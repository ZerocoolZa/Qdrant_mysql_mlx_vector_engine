"""
#[@GHOST]{("file_path=/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/DevinProcessManager.py";"identity=DevinProcessManager";"purpose=Manage Devin CLI process lifecycle so sessions.db can be read without lock";"date=2026-06-29";"version=1.0";"author=Devin";"chat_link=")}
#[@VBSTYLE]{("auth=Devin";"role=domain_process_lifecycle";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded|no_tabs|no_self_underscore";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("DevinProcessManager")}
#[@METHODS]{("__init__";"Run";"Find";"Close";"read_state";"set_config";"_p")}
#[@DOMAIN]{("process_lifecycle")}
"""

import os
import signal
from typing import Any, Dict, Tuple


class DevinProcessManager:
    """Authority for finding and closing Devin CLI processes."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "process_names": ["devin", "devin-cli"],
                "exclude_own_pid": True,
            },
            "results": [],
            "memunit": mem,
            "db_manager": db,
        }
        if param and isinstance(param, dict):
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "find":
            return self.Find(params)
        elif command == "close":
            return self.Close(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        else:
            return (0, None, ("UNKNOWN_COMMAND", f"Unknown command: {command}", 0))

    def _p(self, params, key, default=None):
        if not params or not isinstance(params, dict):
            return default
        return params.get(key, default)

    def read_state(self, params):
        return (1, {
            "config": dict(self.state["config"]),
            "results": list(self.state["results"]),
        }, None)

    def set_config(self, params):
        try:
            if not params or not isinstance(params, dict):
                return (0, None, ("SET_CONFIG_ERROR", "param dict required", 0))
            for key, value in params.items():
                self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("SET_CONFIG_ERROR", str(e), 0))

    def _MatchDevinProcess(self, cmdline):
        if not cmdline:
            return False
        cmdline = cmdline.strip()
        tokens = cmdline.split()
        if not tokens:
            return False
        exe = tokens[0]
        base = os.path.basename(exe)
        if base == "devin":
            return True
        if exe.endswith("/devin"):
            return True
        if exe.endswith("/devin acp"):
            return True
        if len(tokens) > 1 and tokens[0] == "devin":
            return True
        if len(tokens) > 1 and tokens[1] == "devin":
            return True
        return False

    def Find(self, params):
        try:
            own_pid = os.getpid()
            exclude_own = self._p(params, "exclude_own_pid", self.state["config"]["exclude_own_pid"])
            found = []

            try:
                import psutil
                for proc in psutil.process_iter(["pid", "name", "exe", "cmdline"]):
                    pid = proc.info.get("pid")
                    if exclude_own and pid == own_pid:
                        continue
                    name = proc.info.get("name") or ""
                    exe = proc.info.get("exe") or ""
                    cmdline = proc.info.get("cmdline") or []
                    cmdline_str = " ".join(cmdline) if isinstance(cmdline, list) else str(cmdline)
                    if name == "devin" or os.path.basename(exe) == "devin" or self._MatchDevinProcess(cmdline_str):
                        found.append({"pid": pid, "cmdline": cmdline_str[:500]})
                self.state["results"] = found
                return (1, {"found": found, "count": len(found)}, None)
            except ImportError:
                pass

            if os.path.isdir("/proc"):
                for pid_str in os.listdir("/proc"):
                    try:
                        pid = int(pid_str)
                    except ValueError:
                        continue
                    if exclude_own and pid == own_pid:
                        continue
                    cmdline_path = os.path.join("/proc", pid_str, "cmdline")
                    try:
                        with open(cmdline_path, "rb") as f:
                            cmdline = f.read().decode("utf-8", errors="replace")
                    except (OSError, IOError):
                        continue
                    if self._MatchDevinProcess(cmdline.replace("\x00", " ")):
                        found.append({"pid": pid, "cmdline": cmdline.replace("\x00", " ")[:500]})
            else:
                try:
                    import subprocess
                    result = subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True)
                    for line in result.stdout.splitlines()[1:]:
                        parts = line.strip().split(None, 1)
                        if len(parts) < 2:
                            continue
                        try:
                            pid = int(parts[0])
                        except ValueError:
                            continue
                        if exclude_own and pid == own_pid:
                            continue
                        cmdline = parts[1]
                        if self._MatchDevinProcess(cmdline):
                            found.append({"pid": pid, "cmdline": cmdline[:500]})
                except Exception as e:
                    return (0, None, ("FIND_PROCESS_ERROR", str(e), 0))

            self.state["results"] = found
            return (1, {"found": found, "count": len(found)}, None)
        except Exception as e:
            return (0, None, ("FIND_PROCESS_ERROR", str(e), 0))

    def Close(self, params):
        try:
            ok, data, err = self.Find(params)
            if not ok:
                return (0, None, err)
            found = data.get("found", [])
            if not found:
                return (1, {"closed": [], "skipped": [], "count": 0}, None)

            force = self._p(params, "force", False)
            dry_run = self._p(params, "dry_run", False)
            closed = []
            skipped = []

            for proc in found:
                pid = proc["pid"]
                if dry_run:
                    skipped.append({"pid": pid, "cmdline": proc["cmdline"], "reason": "dry_run"})
                    continue
                if not force:
                    skipped.append({"pid": pid, "cmdline": proc["cmdline"], "reason": "force_required"})
                    continue
                try:
                    os.kill(pid, signal.SIGTERM)
                    closed.append({"pid": pid, "cmdline": proc["cmdline"], "signal": "SIGTERM"})
                except Exception as e:
                    skipped.append({"pid": pid, "cmdline": proc["cmdline"], "reason": str(e)})

            self.state["results"] = {"closed": closed, "skipped": skipped}
            return (1, {"closed": closed, "skipped": skipped, "closed_count": len(closed)}, None)
        except Exception as e:
            return (0, None, ("CLOSE_PROCESS_ERROR", str(e), 0))
