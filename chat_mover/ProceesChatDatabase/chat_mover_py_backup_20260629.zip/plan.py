#!/usr/bin/env python3
"""
Step 6: PLAN — Generate change list with impacts, dependencies, execution order.

Reads violations from chatmover_code.db, groups by type and file,
generates a prioritized plan with:
  - What to change
  - Impact (what else breaks)
  - Dependencies (what must be done first)
  - Execution order
  - Risk level

Outputs to plan_changes table and prints summary.
"""
import os
import sys
import sqlite3
import json
from collections import defaultdict


PLAN_SCHEMA = """
CREATE TABLE IF NOT EXISTS plan_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    change_id TEXT NOT NULL,           -- PLN-001, PLN-002, etc.
    violation_type TEXT NOT NULL,
    file_path TEXT,
    class_name TEXT,
    unit_name TEXT,
    change_description TEXT NOT NULL,
    impact TEXT,                       -- what else this affects
    dependencies TEXT,                 -- which other PLN-xxx must be done first
    execution_order INTEGER,           -- 1 = do first
    risk TEXT,                         -- low | medium | high
    estimated_fix TEXT,                -- the actual fix to apply
    status TEXT DEFAULT 'pending',     -- pending | in_progress | done | skipped
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pc_order ON plan_changes(execution_order);
CREATE INDEX IF NOT EXISTS idx_pc_type ON plan_changes(violation_type);
"""


def get_db():
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
    return sqlite3.connect(db_path)


def generate_plan():
    conn = get_db()
    cur = conn.cursor()
    conn.executescript(PLAN_SCHEMA)
    cur.execute("DELETE FROM plan_changes")
    conn.commit()

    # Get all violations grouped by type
    cur.execute("""
        SELECT violation_type, severity, file_path, class_name, unit_name, detail, COUNT(*) as cnt
        FROM violations
        GROUP BY violation_type, file_path, class_name
        ORDER BY 
            CASE severity WHEN 'error' THEN 0 ELSE 1 END,
            cnt DESC
    """)
    rows = cur.fetchall()

    # Also get repair routes for known fixes
    cur.execute("SELECT violation_type, route_name, confidence, success_count, fail_count FROM repair_routes")
    routes = {r[0]: {"fix": r[1], "confidence": r[2], "success": r[3], "fail": r[4]} for r in cur.fetchall()}

    # Get graph edges for impact analysis
    cur.execute("SELECT source_class, source_unit, target_name, edge_type FROM graph_edges")
    all_edges = cur.fetchall()

    # Build dependency map: which classes call which
    callers = defaultdict(list)
    for src_class, src_unit, target, etype in all_edges:
        if target:
            callers[target].append(src_class)

    changes = []
    order = 1

    # Group by violation type for batch fixes
    by_type = defaultdict(list)
    for vtype, sev, fpath, cls, uname, detail, cnt in rows:
        by_type[vtype].append((sev, fpath, cls, uname, detail, cnt))

    # Define fix strategies and execution priority
    fix_strategies = {
        "has_print": {
            "fix": "Remove print() statements or replace with sys.stdout.write()",
            "risk": "low",
            "batch": True,
            "order": 1,
            "impact": "No downstream impact — print removal is safe",
        },
        "has_decorator": {
            "fix": "Remove @property/@staticmethod/@classmethod decorators",
            "risk": "medium",
            "batch": True,
            "order": 2,
            "impact": "Callers may use property access syntax — check all references",
        },
        "has_self_underscore": {
            "fix": "Convert self._xxx to self.state['xxx'] using AST-aware replacement (not regex)",
            "risk": "high",
            "batch": True,
            "order": 3,
            "impact": "All internal references to self._xxx must be updated simultaneously",
            "note": "Previous regex attempt FAILED — use AST-based replacement",
        },
        "method_no_tuple3": {
            "fix": "Convert return statements to Tuple3 format: (1, data, None) or (0, None, (code, desc, 0))",
            "risk": "medium",
            "batch": False,
            "order": 4,
            "impact": "All callers checking return value must handle Tuple3 unpacking",
        },
        "dead_method": {
            "fix": "Remove unused methods or wire them into Run() dispatch",
            "risk": "medium",
            "batch": False,
            "order": 5,
            "impact": "Verify no dynamic dispatch or string-based calls reference these methods",
        },
        "hardcoded_host": {
            "fix": "Replace 'localhost' with Config.MYSQL_HOST constant",
            "risk": "low",
            "batch": True,
            "order": 6,
            "impact": "Must import Config in affected files",
        },
        "hardcoded_home_path": {
            "fix": "Replace /Users/xxx paths with Config.BASE_DIR or os.path.expanduser()",
            "risk": "low",
            "batch": True,
            "order": 6,
            "impact": "Must import Config in affected files",
        },
        "hardcoded_user": {
            "fix": "Replace 'root' with Config.MYSQL_USER constant",
            "risk": "low",
            "batch": True,
            "order": 6,
            "impact": "Must import Config in affected files",
        },
        "missing_run": {
            "fix": "Add Run(self, command, params=None) dispatch method to class",
            "risk": "medium",
            "batch": False,
            "order": 7,
            "impact": "Class becomes callable via Run() — update instantiation sites",
        },
        "missing_bcl": {
            "fix": "Run reason.py to generate BCL stamps",
            "risk": "low",
            "batch": True,
            "order": 8,
            "impact": "None — BCL stamps are metadata, not code changes",
        },
        "duplicate_method": {
            "fix": "Merge duplicate methods into shared base class or utility",
            "risk": "high",
            "batch": False,
            "order": 9,
            "impact": "Both classes lose their own copy — must share one implementation",
        },
        "bare_except": {
            "fix": "Replace bare except: with except Exception as e:",
            "risk": "low",
            "batch": True,
            "order": 10,
            "impact": "Minimal — just more specific exception handling",
        },
    }

    for vtype, items in sorted(by_type.items(), key=lambda x: fix_strategies.get(x[0], {}).get("order", 99)):
        strategy = fix_strategies.get(vtype, {
            "fix": "Manual review required",
            "risk": "medium",
            "batch": False,
            "order": 99,
            "impact": "Unknown — needs analysis",
        })

        route = routes.get(vtype, {})
        known_fix = route.get("fix", "")
        route_conf = route.get("confidence", 0)
        route_success = route.get("success", 0)
        route_fail = route.get("fail", 0)

        if strategy["batch"]:
            # One plan entry per violation type (batch fix)
            files_affected = sorted(set(it[1] for it in items if it[1]))
            classes_affected = sorted(set(it[2] for it in items if it[2]))
            total_count = sum(it[5] for it in items)

            change_id = f"PLN-{order:03d}"
            deps = []

            # Dependencies
            if vtype == "method_no_tuple3":
                deps.append("PLN for has_self_underscore (methods must exist before converting returns)")
            if vtype == "dead_method":
                deps.append("PLN for method_no_tuple3 (confirm method is truly dead before removing)")
            if vtype in ("hardcoded_host", "hardcoded_home_path", "hardcoded_user"):
                deps.append("Config.py must be updated with constants first (Step 8)")

            impact = strategy["impact"]
            if route_fail > 0:
                impact += f" | WARNING: previous route failed {route_fail}x — use different approach"

            estimated = strategy["fix"]
            if known_fix and route_success > 0:
                estimated += f" | KNOWN GOOD ROUTE: {known_fix} (confidence={route_conf})"
            elif route_fail > 0:
                estimated += f" | AVOID: {known_fix} (failed before, confidence={route_conf})"

            changes.append({
                "change_id": change_id,
                "violation_type": vtype,
                "file_path": ", ".join(files_affected[:5]) + ("..." if len(files_affected) > 5 else ""),
                "class_name": ", ".join(classes_affected[:3]),
                "unit_name": "",
                "change_description": f"Fix {total_count} {vtype} violations across {len(files_affected)} files",
                "impact": impact,
                "dependencies": "; ".join(deps) if deps else "none",
                "execution_order": order,
                "risk": strategy["risk"],
                "estimated_fix": estimated,
            })
            order += 1
        else:
            # One plan entry per individual violation
            for sev, fpath, cls, uname, detail, cnt in items:
                change_id = f"PLN-{order:03d}"
                deps = []

                # Check if this method is called by others
                called_by = callers.get(uname, []) if uname else []
                if called_by:
                    impact = f"Called by: {', '.join(called_by[:3])}"
                else:
                    impact = strategy["impact"]

                if vtype == "dead_method" and not called_by:
                    impact = "No callers found — safe to remove"
                if vtype == "dead_method" and called_by:
                    impact = f"WARNING: {len(called_by)} callers found — NOT dead, needs wiring"

                estimated = strategy["fix"]
                if known_fix and route_success > 0:
                    estimated += f" | KNOWN GOOD: {known_fix}"

                changes.append({
                    "change_id": change_id,
                    "violation_type": vtype,
                    "file_path": fpath or "",
                    "class_name": cls or "",
                    "unit_name": uname or "",
                    "change_description": f"{vtype}: {detail or 'no detail'}",
                    "impact": impact,
                    "dependencies": "none",
                    "execution_order": order,
                    "risk": strategy["risk"],
                    "estimated_fix": estimated,
                })
                order += 1

    # Write to DB
    for c in changes:
        cur.execute("""
            INSERT INTO plan_changes
                (change_id, violation_type, file_path, class_name, unit_name,
                 change_description, impact, dependencies, execution_order, risk, estimated_fix)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (c["change_id"], c["violation_type"], c["file_path"], c["class_name"],
              c["unit_name"], c["change_description"], c["impact"], c["dependencies"],
              c["execution_order"], c["risk"], c["estimated_fix"]))

    conn.commit()
    conn.close()
    return changes


def print_plan(changes):
    sys.stdout.write(f"\n{'='*80}\n")
    sys.stdout.write(f"STEP 6: PLAN — Change List ({len(changes)} changes)\n")
    sys.stdout.write(f"{'='*80}\n\n")

    # Group by execution order
    by_order = defaultdict(list)
    for c in changes:
        by_order[c["execution_order"]].append(c)

    for order_num in sorted(by_order.keys()):
        items = by_order[order_num]
        risk_icon = {"low": "OK", "medium": "!!", "high": "XX"}.get(items[0]["risk"], "??")
        sys.stdout.write(f"  ORDER {order_num}  [{risk_icon}]  {items[0]['violation_type']}  ({len(items)} change(s))\n")
        for c in items:
            sys.stdout.write(f"    {c['change_id']}  {c['change_description']}\n")
            if c["file_path"]:
                sys.stdout.write(f"      file: {c['file_path']}\n")
            if c["class_name"]:
                sys.stdout.write(f"      class: {c['class_name']}\n")
            sys.stdout.write(f"      risk: {c['risk']}  |  deps: {c['dependencies']}\n")
            sys.stdout.write(f"      impact: {c['impact']}\n")
            sys.stdout.write(f"      fix: {c['estimated_fix']}\n")
            sys.stdout.write(f"\n")

    # Summary
    sys.stdout.write(f"{'='*80}\n")
    sys.stdout.write(f"SUMMARY:\n")
    by_risk = defaultdict(int)
    by_vtype = defaultdict(int)
    for c in changes:
        by_risk[c["risk"]] += 1
        by_vtype[c["violation_type"]] += 1
    sys.stdout.write(f"  By risk:  {dict(by_risk)}\n")
    sys.stdout.write(f"  By type:  {dict(by_vtype)}\n")
    sys.stdout.write(f"  Total:    {len(changes)} changes\n")
    sys.stdout.write(f"{'='*80}\n")


if __name__ == "__main__":
    changes = generate_plan()
    print_plan(changes)
