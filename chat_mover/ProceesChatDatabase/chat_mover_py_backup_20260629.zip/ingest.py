#!/usr/bin/env python3
"""
Step 1 of the ChatMover Refactor Pipeline: INGEST

Reads every .py file in a target directory, uses Python's ast module to extract
classes, methods, functions, imports, and stores them as normalized rows in SQLite.

One row = one code unit (class, method, or function).
The table IS the file — you can reconstruct any file from its rows.

Usage:
    python3 ingest.py                          # Default: ingest chat_mover/
    python3 ingest.py --dir /path/to/py/files  # Custom directory
    python3 ingest.py --db /path/to/output.db  # Custom DB path
    python3 ingest.py --stats                  # Show DB stats after ingest
"""

import ast
import os
import sys
import hashlib
import argparse
import sqlite3
from pathlib import Path


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS code_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT NOT NULL,
    unit_type TEXT NOT NULL,          -- 'class' | 'method' | 'function' | 'import'
    class_name TEXT,                  -- NULL for top-level functions
    unit_name TEXT NOT NULL,          -- method/function/class name
    source_text TEXT,                 -- full source of this unit
    line_start INTEGER,
    line_end INTEGER,
    return_type TEXT,                 -- 'Tuple3', 'None', 'unknown', etc.
    dispatch_keys TEXT,               -- comma-separated Run() command keys
    calls TEXT,                       -- comma-separated method/function names called
    imports TEXT,                     -- for import rows: the imported names
    decorators TEXT,                  -- comma-separated decorator names
    is_vbstyle INTEGER DEFAULT 0,     -- 1 if passes basic VBStyle checks
    content_hash TEXT,                -- SHA-256 of source_text
    ingested_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_cu_file ON code_units(file_path);
CREATE INDEX IF NOT EXISTS idx_cu_class ON code_units(class_name);
CREATE INDEX IF NOT EXISTS idx_cu_name ON code_units(unit_name);
CREATE INDEX IF NOT EXISTS idx_cu_type ON code_units(unit_type);

CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT UNIQUE NOT NULL,
    line_count INTEGER,
    class_count INTEGER,
    method_count INTEGER,
    function_count INTEGER,
    import_count INTEGER,
    content_hash TEXT,
    ingested_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS graph_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file TEXT,
    source_class TEXT,
    source_unit TEXT,
    target_name TEXT,                -- what it calls/imports/uses
    edge_type TEXT                   -- 'calls' | 'imports' | 'uses' | 'contains'
);
CREATE INDEX IF NOT EXISTS idx_ge_source ON graph_edges(source_file, source_class, source_unit);
CREATE INDEX IF NOT EXISTS idx_ge_target ON graph_edges(target_name);
CREATE INDEX IF NOT EXISTS idx_ge_type ON graph_edges(edge_type);
"""


def extract_calls(node):
    """Extract all function/method call names from an AST node's body."""
    calls = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            if isinstance(child.func, ast.Name):
                calls.add(child.func.id)
            elif isinstance(child.func, ast.Attribute):
                calls.add(child.func.attr)
    return sorted(calls)


def extract_dispatch_keys(node):
    """Extract Run() dispatch command keys from if/elif chains."""
    keys = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Compare):
            # Look for patterns like: command == "decrypt"
            if isinstance(child.left, ast.Name) and child.left.id == "command":
                for comparator in child.comparators:
                    if isinstance(comparator, ast.Constant) and isinstance(comparator.value, str):
                        keys.add(comparator.value)
            # Or: command in ("decrypt", "ingest")
            if isinstance(child.ops, list) and any(isinstance(op, ast.In) for op in child.ops):
                if isinstance(child.comparators[0], (ast.Tuple, ast.List, ast.Set)):
                    for elt in child.comparators[0].elts:
                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                            keys.add(elt.value)
    return sorted(keys)


def detect_return_type(node):
    """Detect the return type pattern (Tuple3, None, etc.)."""
    has_tuple_return = False
    has_none_return = False
    for child in ast.walk(node):
        if isinstance(child, ast.Return) and child.value:
            if isinstance(child.value, ast.Tuple):
                has_tuple_return = True
            elif isinstance(child.value, ast.Constant) and child.value.value is None:
                has_none_return = True
    if has_tuple_return:
        return "Tuple3"
    if has_none_return:
        return "None"
    return "unknown"


def get_decorators(node):
    """Extract decorator names from a function/class node."""
    decorators = []
    if hasattr(node, 'decorator_list'):
        for dec in node.decorator_list:
            if isinstance(dec, ast.Name):
                decorators.append(dec.id)
            elif isinstance(dec, ast.Attribute):
                decorators.append(dec.attr)
            elif isinstance(dec, ast.Call):
                if isinstance(dec.func, ast.Name):
                    decorators.append(dec.func.id)
                elif isinstance(dec.func, ast.Attribute):
                    decorators.append(dec.func.attr)
    return decorators


def check_vbstyle(unit_type, source_text, decorators, return_type):
    """Basic VBStyle compliance check."""
    if unit_type == "import":
        return 1
    if decorators:
        return 0  # No decorators allowed
    if "print(" in source_text:
        return 0  # No print
    if "self._" in source_text and unit_type in ("method",):
        return 0  # No self._ prefix
    if return_type != "Tuple3" and unit_type in ("method", "function"):
        # Helper methods like _p, read_state, set_config can return non-Tuple3
        # but core methods should return Tuple3
        if "def Run(" in source_text and return_type != "Tuple3":
            return 0
    return 1


def ingest_file(db_path, py_file):
    """Parse one .py file and store all code units in SQLite."""
    try:
        source = Path(py_file).read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        return {"file": py_file, "error": str(e)}

    try:
        tree = ast.parse(source, filename=py_file)
    except SyntaxError as e:
        return {"file": py_file, "error": f"SyntaxError: {e}"}

    source_lines = source.splitlines()
    file_hash = hashlib.sha256(source.encode('utf-8')).hexdigest()
    units = []
    edges = []
    class_count = 0
    method_count = 0
    function_count = 0
    import_count = 0

    # Extract imports
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            import_names = []
            if isinstance(node, ast.Import):
                for alias in node.names:
                    import_names.append(alias.name)
            else:
                module = node.module or ""
                for alias in node.names:
                    import_names.append(f"{module}.{alias.name}" if module else alias.name)

            src_segment = ast.get_source_segment(source, node) or ""
            units.append((
                py_file, "import", None, "import",
                src_segment, node.lineno, node.end_lineno,
                None, None, None, ", ".join(import_names), None,
                check_vbstyle("import", src_segment, [], None),
                hashlib.sha256(src_segment.encode('utf-8')).hexdigest()
            ))
            import_count += 1
            for name in import_names:
                edges.append((py_file, None, "import", name, "imports"))

    # Extract classes and their methods
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            class_count += 1
            class_src = ast.get_source_segment(source, node) or ""
            class_decorators = get_decorators(node)

            units.append((
                py_file, "class", None, node.name,
                class_src, node.lineno, node.end_lineno,
                None, None, ", ".join(extract_calls(node)), None,
                ", ".join(class_decorators),
                check_vbstyle("class", class_src, class_decorators, "unknown"),
                hashlib.sha256(class_src.encode('utf-8')).hexdigest()
            ))
            edges.append((py_file, None, node.name, node.name, "contains"))

            # Extract methods within the class
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    method_count += 1
                    method_src = ast.get_source_segment(source, item) or ""
                    method_decorators = get_decorators(item)
                    method_calls = extract_calls(item)
                    dispatch_keys = extract_dispatch_keys(item)
                    return_type = detect_return_type(item)

                    units.append((
                        py_file, "method", node.name, item.name,
                        method_src, item.lineno, item.end_lineno,
                        return_type, ", ".join(dispatch_keys),
                        ", ".join(method_calls), None,
                        ", ".join(method_decorators),
                        check_vbstyle("method", method_src, method_decorators, return_type),
                        hashlib.sha256(method_src.encode('utf-8')).hexdigest()
                    ))
                    edges.append((py_file, node.name, item.name, item.name, "contains"))
                    for call in method_calls:
                        edges.append((py_file, node.name, item.name, call, "calls"))

    # Extract top-level functions
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            function_count += 1
            func_src = ast.get_source_segment(source, node) or ""
            func_decorators = get_decorators(node)
            func_calls = extract_calls(node)
            return_type = detect_return_type(node)

            units.append((
                py_file, "function", None, node.name,
                func_src, node.lineno, node.end_lineno,
                return_type, None,
                ", ".join(func_calls), None,
                ", ".join(func_decorators),
                check_vbstyle("function", func_src, func_decorators, return_type),
                hashlib.sha256(func_src.encode('utf-8')).hexdigest()
            ))
            edges.append((py_file, None, node.name, node.name, "contains"))
            for call in func_calls:
                edges.append((py_file, None, node.name, call, "calls"))

    # Write to SQLite
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Clear old data for this file
    cur.execute("DELETE FROM code_units WHERE file_path = ?", (py_file,))
    cur.execute("DELETE FROM files WHERE file_path = ?", (py_file,))
    cur.execute("DELETE FROM graph_edges WHERE source_file = ?", (py_file,))

    # Insert units
    cur.executemany("""
        INSERT INTO code_units
            (file_path, unit_type, class_name, unit_name, source_text,
             line_start, line_end, return_type, dispatch_keys, calls,
             imports, decorators, is_vbstyle, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, units)

    # Insert file record
    cur.execute("""
        INSERT OR REPLACE INTO files
            (file_path, line_count, class_count, method_count, function_count,
             import_count, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (py_file, len(source_lines), class_count, method_count,
          function_count, import_count, file_hash))

    # Insert graph edges
    cur.executemany("""
        INSERT INTO graph_edges
            (source_file, source_class, source_unit, target_name, edge_type)
        VALUES (?, ?, ?, ?, ?)
    """, edges)

    conn.commit()
    conn.close()

    return {
        "file": py_file,
        "lines": len(source_lines),
        "classes": class_count,
        "methods": method_count,
        "functions": function_count,
        "imports": import_count,
        "units": len(units),
        "edges": len(edges),
        "hash": file_hash[:12]
    }


def show_stats(db_path):
    """Print database statistics."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM files")
    files = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM code_units")
    units = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM graph_edges")
    edges = cur.fetchone()[0]

    cur.execute("SELECT unit_type, COUNT(*) FROM code_units GROUP BY unit_type")
    by_type = cur.fetchall()

    cur.execute("SELECT COUNT(*) FROM code_units WHERE is_vbstyle = 0")
    violations = cur.fetchone()[0]

    cur.execute("""
        SELECT file_path, class_count, method_count, function_count, import_count
        FROM files ORDER BY file_path
    """)
    file_rows = cur.fetchall()

    conn.close()

    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for utype, count in by_type:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for fpath, cls, meth, func, imp in file_rows:
        fname = os.path.basename(fpath)
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
def main():
    parser = argparse.ArgumentParser(description="Ingest .py files into SQLite for the ChatMover Refactor Pipeline")
    parser.add_argument("--dir", default=os.path.dirname(os.path.abspath(__file__)),
                        help="Directory to scan for .py files (default: this folder)")
    parser.add_argument("--db", default=None,
                        help="SQLite DB path (default: <dir>/chatmover_code.db)")
    parser.add_argument("--stats", action="store_true",
                        help="Show database statistics after ingest")
    args = parser.parse_args()

    target_dir = os.path.expanduser(args.dir)
    db_path = args.db or os.path.join(target_dir, "chatmover_code.db")

    if not os.path.isdir(target_dir):
        pass  # TODO: replace with Report
        sys.exit(1)

    py_files = sorted(Path(target_dir).glob("*.py"))
    if not py_files:
        pass  # TODO: replace with Report
        sys.exit(0)

    # Create schema
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA_SQL)
    conn.commit()
    conn.close()

    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    print()

    total_units = 0
    total_edges = 0
    failed = 0

    for py_file in py_files:
        result = ingest_file(db_path, str(py_file))
        if "error" in result:
            pass  # TODO: replace with Report
            failed += 1
        else:
            pass  # TODO: replace with Report
            total_units += result["units"]
            total_edges += result["edges"]

    pass  # TODO: replace with Report
    if failed:
        pass  # TODO: replace with Report
    if args.stats:
        show_stats(db_path)


if __name__ == "__main__":
    main()
