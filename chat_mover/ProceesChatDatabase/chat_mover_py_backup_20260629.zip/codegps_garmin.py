#!/usr/bin/env python3
"""
CodeGPS Garmin — PyQt6 visual repair navigation map.

Looks like a Garmin GPS:
  - Dark screen with glowing nodes
  - Roads connecting destinations
  - Green roads = good routes, red = bad, dashed gray = unexplored
  - 3 map views: Repair, Plan, Errors
  - Side panel with details when you click a node
  - Trip history at the bottom

Like a Garmin: you see where you are, where the destinations are,
which roads are safe, and which to avoid.
"""
import os
import sys
import math
import json
import sqlite3
from collections import defaultdict, deque
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSplitter, QFrame, QScrollArea,
    QGraphicsScene, QGraphicsView, QGraphicsEllipseItem,
    QGraphicsLineItem, QGraphicsTextItem, QGraphicsRectItem,
    QGraphicsPathItem,
    QTabWidget, QTextEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QStatusBar, QComboBox,
    QSystemTrayIcon, QMenu, QCheckBox
)
from PyQt6.QtSvgWidgets import QSvgWidget
from PyQt6.QtCore import Qt, QPointF, QRectF, QSize, QVariantAnimation, QEasingCurve, QPoint, QTimer
from PyQt6.QtGui import (
    QColor, QPen, QBrush, QFont, QPainter, QLinearGradient,
    QRadialGradient, QPainterPath, QPolygonF,
    QIcon, QPixmap, QAction
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from collections import deque

from Config import Color, Font, Style, Theme

GARMIN_ANIMATED_SVG = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 200" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0B1329"/>
      <stop offset="60%" stop-color="#1C2541"/>
      <stop offset="100%" stop-color="#010816"/>
    </linearGradient>
    <linearGradient id="chromeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#64748B"/>
      <stop offset="20%" stop-color="#CBD5E1"/>
      <stop offset="40%" stop-color="#FFFFFF"/>
      <stop offset="55%" stop-color="#E2E8F0"/>
      <stop offset="70%" stop-color="#94A3B8"/>
      <stop offset="100%" stop-color="#334155"/>
    </linearGradient>
    <filter id="gpsGlow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="{dot_glow_radius}" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
    <filter id="logoShadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000000" flood-opacity="0.6"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" rx="8" fill="url(#bgGrad)" stroke="#1a1a2e" stroke-width="0.5"/>
  <g stroke="#38BDF8" stroke-width="0.5" opacity="0.04">
    <line x1="100" y1="0" x2="100" y2="200" />
    <line x1="200" y1="0" x2="200" y2="200" />
    <circle cx="175" cy="100" r="80" fill="none" />
    <circle cx="175" cy="100" r="50" fill="none" stroke-dasharray="4 4" />
  </g>
  <g transform="translate(45, -75)">
    <path d="M 195,115 L 145,195 L 205,195 Z" fill="url(#chromeGrad)" />
    <circle cx="195" cy="92" r="7.5" fill="#38BDF8" filter="url(#gpsGlow)" opacity="{dot_opacity}" />
    <circle cx="195" cy="92" r="3" fill="#E0F2FE" />
  </g>
  <text x="280" y="120"
        font-family="Menlo, Courier New, monospace"
        font-size="22"
        font-weight="bold"
        fill="#e94560">
    CodeGPS
  </text>
  <text x="280" y="145"
        font-family="Menlo, Courier New, monospace"
        font-size="11"
        fill="#607080">
    Repair Navigation System
  </text>
</svg>
"""


class GarminLogoWidget(QSvgWidget):
    """Animated Garmin SVG logo with pulsing GPS beacon dot."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.glow_radius = 6.0
        self.dot_opacity = 0.85
        self.update_svg_render()
        self.start_pulse_animation()

    def update_svg_render(self):
        animated = GARMIN_ANIMATED_SVG.format(
            dot_glow_radius=self.glow_radius,
            dot_opacity=self.dot_opacity
        )
        self.load(bytearray(animated, encoding="utf-8"))

    def start_pulse_animation(self):
        self.pulse_anim = QVariantAnimation(self)
        self.pulse_anim.setDuration(1800)
        self.pulse_anim.setStartValue(4.0)
        self.pulse_anim.setEndValue(12.0)
        self.pulse_anim.setEasingCurve(QEasingCurve.Type.InOutSine)

        def handle_pulse(value):
            self.glow_radius = value
            self.dot_opacity = 1.0 - ((value - 4.0) / 16.0)
            self.update_svg_render()

        self.pulse_anim.valueChanged.connect(handle_pulse)
        self.pulse_anim.setLoopCount(-1)
        self.pulse_anim.start()

    def enterEvent(self, event):
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.parent() and hasattr(self.parent(), "on_logo_click"):
                self.parent().on_logo_click()
            event.accept()


class RepairTelemetryGraph(FigureCanvas):
    """Live scrolling graph showing repair pipeline metrics over time."""

    def __init__(self, parent=None):
        fig = Figure(figsize=(6, 1.8), facecolor="#0B1329")
        self.ax = fig.add_subplot(111)
        self.ax.set_facecolor("#0B1329")

        for spine in self.ax.spines.values():
            spine.set_visible(False)

        self.ax.get_xaxis().set_visible(False)
        self.ax.tick_params(axis="y", colors="#475569", labelsize=7)
        self.ax.set_ylim(0, 50)
        self.ax.grid(True, color="#1E293B", linestyle="--", linewidth=0.5)

        self.violation_history = deque([0] * 40, maxlen=40)
        self.error_history = deque([0] * 40, maxlen=40)
        self.x_axis = list(range(40))

        self.violation_line, = self.ax.plot(
            self.x_axis, self.violation_history,
            color="#38BDF8", linewidth=2, label="Violations"
        )
        self.error_line, = self.ax.plot(
            self.x_axis, self.error_history,
            color="#EF4444", linewidth=1.5, linestyle=":", label="Errors"
        )

        self.ax.legend(
            loc="upper right", facecolor="#0B1329",
            edgecolor="none", labelcolor="#64748B", fontsize=7
        )

        super().__init__(fig)
        self.setParent(parent)

    def update_graph(self, violations, errors):
        self.violation_history.append(violations)
        self.error_history.append(errors)
        self.violation_line.set_ydata(self.violation_history)
        self.error_line.set_ydata(self.error_history)
        self.draw_idle()


DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "garmin_telemetry_history.json")

# Garmin-like color scheme
COL_BG = QColor("#0a0a14")
COL_PANEL = QColor("#111122")
COL_TEXT = QColor("#e0e0e0")
COL_ACCENT = QColor("#e94560")
COL_GREEN = QColor("#00e676")
COL_RED = QColor("#ff5252")
COL_YELLOW = QColor("#ffd740")
COL_BLUE = QColor("#448aff")
COL_GRAY = QColor("#37474f")
COL_DARK = QColor("#050510")
COL_ROAD = QColor("#1a1a2e")
COL_NODE_BG = QColor("#0d1b2a")
COL_GRID = QColor("#0d1520")


class GPSNode(QGraphicsEllipseItem):
    """A glowing destination node on the map."""

    def __init__(self, x, y, radius, label, color, node_id="", data=None, main_window=None):
        super().__init__(x - radius, y - radius, radius * 2, radius * 2)
        self.radius = radius
        self.label = label
        self.color = color
        self.node_id = node_id
        self.data = data or {}
        self.main_window = main_window
        self.setPen(QPen(color, 2))
        self.setBrush(QBrush(COL_NODE_BG))
        self.setZValue(10)
        self.setAcceptHoverEvents(True)

        # Glow effect via larger faint circle behind
        glow = QGraphicsEllipseItem(x - radius - 6, y - radius - 6,
                                     (radius + 6) * 2, (radius + 6) * 2)
        glow.setPen(QPen(color, 1))
        glow.setBrush(QBrush(QColor(color.red(), color.green(), color.blue(), 30)))
        glow.setZValue(9)
        self.glow = glow

        # Label
        self.label_item = QGraphicsTextItem(label)
        self.label_item.setDefaultTextColor(color)
        self.label_item.setFont(QFont("Menlo", 8, QFont.Weight.Bold))
        label_w = self.label_item.boundingRect().width()
        self.label_item.setPos(x - label_w / 2, y - radius - 18)
        self.label_item.setZValue(11)

    def hoverEnterEvent(self, event):
        self.setPen(QPen(self.color, 3))
        self.setBrush(QBrush(QColor(self.color.red(), self.color.green(), self.color.blue(), 40)))
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.setPen(QPen(self.color, 2))
        self.setBrush(QBrush(COL_NODE_BG))
        super().hoverLeaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.main_window:
            self.main_window.show_detail(self.data)
            self.main_window.status.showMessage(f"Selected: {self.data.get('vtype', self.data.get('id', self.label))}")
        super().mousePressEvent(event)


class GPSRoad(QGraphicsLineItem):
    """A road between two nodes on the map."""

    def __init__(self, x1, y1, x2, y2, color, dashed=False, width=2):
        super().__init__(x1, y1, x2, y2)
        pen = QPen(color, width)
        if dashed:
            pen.setStyle(Qt.PenStyle.DashLine)
            pen.setDashPattern([4, 4])
        self.setPen(pen)
        self.setZValue(5)


class CascadeRobot(QGraphicsEllipseItem):
    """A little Cascade AI robot that drives along roads on the map."""

    def __init__(self):
        super().__init__(-12, -12, 24, 24)
        self.setZValue(50)
        self.setPen(QPen(QColor("#38BDF8"), 2))
        self.setBrush(QBrush(QColor("#0F172A")))
        self.setAcceptHoverEvents(False)

        self.eye_l = QGraphicsEllipseItem(-6, -4, 5, 5, self)
        self.eye_l.setPen(QPen(Qt.PenStyle.NoPen))
        self.eye_l.setBrush(QBrush(QColor("#38BDF8")))
        self.eye_r = QGraphicsEllipseItem(1, -4, 5, 5, self)
        self.eye_r.setPen(QPen(Qt.PenStyle.NoPen))
        self.eye_r.setBrush(QBrush(QColor("#38BDF8")))

        self.state = "idle"
        self.path = None
        self.progress = 0.0
        self.speed = 0.008
        self.scene_ref = None
        self.target_node = None
        self.main_window = None
        self.trail = []

    def start_journey(self, path, scene_ref, target_node, main_window):
        self.path = path
        self.scene_ref = scene_ref
        self.target_node = target_node
        self.main_window = main_window
        self.progress = 0.0
        self.state = "driving"
        self.setPen(QPen(QColor("#38BDF8"), 2))
        self.setBrush(QBrush(QColor("#0F172A")))
        self.eye_l.setBrush(QBrush(QColor("#38BDF8")))
        self.eye_r.setBrush(QBrush(QColor("#38BDF8")))
        if self not in scene_ref.items():
            scene_ref.addItem(self)

    def tick(self):
        if self.state == "driving" and self.path:
            self.progress += self.speed
            if self.progress >= 1.0:
                self.progress = 1.0
                self.on_arrive()
            pt = self.path.pointAtPercent(self.progress)
            self.setPos(pt.x(), pt.y())

            if len(self.trail) < 20:
                self.trail.append((pt.x(), pt.y()))
            else:
                self.trail.pop(0)
                self.trail.append((pt.x(), pt.y()))

        elif self.state == "crashed":
            pass

    def on_arrive(self):
        if self.target_node and self.target_node.color == COL_RED:
            self.state = "crashed"
            self.setPen(QPen(QColor("#EF4444"), 3))
            self.setBrush(QBrush(QColor("#7F1D1D")))
            self.eye_l.setBrush(QBrush(QColor("#EF4444")))
            self.eye_r.setBrush(QBrush(QColor("#EF4444")))
            if self.main_window:
                self.main_window.status.showMessage("CASCADE CRASHED at error node — learning to avoid this route...")
                self.main_window.robot_log.append({"event": "crash", "node": self.target_node.label, "learned": True})
        else:
            self.state = "success"
            self.setPen(QPen(QColor("#10B981"), 3))
            self.setBrush(QBrush(QColor("#064E3B")))
            self.eye_l.setBrush(QBrush(QColor("#10B981")))
            self.eye_r.setBrush(QBrush(QColor("#10B981")))
            if self.main_window:
                self.main_window.status.showMessage("CASCADE reached destination successfully!")
                self.main_window.robot_log.append({"event": "success", "node": self.target_node.label})


class GPSMapScene(QGraphicsScene):
    """The map scene — holds all nodes and roads."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setBackgroundBrush(QBrush(COL_BG))
        self.nodes = {}
        self.node_items = []
        self.road_items = []
        self.setItemIndexMethod(QGraphicsScene.ItemIndexMethod.NoIndex)


class GPSMapView(QGraphicsView):
    """The map view — renders the scene with zoom/pan."""

    def __init__(self, scene, parent=None):
        super().__init__(scene, parent)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setBackgroundBrush(QBrush(COL_BG))
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setStyleSheet("QGraphicsView { border: none; background: #0a0a14; }")
        self.scene_ref = scene

    def wheelEvent(self, event):
        zoom_factor = 1.25 if event.angleDelta().y() > 0 else 0.8
        self.scale(zoom_factor, zoom_factor)


class CodeGPSGarmin(QMainWindow):
    """Main CodeGPS Garmin window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("CodeGPS Garmin v3 — Global Repair Matrix")
        self.setMinimumSize(1400, 900)
        self.db_path = DB_PATH
        self.node_data = {}
        self.telemetry_log = []
        self.pulse_nodes = []
        self.robot_log = []
        self.robot = CascadeRobot()
        self.robot_paths = []
        self.robot_targets = []
        self.robot_idx = 0

        self.ensure_database()
        self.load_historical_logs()

        self.current_theme = "midnight"
        Theme.apply(self, self.current_theme)

        self.build_ui()
        self.init_menu()
        self.init_tray()
        self.load_data()
        self.draw_all_maps()

        self.pulse_timer = QTimer(self)
        self.pulse_timer.timeout.connect(self.pulse_error_nodes)
        self.pulse_timer.start(600)
        self.pulse_state = False

        self.robot_timer = QTimer(self)
        self.robot_timer.timeout.connect(self.tick_robot)
        self.robot_timer.start(30)

    def ensure_database(self):
        """Create mock schema + seed a massive global node network if DB is empty."""
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        cur.execute("""CREATE TABLE IF NOT EXISTS violations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT, violation_type TEXT, severity TEXT, message TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS repair_routes (
            violation_type TEXT PRIMARY KEY, route_name TEXT,
            success_count INTEGER DEFAULT 0, fail_count INTEGER DEFAULT 0,
            confidence REAL DEFAULT 0
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS repair_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT, violation_type TEXT, action TEXT,
            result TEXT, tool TEXT, note TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS plan_changes (
            change_id TEXT PRIMARY KEY, execution_order INTEGER,
            violation_type TEXT, risk TEXT, change_description TEXT,
            impact TEXT, estimated_fix TEXT, dependencies TEXT
        )""")

        cur.execute("SELECT COUNT(*) FROM violations")
        if cur.fetchone()[0] == 0:
            mock_violations = [
                ("src/engine.py", "missing_run_method", "error", "Class lacks Run() dispatch method"),
                ("src/engine.py", "print_statement", "error", "Found print() call in production code"),
                ("src/engine.py", "missing_bcl", "error", "No BCL stamp on Engine.process()"),
                ("src/parser.py", "missing_tuple3", "error", "Method does not return Tuple3"),
                ("src/parser.py", "self_underscore", "warning", "Uses self._ prefix instead of self.state"),
                ("src/parser.py", "hardcoded_value", "warning", "Hardcoded timeout 30"),
                ("src/config.py", "hardcoded_value", "warning", "Hardcoded port number 8080"),
                ("src/config.py", "property_decorator", "warning", "Uses @property decorator"),
                ("src/utils.py", "missing_bcl", "error", "No BCL stamp on method"),
                ("src/utils.py", "property_decorator", "warning", "Uses @property decorator"),
                ("src/utils.py", "print_statement", "error", "Debug print in utils"),
                ("src/main.py", "print_statement", "error", "Debug print in main loop"),
                ("src/main.py", "missing_run_method", "error", "Main class lacks Run()"),
                ("src/auth.py", "missing_tuple3", "error", "Auth.check returns bool not Tuple3"),
                ("src/auth.py", "hardcoded_value", "warning", "Hardcoded secret key"),
                ("src/api.py", "print_statement", "error", "print() in API handler"),
                ("src/api.py", "missing_bcl", "error", "No BCL on API routes"),
                ("src/db.py", "self_underscore", "warning", "self._conn used instead of self.state"),
                ("src/db.py", "missing_tuple3", "error", "DB.query returns raw list"),
                ("src/cache.py", "property_decorator", "warning", "@property on cache_size"),
                ("src/cache.py", "hardcoded_value", "warning", "Hardcoded TTL 3600"),
                ("src/logger.py", "print_statement", "error", "print() in logger module"),
                ("src/logger.py", "missing_bcl", "error", "No BCL on Logger.write"),
                ("src/validator.py", "missing_run_method", "error", "Validator lacks Run() dispatch"),
                ("src/validator.py", "self_underscore", "warning", "self._rules used"),
            ]
            cur.executemany("INSERT INTO violations (file_path, violation_type, severity, message) VALUES (?,?,?,?)", mock_violations)

            mock_routes = [
                ("missing_run_method", "insert_run_template", 8, 0, 0.92),
                ("print_statement", "replace_with_pass", 12, 2, 0.88),
                ("missing_tuple3", "wrap_return_tuple3", 6, 0, 0.95),
                ("self_underscore", "rename_to_state", 3, 4, 0.55),
                ("hardcoded_value", "extract_to_config", 7, 0, 0.82),
                ("missing_bcl", "generate_bcl_stamp", 5, 1, 0.78),
                ("property_decorator", "convert_to_method", 4, 2, 0.70),
            ]
            cur.executemany("INSERT OR REPLACE INTO repair_routes VALUES (?,?,?,?,?)", mock_routes)

            mock_logs = [
                ("2025-06-27 10:00:00", "missing_run_method", "insert_run_template", "resolved", "cascade", "Added Run() to Engine class"),
                ("2025-06-27 10:05:00", "print_statement", "replace_with_pass", "resolved", "cascade", "Replaced print with pass in engine.py"),
                ("2025-06-27 10:10:00", "self_underscore", "rename_to_state", "failed", "cascade", "Broke method chain in parser"),
                ("2025-06-27 10:15:00", "self_underscore", "rename_to_state", "reverted", "cascade", "Rolled back rename"),
                ("2025-06-27 10:20:00", "missing_tuple3", "wrap_return_tuple3", "resolved", "cascade", "Wrapped return in Tuple3"),
                ("2025-06-27 10:25:00", "hardcoded_value", "extract_to_config", "resolved", "cascade", "Moved port to Config.py"),
                ("2025-06-27 10:30:00", "missing_bcl", "generate_bcl_stamp", "resolved", "cascade", "Generated BCL for utils.py"),
                ("2025-06-27 10:35:00", "print_statement", "replace_with_pass", "resolved", "cascade", "Removed print from main.py"),
                ("2025-06-27 10:40:00", "property_decorator", "convert_to_method", "failed", "cascade", "Conversion broke interface"),
                ("2025-06-27 10:45:00", "missing_run_method", "insert_run_template", "resolved", "cascade", "Added Run() to Validator"),
                ("2025-06-27 10:50:00", "missing_tuple3", "wrap_return_tuple3", "resolved", "cascade", "Wrapped DB.query return"),
                ("2025-06-27 10:55:00", "print_statement", "replace_with_pass", "resolved", "cascade", "Removed print from logger"),
                ("2025-06-27 11:00:00", "hardcoded_value", "extract_to_config", "resolved", "cascade", "Moved TTL to Config"),
                ("2025-06-27 11:05:00", "missing_bcl", "generate_bcl_stamp", "resolved", "cascade", "BCL stamp on API routes"),
                ("2025-06-27 11:10:00", "self_underscore", "rename_to_state", "resolved", "cascade", "Renamed self._conn in db.py"),
            ]
            cur.executemany("INSERT INTO repair_log (created_at, violation_type, action, result, tool, note) VALUES (?,?,?,?,?,?)", mock_logs)

            mock_plans = [
                ("CHG-001", 1, "missing_run_method", "low", "Insert Run() dispatch", "Adds 8 lines per class", "Add Run() template", "none"),
                ("CHG-002", 2, "print_statement", "low", "Remove print calls", "Removes 6 lines total", "Delete or replace with pass", "none"),
                ("CHG-003", 3, "missing_tuple3", "medium", "Wrap returns in Tuple3", "Changes 4 return signatures", "Wrap in (1, data, None)", "CHG-001"),
                ("CHG-004", 4, "self_underscore", "high", "Rename self._ to self.state", "Breaks method chains", "Find and replace", "CHG-001,CHG-003"),
                ("CHG-005", 5, "hardcoded_value", "low", "Extract to Config.py", "Moves 5 constants", "Add to Config, replace refs", "none"),
                ("CHG-006", 6, "missing_bcl", "medium", "Generate BCL stamps", "Adds metadata to 6 methods", "Run BCL generator", "CHG-001"),
                ("CHG-007", 7, "property_decorator", "medium", "Convert @property to method", "Changes 3 class interfaces", "Replace with explicit getter", "CHG-001"),
                ("CHG-008", 8, "print_statement", "low", "Final print sweep", "Catch remaining prints", "grep + replace", "CHG-002"),
            ]
            cur.executemany("INSERT OR REPLACE INTO plan_changes VALUES (?,?,?,?,?,?,?,?)", mock_plans)

            conn.commit()
        conn.close()

    def load_historical_logs(self):
        if os.path.exists(LOG_FILE):
            try:
                with open(LOG_FILE, "r") as f:
                    self.telemetry_log = json.load(f)
            except Exception:
                self.telemetry_log = []

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(1)
        layout.setContentsMargins(0, 0, 0, 0)

        # Compact top bar — logo + telemetry + buttons in one row
        top_bar = QFrame()
        top_bar.setFixedHeight(36)
        top_bar.setStyleSheet("QFrame { background: #020617; border-bottom: 0.5px solid #121220; }")
        tlay = QHBoxLayout(top_bar)
        tlay.setContentsMargins(6, 0, 6, 0)
        tlay.setSpacing(8)

        self.garmin_logo = GarminLogoWidget(self)
        self.garmin_logo.setFixedHeight(36)
        self.garmin_logo.setFixedWidth(120)
        tlay.addWidget(self.garmin_logo)

        self.telemetry = QLabel("CONNECTING...")
        self.telemetry.setStyleSheet("""
            QLabel {
                background: transparent; color: #38BDF8;
                font-family: Menlo; font-size: 9px; font-weight: bold;
                padding: 0px 4px;
            }
        """)
        tlay.addWidget(self.telemetry, stretch=1)

        self.refresh_btn = QPushButton("⟳")
        self.refresh_btn.setFixedSize(QSize(24, 24))
        self.refresh_btn.clicked.connect(self.refresh)
        tlay.addWidget(self.refresh_btn)

        self.close_btn = QPushButton("✕")
        self.close_btn.setFixedSize(QSize(24, 24))
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent; color: #506070;
                border: none; border-radius: 12px;
                font-size: 11px; font-weight: bold;
            }
            QPushButton:hover {
                background-color: #EF4444; color: #FFFFFF;
            }
        """)
        self.close_btn.clicked.connect(self.close)
        tlay.addWidget(self.close_btn)

        layout.addWidget(top_bar)

        self.telemetry_timer = QTimer(self)
        self.telemetry_timer.timeout.connect(self.update_telemetry)
        self.telemetry_timer.start(2000)
        self.update_telemetry()

        # Live telemetry graph — compact
        self.telemetry_graph = RepairTelemetryGraph()
        self.telemetry_graph.setFixedHeight(60)
        layout.addWidget(self.telemetry_graph)

        # Main splitter: map (left) + detail panel (right)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left: view selector + tabs with maps
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(2)

        # View selector bar
        sel_bar = QFrame()
        sel_bar.setStyleSheet("QFrame { background: #050510; border-bottom: 0.5px solid #121220; }")
        sel_lay = QHBoxLayout(sel_bar)
        sel_lay.setContentsMargins(6, 1, 6, 1)
        sel_label = QLabel("VIEW:")
        sel_label.setStyleSheet("font-family: Menlo; font-size: 10px; color: #607080; font-weight: bold;")
        sel_lay.addWidget(sel_label)
        self.view_selector = QComboBox()
        self.view_selector.addItems(["Repair Map", "Plan Map", "Error Map", "Trip History"])
        self.view_selector.currentIndexChanged.connect(self.on_view_select)
        sel_lay.addWidget(self.view_selector)
        sel_lay.addStretch()
        self.zoom_fit_btn = QPushButton("Zoom to Fit")
        self.zoom_fit_btn.clicked.connect(self.zoom_to_fit)
        sel_lay.addWidget(self.zoom_fit_btn)
        self.send_robot_btn = QPushButton("🤖 Send Cascade")
        self.send_robot_btn.clicked.connect(self.send_robot)
        self.send_robot_btn.setStyleSheet("QPushButton { background: #0d0d18; color: #38BDF8; border: 0.5px solid #38BDF8; border-radius: 2px; padding: 3px 8px; font-family: Menlo; font-size: 9px; font-weight: bold; } QPushButton:hover { background: #38BDF8; color: #0F172A; }")
        sel_lay.addWidget(self.send_robot_btn)
        left_layout.addWidget(sel_bar)

        self.tabs = QTabWidget()
        left_layout.addWidget(self.tabs)
        splitter.addWidget(left_widget)

        # Tab 1: Repair Map
        self.repair_scene = GPSMapScene()
        self.repair_view = GPSMapView(self.repair_scene)
        self.tabs.addTab(self.repair_view, "  REPAIR MAP  ")
        self.repair_view.mousePressEvent = self.on_map_click

        # Tab 2: Plan Map
        self.plan_scene = GPSMapScene()
        self.plan_view = GPSMapView(self.plan_scene)
        self.tabs.addTab(self.plan_view, "  PLAN MAP  ")

        # Tab 3: Error Map
        self.error_scene = GPSMapScene()
        self.error_view = GPSMapView(self.error_scene)
        self.tabs.addTab(self.error_view, "  ERROR MAP  ")

        # Tab 4: Trip History
        history_widget = QWidget()
        hlayout = QVBoxLayout(history_widget)
        hlayout.setContentsMargins(2, 2, 2, 2)
        self.history_table = QTableWidget(0, 6)
        self.history_table.setHorizontalHeaderLabels(["Time", "Type", "Action", "Result", "Tool", "Note"])
        h = self.history_table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        hlayout.addWidget(self.history_table)
        self.tabs.addTab(history_widget, "  TRIP HISTORY  ")

        # Right: detail panel
        detail_widget = QWidget()
        dlayout = QVBoxLayout(detail_widget)
        dlayout.setContentsMargins(4, 4, 4, 4)
        dlayout.setSpacing(4)

        detail_title = QLabel("NAVIGATION DETAILS")
        detail_title.setStyleSheet("font-family: Menlo; font-size: 12px; font-weight: bold; color: #e94560; padding: 4px;")
        dlayout.addWidget(detail_title)

        self.detail_text = QTextEdit()
        self.detail_text.setReadOnly(True)
        dlayout.addWidget(self.detail_text, stretch=1)

        # Legend
        legend_title = QLabel("LEGEND")
        legend_title.setStyleSheet("font-family: Menlo; font-size: 11px; font-weight: bold; color: #607080; padding: 4px;")
        dlayout.addWidget(legend_title)

        legend_items = [
            (COL_GREEN, "Green road = known good route"),
            (COL_RED, "Red road = failed route (avoid!)"),
            (COL_YELLOW, "Yellow road = partial / unknown"),
            (COL_GRAY, "Dashed = no route yet found"),
            (COL_BLUE, "Blue node = your starting point"),
            (COL_GREEN, "Green node = resolved destination"),
            (COL_RED, "Red node = error (must fix)"),
            (COL_YELLOW, "Yellow node = warning (should fix)"),
        ]
        for color, text in legend_items:
            item = QLabel(f"  ●  {text}")
            item.setStyleSheet(f"font-family: Menlo; font-size: 10px; color: #{color.rgb():06x}; padding: 1px 8px;")
            dlayout.addWidget(item)

        dlayout.addStretch()

        # Cascade Robot log
        robot_title = QLabel("🤖 CASCADE ROBOT LOG")
        robot_title.setStyleSheet("font-family: Menlo; font-size: 11px; font-weight: bold; color: #38BDF8; padding: 4px;")
        dlayout.addWidget(robot_title)
        self.robot_log_label = QLabel("Idle — press 'Send Cascade' to dispatch")
        self.robot_log_label.setStyleSheet("font-family: Menlo; font-size: 9px; color: #64748B; padding: 2px 8px;")
        self.robot_log_label.setWordWrap(True)
        dlayout.addWidget(self.robot_log_label)

        # Stats summary
        self.stats_label = QLabel("Loading...")
        self.stats_label.setStyleSheet("font-family: Menlo; font-size: 10px; color: #607080; padding: 4px;")
        dlayout.addWidget(self.stats_label)

        splitter.addWidget(detail_widget)
        splitter.setSizes([900, 350])
        layout.addWidget(splitter, stretch=1)

        # Status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("CodeGPS Garmin ready — click a node for details")

    def init_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        file_menu.addAction("Refresh", self.refresh)
        file_menu.addAction("Export Log", self.export_log)
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        view_menu = menubar.addMenu("View")
        view_menu.addAction("Zoom to Fit", self.zoom_to_fit)
        view_menu.addAction("Send Cascade", self.send_robot)
        view_menu.addSeparator()
        view_menu.addAction("Always on Top", self.toggle_topmost)

        theme_menu = menubar.addMenu("Theme")
        for name in Theme.names():
            act = QAction(name.capitalize(), self, checkable=True)
            act.setChecked(name == self.current_theme)
            act.triggered.connect(lambda checked, n=name: self.switch_theme(n))
            theme_menu.addAction(act)

        help_menu = menubar.addMenu("Help")
        help_menu.addAction("About", self.show_about)

    def init_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setToolTip("CodeGPS Garmin")
        pix = QPixmap(32, 32)
        pix.fill(QColor(Color.ACCENT))
        self.tray_icon.setIcon(QIcon(pix))
        self.tray_icon.activated.connect(self.on_tray_activated)
        tray_menu = QMenu()
        tray_menu.addAction("Show", self.show_window)
        tray_menu.addAction("Refresh", self.refresh)
        tray_menu.addAction("Send Cascade", self.send_robot)
        tray_menu.addSeparator()
        tray_menu.addAction("Exit", self.close)
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()

    def on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.ActivationReason.DoubleClick,
                       QSystemTrayIcon.ActivationReason.Trigger):
            if self.isVisible():
                self.hide()
            else:
                self.show_window()

    def show_window(self):
        self.show()
        self.raise_()
        self.activateWindow()

    def switch_theme(self, name):
        self.current_theme = name
        Theme.apply(self, name)
        self.status.showMessage(f"Theme: {name}")

    def toggle_topmost(self):
        flags = self.windowFlags()
        if flags & Qt.WindowType.WindowStaysOnTopHint:
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, False)
            self.status.showMessage("Always on Top: OFF")
        else:
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
            self.status.showMessage("Always on Top: ON")
        self.show()

    def export_log(self):
        path = os.path.join(os.path.dirname(self.db_path), "codegps_export.json")
        try:
            with open(path, "w") as f:
                json.dump(self.telemetry_log[-500:], f, indent=2)
            self.status.showMessage(f"Exported to {path}")
        except Exception:
            self.status.showMessage("Export failed")

    def show_about(self):
        self.status.showMessage("CodeGPS Garmin v3 — Repair Navigation System")

    def get_conn(self):
        return sqlite3.connect(self.db_path)

    def load_data(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()

            cur.execute("""
                SELECT violation_type, severity, COUNT(*) as cnt
                FROM violations GROUP BY violation_type, severity ORDER BY cnt DESC
            """)
            self.violations = cur.fetchall()

            cur.execute("""
                SELECT violation_type, route_name, success_count, fail_count, confidence
                FROM repair_routes ORDER BY success_count DESC
            """)
            self.routes = {r[0]: r for r in cur.fetchall()}

            cur.execute("""
                SELECT created_at, violation_type, action, result, tool, note
                FROM repair_log ORDER BY created_at DESC
            """)
            self.log_entries = cur.fetchall()

            cur.execute("""
                SELECT change_id, execution_order, violation_type, risk,
                       change_description, impact, estimated_fix, dependencies
                FROM plan_changes ORDER BY execution_order
            """)
            self.plans = cur.fetchall()

            cur.execute("""
                SELECT file_path, violation_type, severity, COUNT(*) as cnt
                FROM violations GROUP BY file_path, violation_type ORDER BY file_path
            """)
            self.violations_by_file = cur.fetchall()

            conn.close()

            total_v = sum(v[2] for v in self.violations)
            self.stats_label.setText(
                f"Violations: {total_v}  |  Routes: {len(self.routes)}  |  "
                f"Plan changes: {len(self.plans)}  |  Log entries: {len(self.log_entries)}"
            )
        except Exception as e:
            self.status.showMessage(f"Error loading: {e}")
            self.violations = []
            self.routes = {}
            self.log_entries = []
            self.plans = []
            self.violations_by_file = []

    def refresh(self):
        self.load_data()
        self.draw_all_maps()
        self.status.showMessage("Refreshed")

    def on_logo_click(self):
        self.load_data()
        self.draw_all_maps()
        self.update_telemetry()
        self.status.showMessage("Garmin logo clicked — data refreshed")

    def on_view_select(self, index):
        self.tabs.setCurrentIndex(index)

    def zoom_to_fit(self):
        view_map = {0: self.repair_view, 1: self.plan_view, 2: self.error_view}
        view = view_map.get(self.tabs.currentIndex())
        if view:
            view.resetTransform()
            scene = view.scene()
            if scene and scene.items():
                view.fitInView(scene.itemsBoundingRect(), Qt.AspectRatioMode.KeepAspectRatio)
                self.status.showMessage("Zoomed to fit all nodes")

    def pulse_error_nodes(self):
        self.pulse_state = not self.pulse_state
        for scene in [self.repair_scene, self.plan_scene, self.error_scene]:
            for item in scene.items():
                if isinstance(item, GPSNode) and item.color == COL_RED:
                    if self.pulse_state:
                        item.setPen(QPen(COL_RED, 4))
                        item.setBrush(QBrush(QColor(255, 82, 82, 80)))
                    else:
                        item.setPen(QPen(COL_RED, 2))
                        item.setBrush(QBrush(COL_NODE_BG))

    def send_robot(self):
        """Send the Cascade robot on a journey along the repair map roads."""
        scene = self.repair_scene
        nodes = [item for item in scene.items() if isinstance(item, GPSNode) and item.data.get("type") == "violation"]
        if not nodes:
            self.status.showMessage("No destinations to send Cascade to")
            return

        start_nodes = [item for item in scene.items() if isinstance(item, GPSNode) and item.data.get("type") == "start"]
        if not start_nodes:
            return
        start = start_nodes[0]

        target = nodes[self.robot_idx % len(nodes)]
        self.robot_idx += 1

        sx = start.rect().center().x()
        sy = start.rect().center().y()
        tx = target.rect().center().x()
        ty = target.rect().center().y()

        path = QPainterPath(QPointF(sx, sy))
        mid_x = (sx + tx) / 2
        mid_y = (sy + ty) / 2 - 60
        path.quadTo(QPointF(mid_x, mid_y), QPointF(tx, ty))

        self.robot.start_journey(path, scene, target, self)
        self.status.showMessage(f"Cascade dispatched to {target.label.replace(chr(10), ' ')}")

    def tick_robot(self):
        """Animation tick — move robot along path, handle crash/success."""
        if self.robot.state == "crashed":
            if self.robot_timer.isActive():
                self.robot_log_label.setText("💥 CRASHED at error node!\nLearning: avoiding this route next time...")
                QTimer.singleShot(2000, self.reset_robot)
                self.robot_timer.stop()
        elif self.robot.state == "success":
            if self.robot_timer.isActive():
                self.robot_log_label.setText("✅ Reached destination safely!\nRoute marked as known-good.")
                QTimer.singleShot(1500, self.reset_robot)
                self.robot_timer.stop()
        else:
            self.robot.tick()
            pct = int(self.robot.progress * 100) if self.robot.progress else 0
            self.robot_log_label.setText(f"🚗 Driving... {pct}%")

    def reset_robot(self):
        """Reset robot to idle and restart the animation timer."""
        self.robot.state = "idle"
        self.robot.setPen(QPen(QColor("#38BDF8"), 2))
        self.robot.setBrush(QBrush(QColor("#0F172A")))
        self.robot.eye_l.setBrush(QBrush(QColor("#38BDF8")))
        self.robot.eye_r.setBrush(QBrush(QColor("#38BDF8")))
        if self.robot.scene_ref:
            self.robot.scene_ref.removeItem(self.robot)
        self.robot.scene_ref = None
        self.robot.path = None
        self.robot_timer.start(30)
        self.robot_log_label.setText("Idle — press 'Send Cascade' to dispatch")

    def closeEvent(self, event):
        try:
            with open(LOG_FILE, "w") as f:
                json.dump(self.telemetry_log[-500:], f, indent=2)
        except Exception:
            pass
        event.accept()

    def update_telemetry(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM violations")
            total_v = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM violations WHERE severity='error'")
            errors = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM repair_routes")
            routes = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM repair_routes WHERE success_count > 0")
            good = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM plan_changes")
            plans = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM repair_log")
            logs = cur.fetchone()[0]
            conn.close()

            self.telemetry.setText(
                f"GPS ONLINE  //  VIOLATIONS: {total_v}  |  ERRORS: {errors}  |  "
                f"ROUTES: {routes} ({good} safe)  |  PLANS: {plans}  |  TRIPS: {logs}"
            )
            self.telemetry_graph.update_graph(total_v, errors)
            self.telemetry_log.append({
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "violations": total_v, "errors": errors
            })
        except Exception:
            self.telemetry.setText("GPS SIGNAL LOST  //  DATABASE OFFLINE")

    def draw_all_maps(self):
        self.draw_repair_map()
        self.draw_plan_map()
        self.draw_error_map()
        self.draw_history()

    def add_map_background(self, scene, w, h):
        """Draw a real Garmin-style map background with terrain, water, parks, and roads."""
        from PyQt6.QtWidgets import QGraphicsPolygonItem
        from PyQt6.QtGui import QPolygonF as GPoly

        bg = QGraphicsRectItem(0, 0, w, h)
        bg.setPen(QPen(Qt.PenStyle.NoPen))
        bg.setBrush(QBrush(QColor("#0A1018")))
        bg.setZValue(-10)
        scene.addItem(bg)

        water1 = QGraphicsPolygonItem(GPoly([
            QPointF(0, 0), QPointF(w * 0.35, 0), QPointF(w * 0.30, h * 0.15),
            QPointF(w * 0.10, h * 0.20), QPointF(0, h * 0.12)
        ]))
        water1.setPen(QPen(QColor("#0C2340"), 1))
        water1.setBrush(QBrush(QColor("#0C2340")))
        water1.setZValue(-8)
        scene.addItem(water1)

        water2 = QGraphicsPolygonItem(GPoly([
            QPointF(w * 0.75, h), QPointF(w, h), QPointF(w, h * 0.70),
            QPointF(w * 0.90, h * 0.78), QPointF(w * 0.82, h * 0.85)
        ]))
        water2.setPen(QPen(QColor("#0C2340"), 1))
        water2.setBrush(QBrush(QColor("#0C2340")))
        water2.setZValue(-8)
        scene.addItem(water2)

        park1 = QGraphicsPolygonItem(GPoly([
            QPointF(w * 0.40, h * 0.50), QPointF(w * 0.55, h * 0.45),
            QPointF(w * 0.60, h * 0.60), QPointF(w * 0.48, h * 0.65),
            QPointF(w * 0.38, h * 0.58)
        ]))
        park1.setPen(QPen(QColor("#0D2818"), 1))
        park1.setBrush(QBrush(QColor("#0D2818")))
        park1.setZValue(-7)
        scene.addItem(park1)

        park2 = QGraphicsPolygonItem(GPoly([
            QPointF(w * 0.15, h * 0.60), QPointF(w * 0.28, h * 0.55),
            QPointF(w * 0.30, h * 0.72), QPointF(w * 0.20, h * 0.75)
        ]))
        park2.setPen(QPen(QColor("#0D2818"), 1))
        park2.setBrush(QBrush(QColor("#0D2818")))
        park2.setZValue(-7)
        scene.addItem(park2)

        blocks = [
            (w * 0.10, h * 0.30, w * 0.12, h * 0.10),
            (w * 0.25, h * 0.25, w * 0.10, h * 0.08),
            (w * 0.40, h * 0.20, w * 0.15, h * 0.10),
            (w * 0.60, h * 0.25, w * 0.12, h * 0.12),
            (w * 0.75, h * 0.30, w * 0.10, h * 0.08),
            (w * 0.08, h * 0.75, w * 0.10, h * 0.08),
            (w * 0.70, h * 0.55, w * 0.08, h * 0.10),
        ]
        for bx, by, bw, bh in blocks:
            block = QGraphicsRectItem(bx, by, bw, bh)
            block.setPen(QPen(QColor("#111820"), 1))
            block.setBrush(QBrush(QColor("#111820")))
            block.setZValue(-6)
            scene.addItem(block)

        for r in range(0, int(w + h), 80):
            line = QGraphicsLineItem(0, r - h, w, r)
            line.setPen(QPen(QColor("#0E1218"), 0.5))
            line.setZValue(-5)
            scene.addItem(line)

    def draw_curved_road(self, scene, x1, y1, x2, y2, color, width=6, dashed=False):
        """Draw a road with casing: dark outline + colored inner line with a curve."""
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        dx = x2 - x1
        dy = y2 - y1
        dist = max(1, (dx * dx + dy * dy) ** 0.5)
        perp_x = -dy / dist * 30
        perp_y = dx / dist * 30
        path = QPainterPath(QPointF(x1, y1))
        path.quadTo(QPointF(mid_x + perp_x, mid_y + perp_y), QPointF(x2, y2))
        casing = QGraphicsPathItem(path)
        cp = QPen(QColor("#0D1117"), width + 4)
        cp.setCapStyle(Qt.PenCapStyle.RoundCap)
        casing.setPen(cp)
        casing.setZValue(3)
        scene.addItem(casing)
        road = QGraphicsPathItem(path)
        rp = QPen(color, width)
        rp.setCapStyle(Qt.PenCapStyle.RoundCap)
        if dashed:
            rp.setStyle(Qt.PenStyle.DashLine)
            rp.setDashPattern([6, 4])
        road.setPen(rp)
        road.setZValue(4)
        scene.addItem(road)
        return path

    def draw_road_label(self, scene, path, text, color):
        pt = path.pointAtPercent(0.5)
        item = QGraphicsTextItem(text)
        item.setDefaultTextColor(color)
        item.setFont(QFont("Menlo", 7, QFont.Weight.Bold))
        item.setPos(pt.x() - item.boundingRect().width() / 2, pt.y() - 18)
        item.setZValue(15)
        scene.addItem(item)

    def draw_compass(self, scene, x, y):
        size = 40
        cx = x + size
        cy = y + size
        circle = QGraphicsEllipseItem(cx - size, cy - size, size * 2, size * 2)
        circle.setPen(QPen(QColor("#334155"), 2))
        circle.setBrush(QBrush(QColor("#0D1117")))
        circle.setZValue(20)
        scene.addItem(circle)
        needle = QPainterPath(QPointF(cx, cy - size + 5))
        needle.lineTo(cx - 8, cy)
        needle.lineTo(cx, cy + size - 5)
        needle.lineTo(cx + 8, cy)
        needle.closeSubpath()
        ni = QGraphicsPathItem(needle)
        ni.setPen(QPen(QColor("#EF4444"), 1))
        ni.setBrush(QBrush(QColor("#EF4444")))
        ni.setZValue(21)
        scene.addItem(ni)
        nl = QGraphicsTextItem("N")
        nl.setDefaultTextColor(QColor("#EF4444"))
        nl.setFont(QFont("Menlo", 9, QFont.Weight.Bold))
        nl.setPos(cx - 5, cy - size - 14)
        nl.setZValue(22)
        scene.addItem(nl)

    def draw_scale_bar(self, scene, x, y, length=150):
        for i in range(4):
            seg = QGraphicsRectItem(x + i * (length // 4), y, length // 4, 6)
            seg.setBrush(QBrush(QColor("#94A3B8") if i % 2 == 0 else QColor("#1E293B")))
            seg.setPen(QPen(QColor("#94A3B8"), 1))
            seg.setZValue(20)
            scene.addItem(seg)
        lbl = QGraphicsTextItem("100 violations")
        lbl.setDefaultTextColor(QColor("#64748B"))
        lbl.setFont(QFont("Menlo", 7))
        lbl.setPos(x, y + 10)
        lbl.setZValue(22)
        scene.addItem(lbl)

    # ═══════════════════════════════════════════════════════════════
    # REPAIR MAP — real Garmin-style road network
    # ═══════════════════════════════════════════════════════════════
    def draw_repair_map(self):
        scene = self.repair_scene
        scene.clear()
        self.node_data = {}

        w = 2400
        h = 1800
        scene.setSceneRect(0, 0, w, h)
        self.add_map_background(scene, w, h)

        title = QGraphicsTextItem("REPAIR MAP — Global Road Network")
        title.setDefaultTextColor(COL_ACCENT)
        title.setFont(QFont("Menlo", 22, QFont.Weight.Bold))
        title.setPos(w // 2 - 200, 10)
        title.setZValue(20)
        scene.addItem(title)

        sub = QGraphicsTextItem("Scroll to zoom  |  Drag to pan  |  Click a destination for repair details")
        sub.setDefaultTextColor(COL_GRAY)
        sub.setFont(QFont("Menlo", 10))
        sub.setPos(w // 2 - 200, 45)
        sub.setZValue(20)
        scene.addItem(sub)

        self.draw_compass(scene, w - 120, 60)
        self.draw_scale_bar(scene, 40, h - 50)

        if not self.violations:
            empty = QGraphicsTextItem("No violations found")
            empty.setDefaultTextColor(COL_GRAY)
            empty.setFont(QFont("Menlo", 14))
            empty.setPos(w // 2 - 80, h // 2)
            scene.addItem(empty)
            return

        start_x = 200
        start_y = h // 2
        start_node = GPSNode(start_x, start_y, 40, "YOU\nARE\nHERE", COL_BLUE, "start",
                             {"type": "start", "label": "Your current location"}, main_window=self)
        scene.addItem(start_node.glow)
        scene.addItem(start_node)
        scene.addItem(start_node.label_item)
        self.node_data["start"] = start_node.data

        hub_positions = [
            (w // 3, h // 4), (2 * w // 3, h // 4),
            (w // 2, h // 2),
            (w // 3, 3 * h // 4), (2 * w // 3, 3 * h // 4),
        ]
        hubs = []
        for i, (hx, hy) in enumerate(hub_positions):
            hub = GPSNode(hx, hy, 18, f"H{i+1}", COL_GRAY, f"hub_{i}",
                          {"type": "hub", "label": f"Intersection {i+1}"}, main_window=self)
            hub.setBrush(QBrush(QColor("#1E293B")))
            scene.addItem(hub.glow)
            scene.addItem(hub)
            scene.addItem(hub.label_item)
            hubs.append((hx, hy))

        for hx, hy in hubs:
            self.draw_curved_road(scene, start_x + 40, start_y, hx, hy, QColor("#3B4D63"), width=12)
        for i in range(len(hubs)):
            x1, y1 = hubs[i]
            x2, y2 = hubs[(i + 1) % len(hubs)]
            self.draw_curved_road(scene, x1, y1, x2, y2, QColor("#3B4D63"), width=10)

        for i, (vtype, sev, cnt) in enumerate(self.violations):
            if sev == "error":
                dest_color = COL_RED
            else:
                dest_color = COL_YELLOW
            route = self.routes.get(vtype)
            if route:
                _, name, success, fail, conf = route
                if success > 0 and fail == 0:
                    road_color = COL_GREEN
                    result_text = "OK"
                    result_color = COL_GREEN
                elif fail > 0 and success == 0:
                    road_color = COL_RED
                    result_text = "FAIL"
                    result_color = COL_RED
                else:
                    road_color = COL_YELLOW
                    result_text = "?"
                    result_color = COL_YELLOW
            else:
                road_color = COL_GRAY
                result_text = "—"
                result_color = COL_GRAY
                name = ""
                conf = 0

            hub_idx = i % len(hubs)
            hx, hy = hubs[hub_idx]
            angle = (i // len(hubs)) * 0.8 + 0.3
            radius = 120 + (i % 3) * 60
            dx = max(80, min(w - 80, hx + math.cos(angle) * radius))
            dy = max(80, min(h - 80, hy + math.sin(angle) * radius))

            path = self.draw_curved_road(scene, hx, hy, dx, dy, road_color,
                                         width=8, dashed=(road_color == COL_GRAY))
            if name:
                self.draw_road_label(scene, path, name[:25], road_color)

            label = f"{vtype}\n({cnt})"
            dest_id = f"dest_{i}"
            dest_node = GPSNode(dx, dy, 38, label, dest_color, dest_id, {
                "type": "violation",
                "vtype": vtype,
                "severity": sev,
                "count": cnt,
                "route": name or "none",
                "result": result_text,
                "confidence": conf,
                "fix": name,
            }, main_window=self)
            scene.addItem(dest_node.glow)
            scene.addItem(dest_node)
            scene.addItem(dest_node.label_item)
            self.node_data[dest_id] = dest_node.data

    # ═══════════════════════════════════════════════════════════════
    # PLAN MAP — execution journey
    # ═══════════════════════════════════════════════════════════════
    def draw_plan_map(self):
        scene = self.plan_scene
        scene.clear()

        n = max(len(self.plans), 1)
        w = max(1100, n * 180)
        h = 600

        scene.setSceneRect(0, 0, w, h)
        self.add_map_background(scene, w, h)

        title = QGraphicsTextItem("PLAN MAP — Execution Journey")
        title.setDefaultTextColor(COL_ACCENT)
        title.setFont(QFont("Menlo", 18, QFont.Weight.Bold))
        title.setPos(w // 2 - 120, 10)
        title.setZValue(20)
        scene.addItem(title)

        if not self.plans:
            empty = QGraphicsTextItem("No plan changes found")
            empty.setDefaultTextColor(COL_GRAY)
            empty.setFont(QFont("Menlo", 14))
            empty.setPos(w // 2 - 80, h // 2)
            scene.addItem(empty)
            return

        risk_colors = {"low": COL_GREEN, "medium": COL_YELLOW, "high": COL_RED}

        margin = 100
        road_w = w - 2 * margin
        step = road_w // max(len(self.plans), 1)
        mid_y = h // 2

        # Main road
        road = QGraphicsLineItem(margin, mid_y, margin + road_w, mid_y)
        road.setPen(QPen(COL_GRAY, 3, Qt.PenStyle.DashLine))
        road.setZValue(1)
        scene.addItem(road)

        # START
        start = GPSNode(margin - 20, mid_y, 25, "START", COL_BLUE, main_window=self)
        scene.addItem(start.glow)
        scene.addItem(start)
        scene.addItem(start.label_item)

        # DONE
        done = GPSNode(margin + road_w + 20, mid_y, 25, "DONE", COL_GREEN, main_window=self)
        scene.addItem(done.glow)
        scene.addItem(done)
        scene.addItem(done.label_item)

        for i, (cid, order, vtype, risk, desc, impact, fix, deps) in enumerate(self.plans):
            x = margin + i * step + step // 2
            color = risk_colors.get(risk, COL_GRAY)

            offset = 100 if i % 2 == 0 else -100
            node_y = mid_y + offset

            # Connector
            conn = GPSRoad(x, mid_y, x, node_y, color, width=2)
            scene.addItem(conn)

            # Node
            label = f"{cid}\n{vtype[:12]}"
            node = GPSNode(x, node_y, 30, label, color, f"plan_{i}", {
                "type": "plan",
                "id": cid,
                "vtype": vtype,
                "risk": risk,
                "desc": desc,
                "impact": impact,
                "fix": fix,
                "deps": deps,
            }, main_window=self)
            scene.addItem(node.glow)
            scene.addItem(node)
            scene.addItem(node.label_item)
            self.node_data[f"plan_{i}"] = node.data

            # Description
            desc_item = QGraphicsTextItem(desc[:50] if desc else "")
            desc_item.setDefaultTextColor(COL_TEXT)
            desc_item.setFont(QFont("Menlo", 8))
            desc_w = desc_item.boundingRect().width()
            desc_item.setPos(x - desc_w / 2, node_y + (45 if offset > 0 else -60))
            desc_item.setZValue(15)
            scene.addItem(desc_item)

            # Risk badge
            risk_item = QGraphicsTextItem(f"[{risk.upper()}]")
            risk_item.setDefaultTextColor(color)
            risk_item.setFont(QFont("Menlo", 8, QFont.Weight.Bold))
            risk_w = risk_item.boundingRect().width()
            risk_item.setPos(x - risk_w / 2, node_y + (-40 if offset > 0 else 35))
            risk_item.setZValue(15)
            scene.addItem(risk_item)

    # ═══════════════════════════════════════════════════════════════
    # ERROR MAP — violations by file
    # ═══════════════════════════════════════════════════════════════
    def draw_error_map(self):
        scene = self.error_scene
        scene.clear()

        w = 1100
        h = 700

        scene.setSceneRect(0, 0, w, h)
        self.add_map_background(scene, w, h)

        title = QGraphicsTextItem("ERROR MAP — Where Problems Cluster")
        title.setDefaultTextColor(COL_ACCENT)
        title.setFont(QFont("Menlo", 18, QFont.Weight.Bold))
        title.setPos(w // 2 - 150, 10)
        title.setZValue(20)
        scene.addItem(title)

        if not self.violations_by_file:
            empty = QGraphicsTextItem("No violations by file")
            empty.setDefaultTextColor(COL_GRAY)
            empty.setFont(QFont("Menlo", 14))
            empty.setPos(w // 2 - 80, h // 2)
            scene.addItem(empty)
            return

        file_groups = defaultdict(list)
        for fpath, vtype, sev, cnt in self.violations_by_file:
            fname = os.path.basename(fpath) if fpath else "unknown"
            file_groups[fname].append((vtype, sev, cnt))

        files = sorted(file_groups.keys())
        cols = min(3, max(1, len(files)))
        rows = math.ceil(len(files) / cols)

        card_w = min(340, (w - 80) // cols)
        card_h = 130
        margin_x = (w - cols * card_w) // (cols + 1)
        margin_y = 80

        for i, fname in enumerate(files):
            col = i % cols
            row = i // cols
            x = margin_x + col * (card_w + margin_x)
            y = margin_y + row * (card_h + 20)

            entries = file_groups[fname]
            total = sum(cnt for _, _, cnt in entries)
            has_error = any(sev == "error" for _, sev, _ in entries)
            border_color = COL_RED if has_error else COL_YELLOW

            # Card background
            card = QGraphicsRectItem(x, y, card_w, card_h)
            card.setPen(QPen(border_color, 2))
            card.setBrush(QBrush(COL_DARK))
            card.setZValue(5)
            scene.addItem(card)

            # File name
            name_item = QGraphicsTextItem(fname[:35])
            name_item.setDefaultTextColor(COL_TEXT)
            name_item.setFont(QFont("Menlo", 10, QFont.Weight.Bold))
            name_item.setPos(x + 10, y + 8)
            name_item.setZValue(10)
            scene.addItem(name_item)

            # Count
            count_item = QGraphicsTextItem(f"{total} violations")
            count_item.setDefaultTextColor(border_color)
            count_item.setFont(QFont("Menlo", 9))
            count_item.setPos(x + 10, y + 28)
            count_item.setZValue(10)
            scene.addItem(count_item)

            # Violation list
            for j, (vtype, sev, cnt) in enumerate(entries[:5]):
                vy = y + 50 + j * 14
                dot = QGraphicsEllipseItem(x + 10, vy - 3, 8, 8)
                dot_color = COL_RED if sev == "error" else COL_YELLOW
                dot.setPen(QPen(dot_color, 1))
                dot.setBrush(QBrush(dot_color))
                dot.setZValue(10)
                scene.addItem(dot)

                vtext = QGraphicsTextItem(f"{vtype} ({cnt})")
                vtext.setDefaultTextColor(COL_TEXT)
                vtext.setFont(QFont("Menlo", 8))
                vtext.setPos(x + 24, vy - 6)
                vtext.setZValue(10)
                scene.addItem(vtext)

            if len(entries) > 5:
                more = QGraphicsTextItem(f"+{len(entries) - 5} more")
                more.setDefaultTextColor(COL_GRAY)
                more.setFont(QFont("Menlo", 7))
                more.setPos(x + 10, y + card_h - 15)
                more.setZValue(10)
                scene.addItem(more)

    # ═══════════════════════════════════════════════════════════════
    # TRIP HISTORY
    # ═══════════════════════════════════════════════════════════════
    def draw_history(self):
        self.history_table.setRowCount(len(self.log_entries))
        for i, (ts, vtype, action, result, tool, note) in enumerate(self.log_entries):
            self.history_table.setItem(i, 0, QTableWidgetItem(ts or ""))
            self.history_table.setItem(i, 1, QTableWidgetItem(vtype or ""))
            self.history_table.setItem(i, 2, QTableWidgetItem(action or ""))
            self.history_table.setItem(i, 3, QTableWidgetItem(result or ""))
            self.history_table.setItem(i, 4, QTableWidgetItem(tool or ""))
            self.history_table.setItem(i, 5, QTableWidgetItem(note or ""))

            if result == "resolved":
                self.history_table.item(i, 3).setForeground(COL_GREEN)
            elif result == "failed":
                self.history_table.item(i, 3).setForeground(COL_RED)
            elif result == "reverted":
                self.history_table.item(i, 3).setForeground(COL_YELLOW)

    # ═══════════════════════════════════════════════════════════════
    # INTERACTION
    # ═══════════════════════════════════════════════════════════════
    def on_map_click(self, event):
        view = self.repair_view
        scene_pos = view.mapToScene(event.pos())
        items = self.repair_scene.items(scene_pos)
        for item in items:
            if isinstance(item, GPSNode):
                data = item.data
                if not data:
                    return
                self.show_detail(data)
                return
        super(GPSMapView, view).mousePressEvent(event)

    def show_detail(self, data):
        lines = []
        dtype = data.get("type", "?")

        if dtype == "start":
            lines.append("YOU ARE HERE")
            lines.append("=" * 40)
            lines.append("This is your starting point.")
            lines.append("All violations are destinations from here.")
        elif dtype == "violation":
            lines.append(f"DESTINATION: {data.get('vtype', '?')}")
            lines.append("=" * 40)
            lines.append(f"  Severity:   {data.get('severity', '?')}")
            lines.append(f"  Count:      {data.get('count', '?')}")
            lines.append(f"  Route:      {data.get('route', 'none')}")
            lines.append(f"  Result:     {data.get('result', '?')}")
            lines.append(f"  Confidence: {data.get('confidence', 0):.1f}")
            if data.get("fix"):
                lines.append(f"  Fix:        {data['fix']}")
        elif dtype == "plan":
            lines.append(f"PLAN: {data.get('id', '?')}")
            lines.append("=" * 40)
            lines.append(f"  Type:        {data.get('vtype', '?')}")
            lines.append(f"  Risk:        {data.get('risk', '?')}")
            lines.append(f"  Description: {data.get('desc', '?')}")
            lines.append(f"  Impact:      {data.get('impact', '?')}")
            lines.append(f"  Fix:         {data.get('fix', '?')}")
            lines.append(f"  Deps:        {data.get('deps', '?')}")

        self.detail_text.setPlainText("\n".join(lines))
        self.status.showMessage(f"Selected: {data.get('vtype', data.get('id', '?'))}")


def main():
    app = QApplication(sys.argv)
    window = CodeGPSGarmin()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
