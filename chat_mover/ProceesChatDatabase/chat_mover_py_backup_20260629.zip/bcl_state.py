#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_state.py"
# date="2026-06-28" author="Cascade" session_id="pipeline-bcl"
# context="BCL state serialization: convert Python dicts/lists to BCL text and back. Replaces JSON for pipeline_maker.py"}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="bcl_state.py" domain="ChatMover" authority="BCLState"}
#[@SUMMARY]{summary="BCLState: serialize Python dicts to BCL containers, deserialize BCL text to Python dicts. Uses existing BCL tokenizer + parser. No JSON."}
#[@CLASS]{class="BCLState" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="Serialize" type="command"}
#[@METHOD]{method="Deserialize" type="command"}
#[@METHOD]{method="SerializeValue" type="helper"}
#[@METHOD]{method="DeserializeNode" type="helper"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import sys

BCL_CORE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "core", "Dom_Bcl")
if BCL_CORE_DIR not in sys.path:
    sys.path.insert(0, BCL_CORE_DIR)

from bcl_lexer import BCLTokenizer
from bcl_parser import BCLParser, BCLNode


class BCLState:
    """Serialize Python dicts to BCL containers, deserialize BCL text to Python dicts."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {},
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "serialize":
            return self.Serialize(params)
        elif command == "deserialize":
            return self.Deserialize(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Serialize(self, params):
        data = self._p(params, "data")
        name = self._p(params, "name", "Root")
        if data is None:
            return (0, None, ("MISSING_PARAM", "data required", 0))
        text = self.SerializeValue(name, data, 0)
        return (1, text, None)

    def SerializeValue(self, name, value, indent):
        pad = "    " * indent
        lines = ["[@%s]{" % name]
        if isinstance(value, dict):
            for key, val in value.items():
                if isinstance(val, dict):
                    lines.append(self.SerializeValue(key, val, indent + 1))
                elif isinstance(val, list):
                    if len(val) == 1 and isinstance(val[0], (str, int, float, bool)):
                        lines.append('%s    ("__list__";"%s")' % (pad, key))
                    if all(isinstance(v, (str, int, float, bool)) for v in val):
                        parts = []
                        for v in val:
                            if isinstance(v, bool):
                                parts.append('"true"' if v else '"false"')
                            elif isinstance(v, (int, float)):
                                parts.append(str(v))
                            else:
                                escaped = str(v).replace('"', '\\"').replace("\n", "\\n")
                                parts.append('"%s"' % escaped)
                        lines.append("%s    (\"%s\";%s)" % (pad, key, ";".join(parts)))
                    elif all(isinstance(v, dict) for v in val):
                        for i, item in enumerate(val):
                            lines.append(self.SerializeValue("%s_%d" % (key, i), item, indent + 1))
                    else:
                        parts = []
                        for v in val:
                            if isinstance(v, bool):
                                parts.append('"true"' if v else '"false"')
                            elif isinstance(v, (int, float)):
                                parts.append(str(v))
                            else:
                                escaped = str(v).replace('"', '\\"').replace("\n", "\\n")
                                parts.append('"%s"' % escaped)
                        lines.append("%s    (\"%s\";%s)" % (pad, key, ";".join(parts)))
                elif isinstance(val, bool):
                    lines.append('%s    ("%s";"%s")' % (pad, key, "true" if val else "false"))
                elif isinstance(val, (int, float)):
                    lines.append('%s    ("%s";%s)' % (pad, key, str(val)))
                elif isinstance(val, str):
                    escaped = val.replace('"', '\\"').replace("\n", "\\n")
                    lines.append('%s    ("%s";"%s")' % (pad, key, escaped))
                elif val is None:
                    lines.append('%s    ("%s";"")' % (pad, key))
        lines.append("%s}" % pad)
        return "\n".join(lines)

    def Deserialize(self, params):
        text = self._p(params, "text")
        if text is None:
            return (0, None, ("MISSING_PARAM", "text required", 0))
        tokenizer = BCLTokenizer()
        tok_rv = tokenizer.Run("tokenize", {"text": text})
        if tok_rv[0] != 1:
            return (0, None, ("TOKENIZE_ERROR", str(tok_rv[2]), 0))
        tokens = tok_rv[1]["tokens"]
        parser = BCLParser()
        parse_rv = parser.Run("parse", {"tokens": tokens})
        if parse_rv[0] != 1:
            return (0, None, ("PARSE_ERROR", str(parse_rv[2]), 0))
        root = parse_rv[1]["root"]
        children = root.state["children"]
        if not children:
            return (0, None, ("EMPTY_BCL", "No containers found in text", 0))
        result = self.DeserializeNode(children[0])
        return (1, result, None)

    def DeserializeNode(self, node):
        result = {}
        list_keys = set()
        for t in node.state["tuples"]:
            if not t:
                continue
            key = t[0]
            if key == "__list__":
                list_keys.add(t[1])
                continue
            if len(t) == 2:
                result[key] = t[1]
            elif len(t) >= 3:
                values = t[1:]
                if all(isinstance(v, (int, float)) for v in values):
                    result[key] = values[0]
                else:
                    result[key] = list(values)
        for lk in list_keys:
            if lk in result and not isinstance(result[lk], list):
                result[lk] = [result[lk]]
        for child in node.state["children"]:
            child_name = child.state["name"]
            if "_" in child_name and child_name.split("_")[-1].isdigit():
                base_key = "_".join(child_name.split("_")[:-1])
                if base_key not in result:
                    result[base_key] = []
                result[base_key].append(self.DeserializeNode(child))
            else:
                result[child_name] = self.DeserializeNode(child)
        return result


def dict_to_bcl(data, name="Root"):
    """Convenience function: dict to BCL text."""
    state = BCLState()
    rv = state.Serialize({"data": data, "name": name})
    return rv[1] if rv[0] == 1 else ""


def bcl_to_dict(text):
    """Convenience function: BCL text to dict."""
    state = BCLState()
    rv = state.Deserialize({"text": text})
    return rv[1] if rv[0] == 1 else {}


def list_to_bcl(items, name="List"):
    """Convenience function: list to BCL container."""
    state = BCLState()
    data = {name: items}
    rv = state.Serialize({"data": data, "name": name})
    return rv[1] if rv[0] == 1 else ""


def bcl_to_list(text):
    """Convenience function: BCL text to list (extracts first tuple values)."""
    d = bcl_to_dict(text)
    if not d:
        return []
    for key, val in d.items():
        if isinstance(val, list):
            return val
    return []
