#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_chat_compressor.py"
# date="2026-06-28" author="Cascade" session_id="bcl-chat-compression"
# context="Stage 1: Code-based BCL extraction from chat history .md files"}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="bcl_chat_compressor.py" domain="ChatMover" authority="BclChatCompressor"}
#[@SUMMARY]{summary="Stage 1 BCL chat compressor: parses .md chat exports, extracts structural tokens via regex/dict. No AI needed. Outputs preliminary BCL token file for AI semantic pass."}
#[@CLASS]{class="BclChatCompressor" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="compress" type="command"}
#[@METHOD]{method="parse_structure" type="command"}
#[@METHOD]{method="extract_errors" type="command"}
#[@METHOD]{method="extract_files" type="command"}
#[@METHOD]{method="extract_commands" type="command"}
#[@METHOD]{method="extract_frustration" type="command"}
#[@METHOD]{method="extract_code_blocks" type="command"}
#[@METHOD]{method="extract_questions" type="command"}
#[@METHOD]{method="detect_topic_boundaries" type="command"}
#[@METHOD]{method="format_output" type="command"}
#[@METHOD]{method="write_output" type="command"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import re
import sys
import hashlib
from datetime import datetime

FRUSTRATION_KEYWORDS = [
    "stuck", "frozen", "hang", "hung", "crash", "broke", "broken",
    "weird", "wrong", "why", "shit", "fuck", "damn", "hell",
    "not working", "doesn't work", "isn't working", "failed",
    "error", "bug", "issue", "problem", "annoying",
]

ERROR_PATTERNS = [
    (r"(\w*Error): (.+)", "python_error"),
    (r"Traceback \(most recent call last\):", "python_traceback"),
    (r"FAILED", "failed_marker"),
    (r"blocked", "blocked_marker"),
    (r"Permission denied", "permission_error"),
    (r"Command not found", "not_found_error"),
    (r"No such file or directory", "file_not_found"),
    (r"Segmentation fault", "segfault"),
]

FILE_PATH_PATTERNS = [
    r"(/[\w/\-]+\.py)",
    r"(/[\w/\-]+\.c)",
    r"(/[\w/\-]+\.md)",
    r"(/[\w/\-]+\.sh)",
    r"(/[\w/\-]+\.json)",
    r"(/[\w/\-]+\.sql)",
    r"(/[\w/\-]+\.yaml)",
    r"(/[\w/\-]+\.yml)",
]

USER_INPUT_HEADERS = [
    r"^### User Input",
    r"^### User",
    r"^## User",
    r"^User:",
    r"^> \*\*User",
]

AI_RESPONSE_HEADERS = [
    r"^### Planner Response",
    r"^### Assistant",
    r"^## Assistant",
    r"^AI:",
    r"^> \*\*Assistant",
]

COMMAND_ACCEPTED = r"\*User accepted command\*"
COMMAND_REJECTED = r"\*User rejected command\*"
COMMAND_PATTERN = r"```(?:bash|shell|sh)?\n(.*?)```"


class BclChatCompressor:
    """Stage 1: Code-based BCL extraction from chat .md files."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "min_lines": 500,
                "output_dir": "",
                "read_order": "bottom_up",
                "chronological": True,
                "inline_lessons": True,
                "extract_errors": True,
                "extract_files": True,
                "extract_commands": True,
                "extract_frustration": True,
                "extract_dialogue": True,
                "extract_questions": True,
                "cross_reference": True,
            },
            "source_path": None,
            "source_lines": [],
            "source_line_count": 0,
            "messages": [],
            "tokens": [],
            "stats": {},
            "output": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "compress":
            return self.Compress(params)
        elif command == "parse_structure":
            return self.ParseStructure(params)
        elif command == "extract_errors":
            return self.ExtractErrors(params)
        elif command == "extract_files":
            return self.ExtractFiles(params)
        elif command == "extract_commands":
            return self.ExtractCommands(params)
        elif command == "extract_frustration":
            return self.ExtractFrustration(params)
        elif command == "extract_code_blocks":
            return self.ExtractCodeBlocks(params)
        elif command == "extract_questions":
            return self.ExtractQuestions(params)
        elif command == "detect_topic_boundaries":
            return self.DetectTopicBoundaries(params)
        elif command == "format_output":
            return self.FormatOutput(params)
        elif command == "write_output":
            return self.WriteOutput(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Compress(self, params):
        input_path = self._p(params, "input_path")
        output_path = self._p(params, "output_path")
        dry_run = self._p(params, "dry_run", False)
        if not input_path:
            return (0, None, ("MISSING_PARAM", "input_path required", 0))

        rv = self._load_file(input_path)
        if rv[0] != 1:
            return rv

        if self.state["source_line_count"] < self.state["config"]["min_lines"]:
            return (0, None, ("TOO_SHORT",
                "File has %d lines, min is %d" % (
                    self.state["source_line_count"],
                    self.state["config"]["min_lines"]), 0))

        rv = self.ParseStructure(params)
        if rv[0] != 1:
            return rv

        self.state["tokens"] = []

        if self.state["config"]["extract_errors"]:
            self.ExtractErrors(params)
        if self.state["config"]["extract_files"]:
            self.ExtractFiles(params)
        if self.state["config"]["extract_commands"]:
            self.ExtractCommands(params)
        if self.state["config"]["extract_frustration"]:
            self.ExtractFrustration(params)
        if self.state["config"]["extract_dialogue"]:
            self.ExtractDialogue(params)
        if self.state["config"]["extract_questions"]:
            self.ExtractQuestions(params)

        self.DetectTopicBoundaries(params)

        self._compute_stats()

        rv = self.FormatOutput(params)
        if rv[0] != 1:
            return rv

        if dry_run:
            return (1, {
                "tokens": self.state["tokens"],
                "stats": self.state["stats"],
                "output": self.state["output"],
                "dry_run": True,
            }, None)

        if output_path:
            return self.WriteOutput({"output_path": output_path})
        return (1, {
            "tokens": self.state["tokens"],
            "stats": self.state["stats"],
            "output": self.state["output"],
        }, None)

    def _load_file(self, path):
        if not os.path.isfile(path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + path, 0))
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))
        self.state["source_path"] = path
        self.state["source_lines"] = content.splitlines()
        self.state["source_line_count"] = len(self.state["source_lines"])
        return (1, True, None)

    def ParseStructure(self, params):
        lines = self.state["source_lines"]
        messages = []
        current_role = None
        current_lines = []
        current_start = 0

        user_patterns = [re.compile(p, re.IGNORECASE) for p in USER_INPUT_HEADERS]
        ai_patterns = [re.compile(p, re.IGNORECASE) for p in AI_RESPONSE_HEADERS]

        for idx, line in enumerate(lines):
            is_user = any(p.match(line) for p in user_patterns)
            is_ai = any(p.match(line) for p in ai_patterns)

            if is_user or is_ai:
                if current_role is not None:
                    messages.append({
                        "role": current_role,
                        "lines": current_lines,
                        "start_line": current_start + 1,
                        "end_line": idx,
                        "text": "\n".join(current_lines),
                    })
                current_role = "user" if is_user else "ai"
                current_lines = []
                current_start = idx
            else:
                current_lines.append(line)

        if current_role is not None:
            messages.append({
                "role": current_role,
                "lines": current_lines,
                "start_line": current_start + 1,
                "end_line": len(lines),
                "text": "\n".join(current_lines),
            })

        self.state["messages"] = messages
        return (1, {"message_count": len(messages)}, None)

    def ExtractErrors(self, params):
        lines = self.state["source_lines"]
        errors = []
        for idx, line in enumerate(lines):
            for pattern, etype in ERROR_PATTERNS:
                m = re.search(pattern, line)
                if m:
                    error_text = m.group(0) if m.groups() else line.strip()
                    errors.append({
                        "type": "ERROR",
                        "line": idx + 1,
                        "error_type": etype,
                        "text": error_text[:200],
                    })
                    break
        self._add_tokens(errors)
        return (1, {"count": len(errors)}, None)

    def ExtractFiles(self, params):
        lines = self.state["source_lines"]
        seen = set()
        files = []
        for idx, line in enumerate(lines):
            for pattern in FILE_PATH_PATTERNS:
                for m in re.finditer(pattern, line):
                    path = m.group(1)
                    if path not in seen:
                        seen.add(path)
                        files.append({
                            "type": "FILE",
                            "line": idx + 1,
                            "path": path,
                        })
        self._add_tokens(files)
        return (1, {"count": len(files)}, None)

    def ExtractCommands(self, params):
        lines = self.state["source_lines"]
        commands = []
        for idx, line in enumerate(lines):
            if re.match(COMMAND_ACCEPTED, line.strip()):
                commands.append({
                    "type": "USER_APPROVED",
                    "line": idx + 1,
                })
            elif re.match(COMMAND_REJECTED, line.strip()):
                commands.append({
                    "type": "USER_REJECTED",
                    "line": idx + 1,
                })
        content = "\n".join(lines)
        for m in re.finditer(COMMAND_PATTERN, content, re.DOTALL):
            cmd = m.group(1).strip()
            if len(cmd) > 5:
                commands.append({
                    "type": "COMMAND_RAN",
                    "text": cmd[:200],
                })
        self._add_tokens(commands)
        return (1, {"count": len(commands)}, None)

    def ExtractFrustration(self, params):
        messages = self.state["messages"]
        signals = []
        for msg in messages:
            if msg["role"] != "user":
                continue
            text_lower = msg["text"].lower()
            for keyword in FRUSTRATION_KEYWORDS:
                if keyword in text_lower:
                    signals.append({
                        "type": "FRUSTRATION_SIGNAL",
                        "line": msg["start_line"],
                        "keyword": keyword,
                    })
                    break
        self._add_tokens(signals)
        return (1, {"count": len(signals)}, None)

    def ExtractCodeBlocks(self, params):
        lines = self.state["source_lines"]
        blocks = []
        in_block = False
        block_start = 0
        block_lang = ""
        block_lines = []
        for idx, line in enumerate(lines):
            if line.strip().startswith("```"):
                if in_block:
                    blocks.append({
                        "type": "CODE_BLOCK",
                        "start_line": block_start + 1,
                        "end_line": idx + 1,
                        "lang": block_lang,
                        "line_count": len(block_lines),
                    })
                    in_block = False
                    block_lines = []
                else:
                    in_block = True
                    block_start = idx
                    block_lang = line.strip()[3:].strip()
            elif in_block:
                block_lines.append(line)
        self._add_tokens(blocks)
        return (1, {"count": len(blocks)}, None)

    def ExtractDialogue(self, params):
        messages = self.state["messages"]
        dialogue = []
        for msg in messages:
            text = msg["text"].strip()
            if not text:
                continue
            first_line = text.split("\n")[0].strip()
            if msg["role"] == "user":
                dialogue.append({
                    "type": "USER_SAYS",
                    "line": msg["start_line"],
                    "text": first_line[:200],
                })
            else:
                dialogue.append({
                    "type": "AI_SAYS",
                    "line": msg["start_line"],
                    "text": first_line[:200],
                })
        self._add_tokens(dialogue)
        return (1, {"count": len(dialogue)}, None)

    def ExtractQuestions(self, params):
        messages = self.state["messages"]
        questions = []
        for msg in messages:
            if msg["role"] != "user":
                continue
            for line in msg["text"].split("\n"):
                line = line.strip()
                if "?" in line and len(line) > 10:
                    questions.append({
                        "type": "QUESTION",
                        "line": msg["start_line"],
                        "text": line[:200],
                    })
        self._add_tokens(questions)
        return (1, {"count": len(questions)}, None)

    def DetectTopicBoundaries(self, params):
        lines = self.state["source_lines"]
        topics = []
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("#") and not stripped.startswith("#[@"):
                heading = stripped.lstrip("#").strip()
                if heading and len(heading) > 3:
                    topics.append({
                        "type": "TOPIC",
                        "line": idx + 1,
                        "text": heading[:200],
                    })
        self._add_tokens(topics)
        return (1, {"count": len(topics)}, None)

    def _add_tokens(self, tokens):
        self.state["tokens"].extend(tokens)

    def _compute_stats(self):
        token_counts = {}
        for token in self.state["tokens"]:
            ttype = token["type"]
            token_counts[ttype] = token_counts.get(ttype, 0) + 1
        self.state["stats"] = {
            "source_lines": self.state["source_line_count"],
            "token_count": len(self.state["tokens"]),
            "token_types": token_counts,
            "message_count": len(self.state["messages"]),
        }

    def FormatOutput(self, params):
        source_path = self.state["source_path"] or "unknown"
        source_name = os.path.basename(source_path)
        source_lines = self.state["source_line_count"]
        stats = self.state["stats"]
        token_counts = stats.get("token_types", {})

        source_hash = hashlib.md5(open(source_path, "rb").read()).hexdigest()[:12] if os.path.isfile(source_path) else "auto"

        lines = []
        lines.append("#[@FILE]      %s path=%s" % (
            self._output_filename(source_name), source_path))
        lines.append("#[@FILEID]    md5=%s date=%s source=%s(%d_lines)" % (
            source_hash, datetime.now().strftime("%Y-%m-%d"), source_name, source_lines))
        lines.append("#[@SUMMARY]   BCL Stage 1 compression (code extraction). %d lines -> %d tokens." % (
            source_lines, stats.get("token_count", 0)))
        lines.append("#[@METHOD]    parse_structure -> regex_extraction -> dict_matching -> format_output")
        lines.append("#[@TOKENS]    Stage 1 only — AI semantic pass needed for [@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON] [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF]")
        lines.append("")
        lines.append("#[@CHAT]      source=%s lines=%d" % (source_name, source_lines))
        lines.append("#[@CHATSOURCE]{path=\"%s\";lines=%d;md5=%s;date=\"%s\"}" % (
            source_path, source_lines, source_hash, datetime.now().strftime("%Y-%m-%d")))
        lines.append("#[@CHATFULLIDEARS]{source=\"%s\";compressed_tokens=%d;compression_ratio=%.0f:1;stage=\"1_code_only\";stage2_needed=\"[@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON] [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF] [@MOOD] [@INTENT]\"}" % (
            source_name, stats.get("token_count", 0),
            source_lines / max(stats.get("token_count", 1), 1)))
        lines.append("")

        sorted_tokens = sorted(self.state["tokens"], key=lambda t: t.get("line", 0))

        current_line = 0
        for token in sorted_tokens:
            ttype = token["type"]
            tline = token.get("line", 0)
            if tline != current_line:
                lines.append("")
                current_line = tline

            if ttype == "USER_SAYS":
                lines.append("#[@USER_SAYS] L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "AI_SAYS":
                lines.append("#[@AI_SAYS]   L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "ERROR":
                lines.append("#[@ERROR]     L%d [%s] %s" % (tline, token.get("error_type", ""), token.get("text", "")))
            elif ttype == "FILE":
                lines.append("#[@FILE]      L%d %s" % (tline, token.get("path", "")))
            elif ttype == "COMMAND_RAN":
                lines.append("#[@COMMAND_RAN] %s" % token.get("text", ""))
            elif ttype == "USER_APPROVED":
                lines.append("#[@USER_APPROVED] L%d" % tline)
            elif ttype == "USER_REJECTED":
                lines.append("#[@USER_REJECTED] L%d" % tline)
            elif ttype == "FRUSTRATION_SIGNAL":
                lines.append("#[@FRUSTRATION_SIGNAL] L%d keyword=%s" % (tline, token.get("keyword", "")))
            elif ttype == "QUESTION":
                lines.append("#[@QUESTION]  L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "TOPIC":
                lines.append("#[@TOPIC]     L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "CODE_BLOCK":
                lines.append("#[@CODE_BLOCK] L%d-%d lang=%s lines=%d" % (
                    tline, token.get("end_line", tline), token.get("lang", ""), token.get("line_count", 0)))

        lines.append("")
        lines.append("# ============================================================")
        lines.append("# STAGE 1 STATS (code extraction only)")
        lines.append("# ============================================================")
        lines.append("#[@STATS]     source_lines=%d -> tokens=%d" % (
            source_lines, stats.get("token_count", 0)))
        for ttype, count in sorted(token_counts.items()):
            lines.append("#[@STATS]     %s=%d" % (ttype, count))
        lines.append("#[@STATS]     messages=%d" % stats.get("message_count", 0))
        lines.append("")
        lines.append("# ============================================================")
        lines.append("# STAGE 2 NEEDED — AI must extract:")
        lines.append("# ============================================================")
        lines.append("#[@NEEDED]    [@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON]")
        lines.append("#[@NEEDED]    [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF]")
        lines.append("#[@NEEDED]    [@MOOD] [@INTENT] [@AI_CORRECT] [@AI_WRONG]")
        lines.append("#[@NEEDED]    Pair problems with solutions, inline lessons under problems")
        lines.append("#[@NEEDED]    Output in chronological order with cause chain")

        self.state["output"] = "\n".join(lines)
        return (1, {"output_length": len(lines)}, None)

    def _output_filename(self, source_name):
        base, _ = os.path.splitext(source_name)
        return base + "_BCL.md"

    def WriteOutput(self, params):
        output_path = self._p(params, "output_path")
        if not output_path:
            source_path = self.state["source_path"]
            if source_path:
                base, _ = os.path.splitext(source_path)
                output_path = base + "_BCL.md"
            else:
                return (0, None, ("MISSING_PARAM", "output_path required", 0))

        output_dir = self.state["config"].get("output_dir", "")
        if output_dir:
            output_path = os.path.join(output_dir, os.path.basename(output_path))

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(self.state["output"])
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))
        return (1, {"output_path": output_path, "lines": len(self.state["output"].splitlines())}, None)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="BCL Chat Compressor — Stage 1 (code extraction)")
    parser.add_argument("--input", required=True, help="Input .md chat file path")
    parser.add_argument("--output", help="Output .md BCL file path (default: <input>_BCL.md)")
    parser.add_argument("--dry-run", action="store_true", help="Print output, don't write file")
    parser.add_argument("--min-lines", type=int, default=500, help="Minimum lines to compress")
    parser.add_argument("--output-dir", default="", help="Output directory override")
    args = parser.parse_args()

    compressor = BclChatCompressor(param={
        "min_lines": args.min_lines,
        "output_dir": args.output_dir,
    })

    rv = compressor.Run("compress", {
        "input_path": args.input,
        "output_path": args.output,
        "dry_run": args.dry_run,
    })

    if rv[0] == 1:
        data = rv[1]
        if data.get("dry_run"):
            print(data["output"])
            print("\n--- DRY RUN STATS ---", file=sys.stderr)
            stats = data["stats"]
            for key, value in sorted(stats.get("token_types", {}).items()):
                print("  %s = %d" % (key, value), file=sys.stderr)
            print("  total_tokens = %d" % stats.get("token_count", 0), file=sys.stderr)
            print("  source_lines = %d" % stats.get("source_lines", 0), file=sys.stderr)
        else:
            print("Output: %s (%d lines)" % (data.get("output_path", "?"), len(data.get("output", "").splitlines())), file=sys.stderr)
            stats = compressor.state["stats"]
            for key, value in sorted(stats.get("token_types", {}).items()):
                print("  %s = %d" % (key, value), file=sys.stderr)
            print("  total_tokens = %d" % stats.get("token_count", 0), file=sys.stderr)
    else:
        err = rv[2]
        print("ERROR: %s — %s" % (err[0], err[1]), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
