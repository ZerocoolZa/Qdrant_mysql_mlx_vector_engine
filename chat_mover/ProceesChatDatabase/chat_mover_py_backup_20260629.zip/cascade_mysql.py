"""
#[@GHOST]{("file_path=/Users/wws/Downloads/cascade_mysql_ingest.py";"identity=Cascade Mysql Ingest";"purpose=Decrypt Windsurf Cascade .pb files and ingest conversations into MySQL.";"date=2026-06-26";"version=1.0";"author=Cascade";"chat_link=mysql://devin/devin_sessions?id=mirror-theory")}
#[@VBSTYLE]{("auth=Cascade";"role=tool";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete")}
#[@FILEID]{("session_id=mirror-theory";"context=Windsurf Decryption + ChatGPT Export + Anti-Collapse System";"purpose=Decrypt Windsurf Cascade .pb files and ingest conversations into MySQL.")}
#[@SUMMARY]{("Created during Windsurf Decryption + ChatGPT Export + Anti-Collapse System session on 2026-06-26")}
"""

#!/usr/bin/env python3
"""Decrypt Windsurf Cascade .pb files and ingest conversations into MySQL.

Uses the decryption and parsing tools from windsurf_decryption_tool.
Creates a `cascade_chats` database with tables for trajectories, rounds, and messages.

Usage:
    python3 cascade_mysql_ingest.py                    # Decrypt + ingest all
    python3 cascade_mysql_ingest.py --decrypt-only     # Just decrypt to /tmp
    python3 cascade_mysql_ingest.py --status           # Show DB stats
"""
import os
import sys
import json
import time
import argparse
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path("/Users/wws/Downloads/windsurf_decryption_tool/tools")))

from decrypt_pb import decrypt_one
from scan_trajectory import parse_trajectory, parse_step, parse_checkpoint, iter_fields
from export_md import (
    read_string_field, split_into_rounds,
    VARIANT_USER_INPUT, VARIANT_PLANNER_RESPONSE, VARIANT_RUN_COMMAND,
    VARIANT_CHECKPOINT, VARIANT_FILE_CONTEXT, VARIANT_COMMAND_RESULT,
)

CASCADE_DIR = os.path.expanduser("~/.codeium/windsurf/cascade")
DECRYPTED_DIR = "/tmp/cascade_decrypted"

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "cascade_chats",
    "charset": "utf8mb4",
}


SCHEMA_SQL = """
CREATE DATABASE IF NOT EXISTS cascade_chats CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE cascade_chats;

CREATE TABLE IF NOT EXISTS trajectories (
    id VARCHAR(128) PRIMARY KEY,
    cascade_id VARCHAR(128),
    file_name VARCHAR(255),
    trajectory_type INT,
    source INT,
    step_count INT,
    round_count INT,
    first_prompt TEXT,
    ingested_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rounds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trajectory_id VARCHAR(128) NOT NULL,
    round_number INT NOT NULL,
    start_step INT,
    end_step INT,
    step_count INT,
    prompt TEXT,
    prompt_slug VARCHAR(120),
    UNIQUE KEY uniq_round (trajectory_id, round_number),
    INDEX idx_traj (trajectory_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trajectory_id VARCHAR(128) NOT NULL,
    round_id INT,
    step_index INT NOT NULL,
    role ENUM('user','assistant','tool','checkpoint','file_context','command_result','other') NOT NULL,
    variant_field INT,
    step_type INT,
    content LONGTEXT,
    internal_planning LONGTEXT,
    command TEXT,
    command_output LONGTEXT,
    file_uri TEXT,
    word_count INT DEFAULT 0,
    char_count INT DEFAULT 0,
    INDEX idx_traj (trajectory_id),
    INDEX idx_round (round_id),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""


def CountWords(text):
    if not text:
        return 0
    return len(text.split())


def Slugify(s, max_len=60):
    s = (s or "").strip().splitlines()[0] if s else ""
    import re
    s = re.sub(r"[\s/\\]+", "-", s)
    s = re.sub(r"[^\w\-]", "", s)
    s = s.strip("-")
    if not s:
        s = "untitled"
    if len(s) > max_len:
        s = s[:max_len].rstrip("-")
    return s


def DecryptAll():
    cascade_path = Path(CASCADE_DIR)
    out_path = Path(DECRYPTED_DIR)
    out_path.mkdir(parents=True, exist_ok=True)

    results = []
    for pb_file in sorted(cascade_path.glob("*.pb")):
        try:
            pt = decrypt_one(pb_file)
            bin_path = out_path / (pb_file.stem + ".bin")
            bin_path.write_bytes(pt)
            results.append((pb_file.name, bin_path, len(pt)))
        except Exception as e:
            sys.stderr.write(f"FAIL {pb_file.name}: {e}\n")
    return results


def ExtractMessagesFromRound(steps):
    messages = []
    for step_idx, step_dict in steps:
        vf = step_dict["variant_field"]
        data = step_dict["variant_data"] or b""
        step_type = step_dict["type"]

        if vf == VARIANT_USER_INPUT:
            prompt = read_string_field(data, 2) or ""
            messages.append({
                "step_index": step_idx,
                "role": "user",
                "variant_field": vf,
                "step_type": step_type,
                "content": prompt,
            })
        elif vf == VARIANT_PLANNER_RESPONSE:
            user_facing = read_string_field(data, 1) or ""
            internal = read_string_field(data, 3) or ""
            messages.append({
                "step_index": step_idx,
                "role": "assistant",
                "variant_field": vf,
                "step_type": step_type,
                "content": user_facing,
                "internal_planning": internal if internal != user_facing else "",
            })
        elif vf == VARIANT_RUN_COMMAND:
            cmd = read_string_field(data, 23) or read_string_field(data, 25) or ""
            output = ""
            for fno, wt, _, val in iter_fields(data):
                if fno == 24 and wt == 2:
                    try:
                        output = val.decode("utf-8", errors="replace")
                    except Exception:
                        pass
                    break
            messages.append({
                "step_index": step_idx,
                "role": "tool",
                "variant_field": vf,
                "step_type": step_type,
                "command": cmd,
                "command_output": output,
            })
        elif vf == VARIANT_CHECKPOINT:
            cp = parse_checkpoint(data)
            messages.append({
                "step_index": step_idx,
                "role": "checkpoint",
                "variant_field": vf,
                "step_type": step_type,
                "content": cp.get("user_intent") or "",
                "internal_planning": cp.get("session_summary") or "",
            })
        elif vf == VARIANT_FILE_CONTEXT:
            uri = read_string_field(data, 1) or ""
            messages.append({
                "step_index": step_idx,
                "role": "file_context",
                "variant_field": vf,
                "step_type": step_type,
                "file_uri": uri,
            })
        elif vf == VARIANT_COMMAND_RESULT:
            step_ref = read_string_field(data, 1) or ""
            output = read_string_field(data, 9) or ""
            messages.append({
                "step_index": step_idx,
                "role": "command_result",
                "variant_field": vf,
                "step_type": step_type,
                "content": output,
                "command": f"result of step #{step_ref}",
            })
        else:
            messages.append({
                "step_index": step_idx,
                "role": "other",
                "variant_field": vf,
                "step_type": step_type,
                "content": f"[tool: variant_field={vf} type={step_type} {len(data)} bytes]",
            })
    return messages


def IngestAll():
    import mysql.connector

    conn = mysql.connector.connect(
        host=DB_CONFIG["host"], user=DB_CONFIG["user"],
        password=DB_CONFIG["password"], charset=DB_CONFIG["charset"],
    )
    cursor = conn.cursor()

    for stmt in SCHEMA_SQL.split(";"):
        s = stmt.strip()
        if s:
            cursor.execute(s)
    conn.commit()
    cursor.close()
    conn.close()

    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(prepared=True)

    bin_files = sorted(Path(DECRYPTED_DIR).glob("*.bin"))
    total_traj = 0
    total_rounds = 0
    total_msgs = 0

    for bin_path in bin_files:
        buf = bin_path.read_bytes()
        info = parse_trajectory(buf)
        traj_id = info["trajectory_id"] or bin_path.stem
        cascade_id = info["cascade_id"] or bin_path.stem
        # Sanitize: if trajectory_id is not a clean UUID, fall back to filename stem
        if traj_id and (len(traj_id) > 64 or not all(c in "0123456789abcdef-" for c in traj_id.lower())):
            traj_id = bin_path.stem
        if cascade_id and (len(cascade_id) > 64 or not all(c in "0123456789abcdef-" for c in cascade_id.lower())):
            cascade_id = bin_path.stem
        rounds = split_into_rounds(info["steps"])

        first_prompt = ""
        for r in rounds:
            if r["prompt"]:
                first_prompt = r["prompt"][:500]
                break

        cursor.execute("""
            INSERT INTO trajectories (id, cascade_id, file_name, trajectory_type, source, step_count, round_count, first_prompt)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                cascade_id=VALUES(cascade_id), file_name=VALUES(file_name),
                trajectory_type=VALUES(trajectory_type), source=VALUES(source),
                step_count=VALUES(step_count), round_count=VALUES(round_count),
                first_prompt=VALUES(first_prompt)
        """, (traj_id, cascade_id, bin_path.name, info["trajectory_type"],
              info["source"], info["steps_count"], len(rounds), first_prompt))
        total_traj += 1

        for round_num, r in enumerate(rounds, start=1):
            prompt = r["prompt"] or ""
            slug = Slugify(prompt) if prompt else "prelude"
            step_count = r["end_step"] - r["start_step"] + 1

            cursor.execute("""
                INSERT INTO rounds (trajectory_id, round_number, start_step, end_step, step_count, prompt, prompt_slug)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    start_step=VALUES(start_step), end_step=VALUES(end_step),
                    step_count=VALUES(step_count), prompt=VALUES(prompt), prompt_slug=VALUES(prompt_slug)
            """, (traj_id, round_num, r["start_step"], r["end_step"], step_count, prompt, slug))

            cursor.execute("SELECT id FROM rounds WHERE trajectory_id=%s AND round_number=%s", (traj_id, round_num))
            round_id = cursor.fetchone()[0]
            total_rounds += 1

            messages = ExtractMessagesFromRound(r["parsed_steps"])
            for msg in messages:
                content = msg.get("content", "")
                internal = msg.get("internal_planning", "")
                cmd = msg.get("command", "")
                cmd_out = msg.get("command_output", "")
                file_uri = msg.get("file_uri", "")

                all_text = " ".join(filter(None, [content, internal, cmd, cmd_out]))
                wc = CountWords(all_text)
                cc = len(all_text)

                cursor.execute("""
                    INSERT INTO messages (trajectory_id, round_id, step_index, role, variant_field, step_type,
                        content, internal_planning, command, command_output, file_uri, word_count, char_count)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (traj_id, round_id, msg["step_index"], msg["role"],
                      msg["variant_field"], msg["step_type"],
                      content, internal, cmd, cmd_out, file_uri, wc, cc))
                total_msgs += 1

        conn.commit()
        sys.stderr.write(f"  {bin_path.name}: {len(rounds)} rounds, {sum(len(ExtractMessagesFromRound(r['parsed_steps'])) for r in rounds)} messages\n")

    cursor.close()
    conn.close()

    sys.stderr.write(f"\nIngested: {total_traj} trajectories, {total_rounds} rounds, {total_msgs} messages\n")
    return total_traj, total_rounds, total_msgs


def ShowStatus():
    import mysql.connector
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM trajectories")
    trajs = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM rounds")
    rounds = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM messages")
    msgs = cursor.fetchone()[0]
    cursor.execute("SELECT SUM(word_count) FROM messages")
    words = cursor.fetchone()[0] or 0
    cursor.execute("SELECT SUM(char_count) FROM messages")
    chars = cursor.fetchone()[0] or 0

    cursor.execute("SELECT role, COUNT(*) FROM messages GROUP BY role ORDER BY COUNT(*) DESC")
    role_counts = cursor.fetchall()

    cursor.execute("SELECT id, cascade_id, round_count, step_count, LEFT(first_prompt, 80) FROM trajectories ORDER BY ingested_at")
    traj_list = cursor.fetchall()

    sys.stderr.write(f"\n{'='*60}\n")
    sys.stderr.write(f"CASCADE CHATS — MySQL DATABASE STATUS\n")
    sys.stderr.write(f"{'='*60}\n")
    sys.stderr.write(f"  Database:      {DB_CONFIG['database']}\n")
    sys.stderr.write(f"  Trajectories:  {trajs}\n")
    sys.stderr.write(f"  Rounds:        {rounds}\n")
    sys.stderr.write(f"  Messages:      {msgs:,}\n")
    sys.stderr.write(f"  Words:         {words:,}\n")
    sys.stderr.write(f"  Characters:    {chars:,}\n")
    sys.stderr.write(f"\n  Messages by role:\n")
    for role, count in role_counts:
        sys.stderr.write(f"    {role:20s}: {count:,}\n")
    sys.stderr.write(f"\n  Trajectories:\n")
    for tid, cid, rc, sc, fp in traj_list:
        sys.stderr.write(f"    {tid[:36]:36s}  {rc:3d} rounds  {sc:4d} steps  {fp or '(no prompt)'}\n")
    sys.stderr.write(f"{'='*60}\n")

    cursor.close()
    conn.close()


def main():
    parser = argparse.ArgumentParser(description="Decrypt and ingest Cascade .pb files into MySQL")
    parser.add_argument("--decrypt-only", action="store_true", help="Only decrypt, don't ingest")
    parser.add_argument("--status", action="store_true", help="Show database stats")
    parser.add_argument("--cascade-dir", default=CASCADE_DIR, help="Cascade .pb directory")
    args = parser.parse_args()

    if args.status:
        ShowStatus()
        return

    sys.stderr.write("Step 1: Decrypting .pb files...\n")
    results = DecryptAll()
    sys.stderr.write(f"  Decrypted {len(results)} files to {DECRYPTED_DIR}\n")

    if args.decrypt_only:
        for name, path, size in results:
            sys.stderr.write(f"  {name} -> {path} ({size:,} bytes)\n")
        return

    sys.stderr.write("\nStep 2: Creating schema and ingesting into MySQL...\n")
    IngestAll()

    sys.stderr.write("\nStep 3: Final status:\n")
    ShowStatus()


if __name__ == "__main__":
    main()
