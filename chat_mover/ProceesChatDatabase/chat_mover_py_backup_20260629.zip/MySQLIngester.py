"""
#[@GHOST]{("file_path=/Users/wws/Downloads/ChatGPTManager/MySQLIngester.py";"identity=MySQLIngester";"purpose=Load ChatGPT conversations from JSON files into MySQL database";"date=2026-06-26";"version=1.0";"author=Devin";"chat_link=mysql://devin/devin_chat_turns?session_id=bottled-tarsier")}
#[@VBSTYLE]{("auth=Devin";"role=domain_ingest";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("MySQLIngester")}
#[@METHODS]{("Run";"Ingest";"Status";"_Connect";"_Close";"_IngestConversation";"_CountWords";"_EstimateTokens";"_TimeToDate";"read_state";"set_config";"_p")}
#[@DOMAIN]{("ingest")}
"""

import os
import json
import time
from datetime import datetime, timezone
from typing import Any, Dict, Tuple

from Config import DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_CHARSET, ACCOUNT_EMAIL, CHATS_DIR
from ChatGPTFetcher import ChatGPTFetcher


class MySQLIngester:
    """Authority for loading ChatGPT conversations into MySQL."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "db_host": DB_HOST,
                "db_user": DB_USER,
                "db_password": DB_PASSWORD,
                "db_name": DB_NAME,
                "db_charset": DB_CHARSET,
                "account_email": ACCOUNT_EMAIL,
                "chats_dir": CHATS_DIR,
                "commit_batch": 50
            },
            "catalog": [],
            "results": [],
            "memunit": mem,
            "db_manager": db,
            "conn": None,
            "cursor": None
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "ingest":
            return self.Ingest(params)
        elif command == "status":
            return self.Status(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        else:
            return (0, None, ("UNKNOWN_COMMAND", f"Unknown command: {command}", 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params):
        snapshot = dict(self.state)
        snapshot["conn"] = "connected" if self.state["conn"] else "disconnected"
        return (1, snapshot, None)

    def set_config(self, params):
        try:
            for key, value in params.items():
                self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("SET_CONFIG_ERROR", str(e), 0))

    def _Connect(self, params):
        try:
            import mysql.connector
            cfg = self.state["config"]
            self.state["conn"] = mysql.connector.connect(
                host=cfg["db_host"],
                user=cfg["db_user"],
                password=cfg["db_password"],
                database=cfg["db_name"],
                charset=cfg["db_charset"]
            )
            self.state["cursor"] = self.state["conn"].cursor(prepared=True)
            return (1, True, None)
        except Exception as e:
            return (0, None, ("CONNECT_ERROR", str(e), 0))

    def _Close(self, params):
        try:
            if self.state["cursor"]:
                self.state["cursor"].close()
                self.state["cursor"] = None
            if self.state["conn"]:
                self.state["conn"].close()
                self.state["conn"] = None
            return (1, True, None)
        except Exception as e:
            return (0, None, ("CLOSE_ERROR", str(e), 0))

    def _CountWords(self, params):
        text = self.state["p"](params, "text", "")
        if not text:
            return (1, 0, None)
        return (1, len(text.split()), None)

    def _EstimateTokens(self, params):
        text = self.state["p"](params, "text", "")
        if not text:
            return (1, 0, None)
        return (1, len(text) // 4, None)

    def _TimeToDate(self, params):
        t = self.state["p"](params, "time", None)
        if t is None:
            return (1, None, None)
        try:
            return (1, datetime.fromtimestamp(float(t), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), None)
        except (ValueError, TypeError, OSError):
            return (1, None, None)

    def _IngestConversation(self, params):
        try:
            conv_data = self.state["p"](params, "conv_data", {})
            conv_id = conv_data.get("id") or conv_data.get("conversation_id") or ""
            if not conv_id:
                return (0, None, ("NO_CONV_ID", "Conversation has no ID", 0))

            title = conv_data.get("title", "Untitled")
            create_time = conv_data.get("create_time")
            update_time = conv_data.get("update_time")

            ok, create_date, _ = self._TimeToDate({"time": create_time})
            ok, update_date, _ = self._TimeToDate({"time": update_time})

            is_archived = 1 if conv_data.get("is_archived") else 0
            is_starred = 1 if conv_data.get("is_starred") else 0
            is_temporary = 1 if conv_data.get("is_temporary_chat") else 0

            fetcher = ChatGPTFetcher(param={"token": "", "cookies": {}})
            ok, messages, _ = fetcher.ExtractMessages({"conv_detail": conv_data})
            msg_count = len(messages)

            total_words = 0
            total_tokens = 0
            for m in messages:
                ok, wc, _ = self._CountWords({"text": m["text"]})
                ok, tc, _ = self._EstimateTokens({"text": m["text"]})
                total_words += wc
                total_tokens += tc

            model_slug = ""
            for m in messages:
                if m["role"] == "assistant" and m["model_slug"]:
                    model_slug = m["model_slug"]
                    break

            cursor = self.state["cursor"]
            account_email = self.state["config"]["account_email"]

            cursor.execute("""
                INSERT INTO conversations
                    (id, title, create_time, create_date, update_time, update_date,
                     model_slug, is_archived, is_starred, is_temporary,
                     message_count, word_count, token_count, account_email, source)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'local')
                ON DUPLICATE KEY UPDATE
                    title=VALUES(title), create_time=VALUES(create_time),
                    create_date=VALUES(create_date), update_time=VALUES(update_time),
                    update_date=VALUES(update_date), model_slug=VALUES(model_slug),
                    is_archived=VALUES(is_archived), is_starred=VALUES(is_starred),
                    is_temporary=VALUES(is_temporary),
                    message_count=VALUES(message_count), word_count=VALUES(word_count),
                    token_count=VALUES(token_count), account_email=VALUES(account_email)
            """, (conv_id, title, create_time, create_date, update_time, update_date,
                  model_slug, is_archived, is_starred, is_temporary,
                  msg_count, total_words, total_tokens, account_email))

            cursor.execute("DELETE FROM messages WHERE conversation_id=%s", (conv_id,))

            for m in messages:
                ok, m_date, _ = self._TimeToDate({"time": m["create_time"]})
                ok, wc, _ = self._CountWords({"text": m["text"]})
                ok, tc, _ = self._EstimateTokens({"text": m["text"]})
                cursor.execute("""
                    INSERT INTO messages
                        (conversation_id, node_id, role, content_type, author_name,
                         text, word_count, token_count, create_time, create_date, model_slug)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (conv_id, m["node_id"], m["role"], m["content_type"],
                      "", m["text"], wc, tc,
                      m["create_time"], m_date, m["model_slug"]))

            return (1, {"conv_id": conv_id, "msg_count": msg_count}, None)
        except Exception as e:
            return (0, None, ("INGEST_CONV_ERROR", str(e), 0))

    def Ingest(self, params):
        try:
            chats_dir = self.state["p"](params, "chats_dir", self.state["config"]["chats_dir"])
            commit_batch = self.state["config"]["commit_batch"]

            if not os.path.isdir(chats_dir):
                return (0, None, ("NO_DIR", f"Chats directory not found: {chats_dir}", 0))

            json_files = sorted([f for f in os.listdir(chats_dir) if f.endswith(".json")])

            ok, _, error = self._Connect({})
            if not ok:
                return (0, None, error)

            cursor = self.state["cursor"]
            conn = self.state["conn"]

            cursor.execute("SELECT COUNT(*) FROM conversations")
            existing_convs = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM messages")
            existing_msgs = cursor.fetchone()[0]

            ingested = 0
            failed = 0
            total_msgs = 0
            total_words = 0
            start_time = time.time()

            for i, fname in enumerate(json_files):
                fpath = os.path.join(chats_dir, fname)
                try:
                    with open(fpath) as f:
                        data = json.load(f)

                    ok, result, error = self._IngestConversation({"conv_data": data})
                    if ok:
                        total_msgs += result["msg_count"]
                        fetcher = ChatGPTFetcher(param={"token": "", "cookies": {}})
                        ok, messages, _ = fetcher.ExtractMessages({"conv_detail": data})
                        for m in messages:
                            ok, wc, _ = self._CountWords({"text": m["text"]})
                            total_words += wc
                        ingested += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1

                if (i + 1) % commit_batch == 0:
                    conn.commit()

            conn.commit()
            elapsed = time.time() - start_time

            cursor.execute("SELECT COUNT(*) FROM conversations")
            final_convs = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM messages")
            final_msgs = cursor.fetchone()[0]
            cursor.execute("SELECT SUM(word_count) FROM messages")
            final_words = cursor.fetchone()[0] or 0

            self._Close({})

            self.state["results"] = {
                "ingested": ingested,
                "failed": failed,
                "total_msgs": total_msgs,
                "total_words": total_words,
                "elapsed_seconds": round(elapsed, 2),
                "final_convs": final_convs,
                "final_msgs": final_msgs,
                "final_words": final_words
            }
            return (1, self.state["results"], None)
        except Exception as e:
            return (0, None, ("INGEST_ERROR", str(e), 0))

    def Status(self, params):
        try:
            ok, _, error = self._Connect({})
            if not ok:
                return (0, None, error)

            cursor = self.state["cursor"]
            cursor.execute("SELECT COUNT(*) FROM conversations")
            convs = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM messages")
            msgs = cursor.fetchone()[0]
            cursor.execute("SELECT SUM(word_count) FROM messages")
            words = cursor.fetchone()[0] or 0
            cursor.execute("SELECT SUM(token_count) FROM messages")
            tokens = cursor.fetchone()[0] or 0
            cursor.execute("SELECT COUNT(DISTINCT account_email) FROM conversations")
            accounts = cursor.fetchone()[0]

            self._Close({})

            status = {
                "conversations": convs,
                "messages": msgs,
                "words": words,
                "tokens": tokens,
                "accounts": accounts
            }
            self.state["results"] = status
            return (1, status, None)
        except Exception as e:
            return (0, None, ("STATUS_ERROR", str(e), 0))
