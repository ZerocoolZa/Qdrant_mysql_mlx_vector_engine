"""
#[@GHOST]{("file_path=/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/Config_devin_sync.py";"identity=DevinSyncConfig";"purpose=Configuration constants for Devin session SQLite-to-MySQL sync";"date=2026-06-29";"version=1.0";"author=Devin";"chat_link=")}
#[@VBSTYLE]{("auth=Devin";"role=domain_config";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded|no_tabs|no_self_underscore";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("DevinSyncConfig")}
#[@METHODS]{("__init__";"Run";"read_state";"set_config";"_p";"GetDevinPaths";"GetMysqlConfig")}
#[@DOMAIN]{("config")}
"""

import os
from typing import Tuple


ENV_DEFAULTS = {
    "DEVIN_SQLITE_DB": "DEVIN_SYNC_SQLITE_DB",
    "DEVIN_SUMMARIES_DIR": "DEVIN_SYNC_SUMMARIES_DIR",
    "DEVIN_TRANSCRIPTS_DIR": "DEVIN_SYNC_TRANSCRIPTS_DIR",
    "SQLITE3_EXE": "DEVIN_SYNC_SQLITE3_EXE",
    "DB_HOST": "DEVIN_SYNC_DB_HOST",
    "DB_PORT": "DEVIN_SYNC_DB_PORT",
    "DB_USER": "DEVIN_SYNC_DB_USER",
    "DB_PASSWORD": "DEVIN_SYNC_DB_PASSWORD",
    "DB_NAME": "DEVIN_SYNC_DB_NAME",
    "DB_CHARSET": "DEVIN_SYNC_DB_CHARSET",
    "MAX_RETRIES": "DEVIN_SYNC_MAX_RETRIES",
    "INITIAL_BACKOFF": "DEVIN_SYNC_INITIAL_BACKOFF",
    "BATCH_SIZE": "DEVIN_SYNC_BATCH_SIZE",
    "KILL_DEVIN": "DEVIN_SYNC_KILL_DEVIN",
}


class DevinSyncConfig:
    """Authority for Devin sync configuration."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": self._BuildConfig(),
            "results": [],
            "memunit": mem,
            "db_manager": db,
        }
        if param and isinstance(param, dict):
            for key, value in param.items():
                self.state["config"][key] = value

    def _BuildConfig(self):
        devin_base = os.environ.get("DEVIN_CLI_HOME", os.path.expanduser("~/.local/share/devin/cli"))
        return {
            "DEVIN_SQLITE_DB": os.environ.get(
                ENV_DEFAULTS["DEVIN_SQLITE_DB"],
                os.path.join(devin_base, "sessions.db"),
            ),
            "DEVIN_SUMMARIES_DIR": os.environ.get(
                ENV_DEFAULTS["DEVIN_SUMMARIES_DIR"],
                os.path.join(devin_base, "summaries"),
            ),
            "DEVIN_TRANSCRIPTS_DIR": os.environ.get(
                ENV_DEFAULTS["DEVIN_TRANSCRIPTS_DIR"],
                os.path.join(devin_base, "transcripts"),
            ),
            "SQLITE3_EXE": os.environ.get(ENV_DEFAULTS["SQLITE3_EXE"], "sqlite3"),
            "DB_HOST": os.environ.get(ENV_DEFAULTS["DB_HOST"], "localhost"),
            "DB_PORT": int(os.environ.get(ENV_DEFAULTS["DB_PORT"], "3306")),
            "DB_USER": os.environ.get(ENV_DEFAULTS["DB_USER"], "root"),
            "DB_PASSWORD": os.environ.get(ENV_DEFAULTS["DB_PASSWORD"], ""),
            "DB_NAME": os.environ.get(ENV_DEFAULTS["DB_NAME"], "devin"),
            "DB_CHARSET": os.environ.get(ENV_DEFAULTS["DB_CHARSET"], "utf8mb4"),
            "MAX_RETRIES": int(os.environ.get(ENV_DEFAULTS["MAX_RETRIES"], "5")),
            "INITIAL_BACKOFF": float(os.environ.get(ENV_DEFAULTS["INITIAL_BACKOFF"], "1.0")),
            "BATCH_SIZE": int(os.environ.get(ENV_DEFAULTS["BATCH_SIZE"], "500")),
            "KILL_DEVIN": os.environ.get(ENV_DEFAULTS["KILL_DEVIN"], "0") == "1",
        }

    def Run(self, command, params=None):
        params = params or {}
        if command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        elif command == "mysql_config":
            return self.GetMysqlConfig(params)
        elif command == "devin_paths":
            return self.GetDevinPaths(params)
        else:
            return (0, None, ("UNKNOWN_COMMAND", f"Unknown command: {command}", 0))

    def _p(self, params, key, default=None):
        if not params or not isinstance(params, dict):
            return default
        return params.get(key, default)

    def read_state(self, params):
        return (1, dict(self.state["config"]), None)

    def set_config(self, params):
        try:
            if not params or not isinstance(params, dict):
                return (0, None, ("SET_CONFIG_ERROR", "param dict required", 0))
            for key, value in params.items():
                self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("SET_CONFIG_ERROR", str(e), 0))

    def GetDevinPaths(self, params):
        cfg = self.state["config"]
        return (1, {
            "sqlite_db": cfg["DEVIN_SQLITE_DB"],
            "summaries_dir": cfg["DEVIN_SUMMARIES_DIR"],
            "transcripts_dir": cfg["DEVIN_TRANSCRIPTS_DIR"],
        }, None)

    def GetMysqlConfig(self, params):
        cfg = self.state["config"]
        return (1, {
            "host": cfg["DB_HOST"],
            "port": cfg["DB_PORT"],
            "user": cfg["DB_USER"],
            "password": cfg["DB_PASSWORD"],
            "database": cfg["DB_NAME"],
            "charset": cfg["DB_CHARSET"],
            "autocommit": True,
            "connection_timeout": 10,
        }, None)
