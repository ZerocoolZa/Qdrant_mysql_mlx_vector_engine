#!/usr/bin/env python3
"""Generic protobuf wire-format scanner for decrypted Cascade trajectories.

Goals:
1. Parse CortexTrajectory wire-format (no schema compilation needed)
2. Count CortexStepType distribution within trajectory.steps
3. Identify CHECKPOINT steps (type 56) and dump their content
4. Surface user_intent / session_summary / code_change_summary text
"""
import sys
import struct
from pathlib import Path

# CortexStepType enum values from proto schema reconstruction
# These are sequential — values inferred from the order step variants appear in CortexTrajectoryStep.step oneof
# We'll mostly use raw integer values
STEP_TYPE_NAMES = {
    0: "UNSPECIFIED",
    # The numeric mapping isn't 1:1 with oneof index — these are from the enum
    # We'll just print numeric and look up later
}

# Known: CORTEX_STEP_TYPE_CHECKPOINT — need to find numeric value
# From string scans, type=27 or similar — we'll discover empirically

def read_varint(buf, pos):
    """Read a varint. Return (value, new_pos)."""
    val = 0
    shift = 0
    while pos < len(buf):
        b = buf[pos]
        pos += 1
        val |= (b & 0x7F) << shift
        if not (b & 0x80):
            return val, pos
        shift += 7
    raise ValueError("unterminated varint")


def parse_tag(tag):
    """Return (field_no, wire_type)."""
    return tag >> 3, tag & 7


def skip_value(buf, pos, wire_type):
    """Skip a single field value."""
    if wire_type == 0:  # varint
        _, pos = read_varint(buf, pos)
    elif wire_type == 1:  # 64-bit
        pos += 8
    elif wire_type == 2:  # length-delimited
        length, pos = read_varint(buf, pos)
        pos += length
    elif wire_type == 5:  # 32-bit
        pos += 4
    elif wire_type == 3:  # start group (deprecated)
        while True:
            t, pos = read_varint(buf, pos)
            f, wt = parse_tag(t)
            if wt == 4:
                return pos
            pos = skip_value(buf, pos, wt)
    else:
        raise ValueError(f"unknown wire type {wire_type}")
    return pos


def iter_fields(buf, start=0, end=None):
    """Yield (field_no, wire_type, value_offset, value_length_or_data) over a message."""
    if end is None:
        end = len(buf)
    pos = start
    while pos < end:
        tag, pos = read_varint(buf, pos)
        fno, wt = parse_tag(tag)
        if wt == 0:
            val, new_pos = read_varint(buf, pos)
            yield fno, wt, pos, val
            pos = new_pos
        elif wt == 1:
            yield fno, wt, pos, buf[pos:pos+8]
            pos += 8
        elif wt == 2:
            length, lpos = read_varint(buf, pos)
            yield fno, wt, lpos, buf[lpos:lpos+length]
            pos = lpos + length
        elif wt == 5:
            yield fno, wt, pos, buf[pos:pos+4]
            pos += 4
        else:
            raise ValueError(f"wire type {wt} unsupported at {pos}")


def parse_trajectory(buf):
    """Parse top-level CortexTrajectory and yield step messages (as raw bytes).

    Handles two formats:
      1. Standard CortexTrajectory (fields 1=id, 2=steps, 4=type, 6=cascade_id, 8=source)
      2. Implicit trajectory — wraps CortexTrajectory inside top-level field 1
         (field 1 contains a nested CortexTrajectory message)
    """
    # CortexTrajectory fields (from proto schema reconstruction):
    #   1: trajectory_id (string)
    #   2: steps (repeated CortexTrajectoryStep) ← what we want
    #   3: generator_metadata
    #   4: trajectory_type (enum)
    #   6: cascade_id
    #   7: metadata
    #   8: source (enum)
    info = {
        'trajectory_id': None,
        'cascade_id': None,
        'trajectory_type': None,
        'source': None,
        'steps_count': 0,
        'steps': [],
    }

    # First pass: check if this is the implicit format (field 1 contains nested message)
    # The implicit format has only field 1 (wt=2) and field 5 (wt=2) at top level,
    # and field 1's content itself is a CortexTrajectory message.
    top_fields = list(iter_fields(buf))
    has_top_steps = any(f == 2 and w == 2 for f, w, _, _ in top_fields)

    if not has_top_steps:
        # Implicit format: parse the nested CortexTrajectory inside field 1
        for fno, wt, off, val in top_fields:
            if fno == 1 and wt == 2:
                inner = val
                # Check if inner looks like a nested message (has field 1 = trajectory_id)
                inner_fields = list(iter_fields(inner))
                inner_has_id = any(f == 1 and w == 2 for f, w, _, _ in inner_fields)
                inner_has_steps = any(f == 2 and w == 2 for f, w, _, _ in inner_fields)
                if inner_has_id and inner_has_steps:
                    return parse_trajectory(inner)
                else:
                    info['trajectory_id'] = inner.decode('utf-8', errors='replace')
                break
        return info

    # Standard format
    for fno, wt, off, val in top_fields:
        if fno == 1 and wt == 2:
            info['trajectory_id'] = val.decode('utf-8', errors='replace')
        elif fno == 6 and wt == 2:
            info['cascade_id'] = val.decode('utf-8', errors='replace')
        elif fno == 4 and wt == 0:
            info['trajectory_type'] = val
        elif fno == 8 and wt == 0:
            info['source'] = val
        elif fno == 2 and wt == 2:  # step
            info['steps_count'] += 1
            info['steps'].append(val)
    return info


def parse_step(step_buf):
    """Parse a CortexTrajectoryStep. Returns dict with type, status, and step-specific payloads."""
    # CortexTrajectoryStep fields (from proto schema reconstruction):
    #   1: type (enum)
    #   4: status (enum)
    #   5: metadata
    #   And oneof step variants: 7=dummy, 8=plan_input, 9=mquery, 10=code_action, 12=finish, 13=grep_search, ...
    out = {'type': None, 'status': None, 'variant_field': None, 'variant_data': None, '_raw': step_buf}
    for fno, wt, off, val in iter_fields(step_buf):
        if fno == 1 and wt == 0:
            out['type'] = val
        elif fno == 4 and wt == 0:
            out['status'] = val
        # oneof step variants are between fields 7-30+ (length-delimited)
        elif 7 <= fno <= 110 and wt == 2:
            if out['variant_field'] is None:
                out['variant_field'] = fno
                out['variant_data'] = val
    return out


def parse_checkpoint(cp_buf):
    """Parse CortexStepCheckpoint. Returns dict with 6 summary fields."""
    # CortexStepCheckpoint fields (from proto schema reconstruction):
    #   1: checkpoint_index (uint32)
    #   3: included_step_indices (repeated uint32, packed)
    #   4: user_intent (string)
    #   5: session_summary (string)
    #   6: code_change_summary (string)
    #   7: edited_file_map (map<string, DiffList>)
    #   8: memory_summary (string)
    #   9: intent_only (bool)
    #   10: conversation_title (string)
    #   11: included_step_index_start (uint32)
    #   12: included_step_index_end (uint32)
    #   13: plan_snapshot (string)
    #   14: user_intent_request_id (string)
    #   15: session_summary_request_id (string)
    #   16: code_change_summary_request_id (string)
    out = {
        'checkpoint_index': None,
        'user_intent': None,
        'session_summary': None,
        'code_change_summary': None,
        'memory_summary': None,
        'conversation_title': None,
        'plan_snapshot': None,
        'intent_only': None,
        'included_step_index_start': None,
        'included_step_index_end': None,
        'included_step_indices': [],
        'edited_files': [],
    }
    for fno, wt, off, val in iter_fields(cp_buf):
        if fno == 1 and wt == 0:
            out['checkpoint_index'] = val
        elif fno == 3:
            if wt == 0:
                out['included_step_indices'].append(val)
            elif wt == 2:  # packed
                pos = 0
                while pos < len(val):
                    v, pos = read_varint(val, pos)
                    out['included_step_indices'].append(v)
        elif fno == 4 and wt == 2:
            out['user_intent'] = val.decode('utf-8', errors='replace')
        elif fno == 5 and wt == 2:
            out['session_summary'] = val.decode('utf-8', errors='replace')
        elif fno == 6 and wt == 2:
            out['code_change_summary'] = val.decode('utf-8', errors='replace')
        elif fno == 7 and wt == 2:
            # edited_file_map entry: {1: key, 2: DiffList}
            file_path = None
            for ifno, iwt, ioff, ival in iter_fields(val):
                if ifno == 1 and iwt == 2:
                    file_path = ival.decode('utf-8', errors='replace')
            if file_path:
                out['edited_files'].append(file_path)
        elif fno == 8 and wt == 2:
            out['memory_summary'] = val.decode('utf-8', errors='replace')
        elif fno == 9 and wt == 0:
            out['intent_only'] = bool(val)
        elif fno == 10 and wt == 2:
            out['conversation_title'] = val.decode('utf-8', errors='replace')
        elif fno == 11 and wt == 0:
            out['included_step_index_start'] = val
        elif fno == 12 and wt == 0:
            out['included_step_index_end'] = val
        elif fno == 13 and wt == 2:
            out['plan_snapshot'] = val.decode('utf-8', errors='replace')
    return out


def main():
    if len(sys.argv) < 2:
        pass  # TODO: replace with Report
        sys.exit(2)

    buf = Path(sys.argv[1]).read_bytes()
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    info = parse_trajectory(buf)
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    # Count step types
    type_counts = {}
    variant_field_counts = {}
    checkpoints = []
    CHECKPOINT_FIELD = 30  # per reconstructed cortex_pb schema: field 30 = checkpoint oneof variant
    for idx, step_buf in enumerate(info['steps']):
        step = parse_step(step_buf)
        t = step['type']
        type_counts[t] = type_counts.get(t, 0) + 1
        if step['variant_field']:
            vf = step['variant_field']
            variant_field_counts[vf] = variant_field_counts.get(vf, 0) + 1
        # Hunt for checkpoints by ACTUAL field number
        if step['variant_field'] == CHECKPOINT_FIELD and step['variant_data']:
            cp = parse_checkpoint(step['variant_data'])
            checkpoints.append((idx, step['type'], step['variant_field'], cp))

    pass  # TODO: replace with Report
    for t, c in sorted(type_counts.items(), key=lambda x: -x[1])[:15]:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for vf, c in sorted(variant_field_counts.items(), key=lambda x: -x[1])[:15]:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for step_idx, step_type, variant_field, cp in checkpoints[:5]:
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        for f in cp['edited_files'][:5]:
            pass  # TODO: replace with Report
if __name__ == "__main__":
    main()
