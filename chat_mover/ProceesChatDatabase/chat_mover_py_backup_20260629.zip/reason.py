#!/usr/bin/env python3
"""
Step 3 of the ChatMover Refactor Pipeline: REASON

Reads every code_unit from chatmover_code.db, generates a BCL reasoning stamp
for each class/method/function, and stores it in the bcl_stamps table.

The stamp captures:
  - purpose: what this unit does (from docstring + name analysis)
  - inputs: expected parameters (from AST)
  - outputs: return shape (from return_type field)
  - assumptions: preconditions (heuristic: what must be true before calling)
  - invariants: what must hold during execution
  - side_effects: mutations, IO, DB writes, file writes (heuristic detection)
  - failure_modes: how it breaks (from try/except analysis)
  - dependencies: what it relies on (from calls field)
  - confidence: 0.0-1.0 based on analysis depth

Usage:
    python3 reason.py                    # Generate stamps for all units
    python3 reason.py --class CascadeIngester  # Stamp one class
    python3 reason.py --stats            # Show stamp coverage stats
"""

import ast
import os
import sys
import re
import hashlib
import argparse
import sqlite3
from pathlib import Path


STAMP_SCHEMA = """
CREATE TABLE IF NOT EXISTS bcl_stamps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unit_id INTEGER NOT NULL,
    purpose TEXT,
    inputs TEXT,
    outputs TEXT,
    assumptions TEXT,
    invariants TEXT,
    side_effects TEXT,
    failure_modes TEXT,
    dependencies TEXT,
    confidence REAL DEFAULT 0.0,
    confidence_reason TEXT,
    stamp_hash TEXT,
    bcl_text TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (unit_id) REFERENCES code_units(id),
    UNIQUE (unit_id)
);

CREATE TABLE IF NOT EXISTS stamp_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unit_id INTEGER NOT NULL,
    stamp_hash TEXT,
    bcl_text TEXT,
    archived_at TEXT DEFAULT (datetime('now'))
);
"""


def extract_docstring(source_text):
    """Extract docstring from source text."""
    try:
        tree = ast.parse(source_text)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
                if (node.body and isinstance(node.body[0], ast.Expr) and
                    isinstance(node.body[0].value, ast.Constant) and
                    isinstance(node.body[0].value.value, str)):
                    return node.body[0].value.value.strip()
    except Exception:
        pass
    return ""


def extract_params(source_text):
    """Extract parameter names from a function/method definition."""
    try:
        tree = ast.parse(source_text)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = []
                for arg in node.args.args:
                    args.append(arg.arg)
                if node.args.vararg:
                    args.append("*" + node.args.vararg.arg)
                if node.args.kwarg:
                    args.append("**" + node.args.kwarg.arg)
                return ", ".join(args)
    except Exception:
        pass
    return ""


def detect_side_effects(source_text):
    """Heuristic detection of side effects."""
    effects = []
    if re.search(r'\.execute\s*\(', source_text):
        effects.append("DB: executes SQL queries")
    if re.search(r'\.commit\s*\(', source_text):
        effects.append("DB: commits transaction")
    if re.search(r'\.close\s*\(', source_text):
        effects.append("DB: closes connection/cursor")
    if re.search(r'\.connect\s*\(', source_text):
        effects.append("DB: opens connection")
    if re.search(r'\.write\s*\(', source_text) or re.search(r'write_text\s*\(', source_text):
        effects.append("FS: writes to file")
    if re.search(r'\.read\s*\(', source_text) or re.search(r'read_text\s*\(', source_text) or re.search(r'read_bytes\s*\(', source_text):
        effects.append("FS: reads from file")
    if re.search(r'\.glob\s*\(', source_text):
        effects.append("FS: directory listing")
    if re.search(r'os\.makedirs|mkdir|mkdirs', source_text):
        effects.append("FS: creates directory")
    if re.search(r'sys\.path', source_text):
        effects.append("SYS: modifies sys.path")
    if re.search(r'import\s+', source_text):
        effects.append("IMPORT: dynamic import")
    if not effects:
        return "none detected"
    return "; ".join(effects)


def detect_failure_modes(source_text):
    """Heuristic detection of failure modes from try/except patterns."""
    modes = []
    try:
        tree = ast.parse(source_text)
        for node in ast.walk(tree):
            if isinstance(node, ast.Try):
                for handler in node.handlers:
                    if isinstance(handler.type, ast.Name):
                        exc_name = handler.type.id
                    elif isinstance(handler.type, ast.Tuple):
                        exc_name = ", ".join(
                            e.id for e in handler.type.elts if isinstance(e, ast.Name)
                        )
                    elif handler.type is None:
                        exc_name = "BARE EXCEPT (catches everything — dangerous)"
                    else:
                        exc_name = "unknown"
                    modes.append(f"catches {exc_name}")
    except Exception:
        pass

    if re.search(r'return\s*\(0\s*,\s*None\s*,', source_text):
        modes.append("returns error Tuple3 on failure")
    if re.search(r'raise\s+', source_text):
        modes.append("can raise exceptions")
    if not modes:
        return "none detected"
    return "; ".join(modes)


def detect_assumptions(source_text, unit_type, class_name):
    """Heuristic detection of assumptions/preconditions."""
    assumptions = []
    if "self.state" in source_text:
        assumptions.append("self.state dict is initialized")
    if "self.state[\"conn\"]" in source_text or "self.state['conn']" in source_text:
        assumptions.append("DB connection may or may not be open")
    if "self.state[\"cursor\"]" in source_text or "self.state['cursor']" in source_text:
        assumptions.append("DB cursor may or may not be open")
    if re.search(r'params\.get|self\._p\s*\(', source_text):
        assumptions.append("params dict may be empty or missing keys")
    if "import " in source_text and "mysql" in source_text.lower():
        assumptions.append("mysql.connector is installed")
    if not assumptions:
        return "none detected"
    return "; ".join(assumptions)


def detect_invariants(source_text):
    """Heuristic detection of invariants."""
    invariants = []
    if "Tuple3" in source_text or re.search(r'return\s*\(\s*[01]\s*,', source_text):
        invariants.append("all return paths must yield Tuple3 (ok, data, error)")
    if "self.state" in source_text:
        invariants.append("self.state is the single source of instance state")
    if not invariants:
        return "none detected"
    return "; ".join(invariants)


def infer_purpose(unit_name, unit_type, class_name, docstring, calls, source_text):
    """Infer purpose from name, docstring, and calls."""
    if docstring:
        first_line = docstring.splitlines()[0].strip()
        if len(first_line) > 5:
            return first_line[:200]

    name_hints = {
        "Run": "Dispatch entry point — routes commands to methods",
        "Decrypt": "Decrypt .pb files using AES-256-GCM",
        "Ingest": "Parse and store conversations into MySQL",
        "Status": "Query database for current state/counts",
        "Connect": "Establish MySQL connection",
        "Close": "Close MySQL connection and cursor",
        "Export": "Export data to files",
        "main": "Script entry point",
        "decrypt_one": "Decrypt a single .pb file",
        "parse_trajectory": "Parse protobuf trajectory binary",
        "parse_step": "Parse a single trajectory step",
        "parse_checkpoint": "Parse a CortexStepCheckpoint",
        "read_varint": "Read a protobuf varint",
        "parse_tag": "Parse a protobuf field tag",
    }

    if unit_name in name_hints:
        return name_hints[unit_name]

    if unit_name.startswith("_"):
        return f"Internal helper: {unit_name.lstrip('_')}"

    if unit_type == "class":
        return f"Class: {unit_name}"

    if unit_type == "function":
        return f"Function: {unit_name}"

    return f"{unit_type} {unit_name}"


def compute_confidence(source_text, docstring, unit_type, return_type, calls):
    """Compute confidence score based on how much we could analyze."""
    score = 0.3  # base
    if docstring:
        score += 0.15
    if return_type and return_type != "unknown":
        score += 0.1
    if calls:
        score += 0.1
    if len(source_text) > 50:
        score += 0.1
    if unit_type == "method":
        score += 0.1  # methods are more predictable
    if "try" in source_text.lower() or "except" in source_text.lower():
        score += 0.05  # error handling visible
    if "return" in source_text:
        score += 0.1

    return min(score, 0.95)


def generate_bcl_text(unit_id, unit_name, unit_type, class_name, purpose, inputs,
                      outputs, assumptions, invariants, side_effects,
                      failure_modes, dependencies, confidence):
    """Generate BCL-formatted stamp text."""
    cls = class_name or "module"
    bcl = f"[@{unit_name}]{{"
    bcl += f'("unit_id";"{unit_id}";92);'
    bcl += f'("class";"{cls}";92);'
    bcl += f'("type";"{unit_type}";92);'
    bcl += f'("purpose";"{purpose}";92);'
    bcl += f'("inputs";"{inputs}";92);'
    bcl += f'("outputs";"{outputs}";92);'
    bcl += f'("assumptions";"{assumptions}";92);'
    bcl += f'("invariants";"{invariants}";92);'
    bcl += f'("side_effects";"{side_effects}";92);'
    bcl += f'("failure_modes";"{failure_modes}";92);'
    bcl += f'("dependencies";"{dependencies}";92);'
    bcl += f'("confidence";"{confidence:.2f}";92)'
    bcl += "}"
    return bcl


def stamp_unit(db_path, unit_row):
    """Generate and store a BCL stamp for one code unit."""
    unit_id, file_path, unit_type, class_name, unit_name, source_text = unit_row[:6]
    return_type = unit_row[7] if len(unit_row) > 7 else "unknown"
    dispatch_keys = unit_row[8] if len(unit_row) > 8 else ""
    calls = unit_row[9] if len(unit_row) > 9 else ""

    docstring = extract_docstring(source_text)
    params = extract_params(source_text)
    purpose = infer_purpose(unit_name, unit_type, class_name, docstring, calls, source_text)
    inputs = params if params else "none"
    outputs = return_type if return_type and return_type != "unknown" else "unknown"
    assumptions = detect_assumptions(source_text, unit_type, class_name)
    invariants = detect_invariants(source_text)
    side_effects = detect_side_effects(source_text)
    failure_modes = detect_failure_modes(source_text)
    dependencies = calls if calls else "none"
    confidence = compute_confidence(source_text, docstring, unit_type, return_type, calls)
    confidence_reason = f"auto-generated; docstring={'yes' if docstring else 'no'}; return_type={return_type}; calls={len(calls.split(',')) if calls else 0}"

    bcl_text = generate_bcl_text(
        unit_id, unit_name, unit_type, class_name, purpose, inputs,
        outputs, assumptions, invariants, side_effects,
        failure_modes, dependencies, confidence
    )

    stamp_hash = hashlib.sha256(bcl_text.encode('utf-8')).hexdigest()

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Archive old stamp if exists
    cur.execute("SELECT bcl_text, stamp_hash FROM bcl_stamps WHERE unit_id=?", (unit_id,))
    old = cur.fetchone()
    if old:
        cur.execute("INSERT INTO stamp_history (unit_id, stamp_hash, bcl_text) VALUES (?, ?, ?)",
                     (unit_id, old[1], old[0]))
        cur.execute("DELETE FROM bcl_stamps WHERE unit_id=?", (unit_id,))

    cur.execute("""
        INSERT INTO bcl_stamps
            (unit_id, purpose, inputs, outputs, assumptions, invariants,
             side_effects, failure_modes, dependencies, confidence,
             confidence_reason, stamp_hash, bcl_text)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (unit_id, purpose, inputs, outputs, assumptions, invariants,
          side_effects, failure_modes, dependencies, confidence,
          confidence_reason, stamp_hash, bcl_text))

    conn.commit()
    conn.close()

    return {
        "unit_id": unit_id,
        "unit_name": unit_name,
        "class_name": class_name,
        "confidence": confidence,
        "purpose": purpose[:60]
    }


def show_stamp_stats(db_path):
    """Show BCL stamp coverage statistics."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM code_units WHERE unit_type IN ('class','method','function')")
    total = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM bcl_stamps")
    stamped = cur.fetchone()[0]

    cur.execute("""
        SELECT cu.unit_type, COUNT(cu.id) as total, COUNT(bs.id) as stamped
        FROM code_units cu
        LEFT JOIN bcl_stamps bs ON bs.unit_id = cu.id
        WHERE cu.unit_type IN ('class','method','function')
        GROUP BY cu.unit_type
    """)
    by_type = cur.fetchall()

    cur.execute("""
        SELECT cu.class_name, cu.unit_name, bs.confidence, bs.purpose
        FROM bcl_stamps bs
        JOIN code_units cu ON cu.id = bs.unit_id
        ORDER BY bs.confidence ASC
        LIMIT 10
    """)
    low_conf = cur.fetchall()

    cur.execute("""
        SELECT cu.class_name, cu.unit_name, bs.purpose, bs.side_effects, bs.failure_modes
        FROM bcl_stamps bs
        JOIN code_units cu ON cu.id = bs.unit_id
        WHERE bs.confidence >= 0.7
        ORDER BY bs.confidence DESC
        LIMIT 10
    """)
    high_conf = cur.fetchall()

    conn.close()

    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for utype, tot, stm in by_type:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for cls, name, conf, purpose in low_conf:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for cls, name, purpose, effects, failures in high_conf:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
def main():
    parser = argparse.ArgumentParser(description="Step 3: REASON — Generate BCL stamps for all code units")
    parser.add_argument("--db", default=None, help="SQLite DB path")
    parser.add_argument("--class", dest="class_name", default=None, help="Stamp only one class")
    parser.add_argument("--stats", action="store_true", help="Show stamp coverage stats")
    args = parser.parse_args()

    db_path = args.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
    if not os.path.exists(db_path):
        pass  # TODO: replace with Report
        sys.exit(1)

    conn = sqlite3.connect(db_path)
    conn.executescript(STAMP_SCHEMA)
    conn.commit()
    conn.close()

    if args.stats:
        show_stamp_stats(db_path)
        return

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    if args.class_name:
        cur.execute("""
            SELECT id, file_path, unit_type, class_name, unit_name, source_text,
                   return_type, dispatch_keys, calls
            FROM code_units
            WHERE class_name = ? AND unit_type IN ('class','method','function')
            ORDER BY line_start
        """, (args.class_name,))
    else:
        cur.execute("""
            SELECT id, file_path, unit_type, class_name, unit_name, source_text,
                   return_type, dispatch_keys, calls
            FROM code_units
            WHERE unit_type IN ('class','method','function')
            ORDER BY file_path, line_start
        """)

    units = cur.fetchall()
    conn.close()

    pass  # TODO: replace with Report
    print()

    for unit in units:
        result = stamp_unit(db_path, unit)
        cls = result["class_name"] or "module"
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    show_stamp_stats(db_path)


if __name__ == "__main__":
    main()
