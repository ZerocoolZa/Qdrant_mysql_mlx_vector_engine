#!/usr/bin/env python3
"""
Repair Graph — the Garmin for code fixes.

Every violation is a starting location. Every fix attempt is a route.
Every result is a destination. Successful routes get saved.

Tables:
  repair_nodes  — states in the repair journey (violations, fix attempts, results)
  repair_edges  — transitions between states (actions taken, with metadata)
  repair_routes — saved successful paths (reusable: "when you see X, do Y")
  repair_log    — every action ever taken (the trip history)

Usage:
    python3 repair_graph.py init              # Create tables
    python3 repair_graph.py import-violations  # Load violations from violations table
    python3 repair_graph.py attempt            # Record a fix attempt
    python3 repair_graph.py routes             # Show saved routes
    python3 repair_graph.py history            # Show full trip history
    python3 repair_graph.py navigate <type>    # Show all known paths for a violation type
    python3 repair_graph.py stats              # Dashboard
"""

import os
import sys
import json
import hashlib
import argparse
import sqlite3
from datetime import datetime


REPAIR_SCHEMA = """
-- Repair nodes: states in the repair journey
-- Each node is a point in time: a violation found, a fix attempted, a result observed
CREATE TABLE IF NOT EXISTS repair_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_type TEXT NOT NULL,           -- 'violation' | 'fix_attempt' | 'result' | 'learned'
    violation_type TEXT,               -- has_print, has_decorator, etc.
    file_path TEXT,
    line_number INTEGER,
    severity TEXT,                     -- error | warning
    status TEXT DEFAULT 'open',        -- open | in_progress | fixed | failed | skipped
    source_hash TEXT,                  -- hash of source before this state
    detail TEXT,                       -- what this node represents
    created_at TEXT DEFAULT (datetime('now'))
);

-- Repair edges: transitions between states
-- Each edge is an action: "we tried fix X", "it compiled", "it broke", "we reverted"
CREATE TABLE IF NOT EXISTS repair_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_node INTEGER NOT NULL,
    target_node INTEGER NOT NULL,
    action TEXT NOT NULL,              -- 'attempted' | 'succeeded' | 'failed' | 'reverted' | 'learned'
    fix_applied TEXT,                  -- what transformation was done
    fix_tool TEXT,                     -- 'rule_enforcer' | 'manual' | 'repair_engine' | 'cascade'
    result TEXT,                       -- 'compiled' | 'broke_syntax' | 'new_violation' | 'resolved' | 'partial'
    confidence REAL DEFAULT 0.5,
    note TEXT,                         -- free text: "regex bug, only captured first char"
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (source_node) REFERENCES repair_nodes(id),
    FOREIGN KEY (target_node) REFERENCES repair_nodes(id)
);

-- Saved routes: successful paths from violation -> resolved
-- These are the "saved destinations" in Garmin terms
CREATE TABLE IF NOT EXISTS repair_routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    violation_type TEXT NOT NULL,
    route_name TEXT,                   -- human-readable: "remove @property decorator"
    steps TEXT NOT NULL,               -- JSON array of actions
    success_count INTEGER DEFAULT 0,
    fail_count INTEGER DEFAULT 0,
    confidence REAL DEFAULT 0.5,
    first_seen TEXT DEFAULT (datetime('now')),
    last_used TEXT DEFAULT (datetime('now'))
);

-- Trip history: every action ever logged (the Garmin trip log)
CREATE TABLE IF NOT EXISTS repair_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    violation_type TEXT,
    file_path TEXT,
    action TEXT,                       -- what was done
    result TEXT,                       -- what happened
    tool TEXT,                         -- who did it
    route_id INTEGER,                  -- which saved route was used (if any)
    note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_rn_type ON repair_nodes(violation_type);
CREATE INDEX IF NOT EXISTS idx_rn_status ON repair_nodes(status);
CREATE INDEX IF NOT EXISTS idx_re_source ON repair_edges(source_node);
CREATE INDEX IF NOT EXISTS idx_re_target ON repair_edges(target_node);
CREATE INDEX IF NOT EXISTS idx_rr_type ON repair_routes(violation_type);
CREATE INDEX IF NOT EXISTS idx_rl_type ON repair_log(violation_type);
"""


def get_db():
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
    return sqlite3.connect(db_path)


def cmd_init(args):
    conn = get_db()
    conn.executescript(REPAIR_SCHEMA)
    conn.commit()
    conn.close()
    sys.stdout.write("Repair Graph tables created.\n")


def cmd_import_violations(args):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT id, unit_id, file_path, class_name, unit_name, violation_type, severity, detail FROM violations WHERE status = 'open'")
    rows = cur.fetchall()

    imported = 0
    for vid, uid, fpath, cls, uname, vtype, sev, detail in rows:
        cur.execute("""
            INSERT INTO repair_nodes (node_type, violation_type, file_path, severity, status, detail)
            VALUES ('violation', ?, ?, ?, 'open', ?)
        """, (vtype, fpath, sev, detail))
        imported += 1

    conn.commit()
    conn.close()
    sys.stdout.write(f"Imported {imported} violations as repair nodes.\n")


def cmd_attempt(args):
    """Record a fix attempt: violation -> fix -> result."""
    conn = get_db()
    cur = conn.cursor()

    vtype = args.violation_type
    fpath = args.file
    fix_applied = args.fix or "auto"
    result = args.result or "unknown"
    tool = args.tool or "cascade"
    note = args.note or ""

    source_hash = ""
    if fpath and os.path.isfile(fpath):
        with open(fpath, "r") as f:
            source_hash = hashlib.sha256(f.read().encode()).hexdigest()[:16]

    cur.execute("""
        INSERT INTO repair_nodes (node_type, violation_type, file_path, severity, status, source_hash, detail)
        VALUES ('fix_attempt', ?, ?, 'info', 'in_progress', ?, ?)
    """, (vtype, fpath, source_hash, fix_applied))
    attempt_node = cur.lastrowid

    if result == "resolved":
        status = "fixed"
    elif result == "broke_syntax":
        status = "failed"
    else:
        status = "open"

    cur.execute("""
        INSERT INTO repair_nodes (node_type, violation_type, file_path, severity, status, detail)
        VALUES ('result', ?, ?, 'info', ?, ?)
    """, (vtype, fpath, status, result))
    result_node = cur.lastrowid

    cur.execute("""
        INSERT INTO repair_edges (source_node, target_node, action, fix_applied, fix_tool, result, confidence, note)
        VALUES (?, ?, 'attempted', ?, ?, ?, 0.5, ?)
    """, (attempt_node - 1 if attempt_node > 1 else attempt_node, attempt_node, fix_applied, tool, result, note))

    cur.execute("""
        INSERT INTO repair_edges (source_node, target_node, action, fix_applied, fix_tool, result, confidence, note)
        VALUES (?, ?, ?, ?, ?, ?, 0.5, ?)
    """, (attempt_node, result_node, "succeeded" if result == "resolved" else "failed", fix_applied, tool, result, note))

    cur.execute("""
        INSERT INTO repair_log (violation_type, file_path, action, result, tool, note)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (vtype, fpath, fix_applied, result, tool, note))

    if result == "resolved":
        cur.execute("""
            INSERT INTO repair_routes (violation_type, route_name, steps, success_count, confidence)
            VALUES (?, ?, ?, 1, 0.8)
        """, (vtype, fix_applied, json.dumps([{"action": fix_applied, "tool": tool, "result": result}])))

    conn.commit()
    conn.close()
    sys.stdout.write(f"Recorded: {vtype} on {fpath} -> {fix_applied} -> {result}\n")


def cmd_routes(args):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT violation_type, route_name, success_count, fail_count, confidence, last_used
        FROM repair_routes ORDER BY success_count DESC, confidence DESC
    """)
    rows = cur.fetchall()
    conn.close()

    if not rows:
        sys.stdout.write("No saved routes yet.\n")
        return

    sys.stdout.write(f"\n{'='*70}\n")
    sys.stdout.write(f"SAVED REPAIR ROUTES (Garmin destinations)\n")
    sys.stdout.write(f"{'='*70}\n")
    for vtype, name, success, fail, conf, last in rows:
        sys.stdout.write(f"  {vtype:25s}  {name:30s}  OK:{success} FAIL:{fail}  conf={conf:.1f}  last={last}\n")
    sys.stdout.write(f"{'='*70}\n")


def cmd_history(args):
    conn = get_db()
    cur = conn.cursor()
    limit = args.limit or 50
    cur.execute("""
        SELECT violation_type, file_path, action, result, tool, note, created_at
        FROM repair_log ORDER BY created_at DESC LIMIT ?
    """, (limit,))
    rows = cur.fetchall()
    conn.close()

    if not rows:
        sys.stdout.write("No repair history yet.\n")
        return

    sys.stdout.write(f"\n{'='*70}\n")
    sys.stdout.write(f"REPAIR TRIP HISTORY (last {len(rows)} actions)\n")
    sys.stdout.write(f"{'='*70}\n")
    for vtype, fpath, action, result, tool, note, ts in rows:
        fname = os.path.basename(fpath) if fpath else "?"
        sys.stdout.write(f"  {ts}  {vtype:20s}  {fname:25s}  {action:20s}  -> {result:15s}  [{tool}]\n")
        if note:
            sys.stdout.write(f"    note: {note}\n")
    sys.stdout.write(f"{'='*70}\n")


def cmd_navigate(args):
    """Show all known paths for a violation type — like asking Garmin for route options."""
    conn = get_db()
    cur = conn.cursor()
    vtype = args.violation_type

    cur.execute("""
        SELECT route_name, success_count, fail_count, confidence, steps
        FROM repair_routes WHERE violation_type = ? ORDER BY success_count DESC
    """, (vtype,))
    routes = cur.fetchall()

    cur.execute("""
        SELECT action, result, tool, note, created_at
        FROM repair_log WHERE violation_type = ? ORDER BY created_at DESC LIMIT 20
    """, (vtype,))
    history = cur.fetchall()

    conn.close()

    sys.stdout.write(f"\n{'='*70}\n")
    sys.stdout.write(f"NAVIGATE: {vtype}\n")
    sys.stdout.write(f"{'='*70}\n")

    if routes:
        sys.stdout.write(f"\n  SAVED ROUTES ({len(routes)}):\n")
        for name, success, fail, conf, steps in routes:
            sys.stdout.write(f"    -> {name:30s}  OK:{success} FAIL:{fail}  conf={conf:.1f}\n")
            step_list = json.loads(steps) if steps else []
            for s in step_list:
                sys.stdout.write(f"       step: {s.get('action', '?')} via {s.get('tool', '?')} -> {s.get('result', '?')}\n")
    else:
        sys.stdout.write(f"\n  No saved routes yet for {vtype}.\n")

    if history:
        sys.stdout.write(f"\n  TRIP HISTORY ({len(history)}):\n")
        for action, result, tool, note, ts in history:
            sys.stdout.write(f"    {ts}  {action:20s} -> {result:15s}  [{tool}]")
            if note:
                sys.stdout.write(f"  note: {note}")
            sys.stdout.write("\n")
    else:
        sys.stdout.write(f"\n  No history yet for {vtype}.\n")

    sys.stdout.write(f"\n{'='*70}\n")


def cmd_stats(args):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM repair_nodes")
    nodes = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM repair_edges")
    edges = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM repair_routes")
    routes = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM repair_log")
    log = cur.fetchone()[0]

    cur.execute("SELECT status, COUNT(*) FROM repair_nodes WHERE node_type='result' GROUP BY status")
    by_status = cur.fetchall()

    cur.execute("SELECT violation_type, COUNT(*) FROM repair_nodes WHERE node_type='violation' GROUP BY violation_type ORDER BY COUNT(*) DESC")
    by_type = cur.fetchall()

    cur.execute("SELECT violation_type, route_name, success_count, confidence FROM repair_routes ORDER BY success_count DESC LIMIT 10")
    top_routes = cur.fetchall()

    conn.close()

    sys.stdout.write(f"\n{'='*70}\n")
    sys.stdout.write(f"REPAIR GRAPH DASHBOARD\n")
    sys.stdout.write(f"{'='*70}\n")
    sys.stdout.write(f"  Nodes:     {nodes}\n")
    sys.stdout.write(f"  Edges:     {edges}\n")
    sys.stdout.write(f"  Routes:    {routes}\n")
    sys.stdout.write(f"  Log entries: {log}\n")

    sys.stdout.write(f"\n  Results by status:\n")
    for status, cnt in by_status:
        sys.stdout.write(f"    {status:15s}: {cnt}\n")

    sys.stdout.write(f"\n  Violations by type:\n")
    for vtype, cnt in by_type:
        sys.stdout.write(f"    {vtype:25s}: {cnt}\n")

    if top_routes:
        sys.stdout.write(f"\n  Top saved routes:\n")
        for vtype, name, success, conf in top_routes:
            sys.stdout.write(f"    {vtype:25s} -> {name:30s}  OK:{success}  conf={conf:.1f}\n")

    sys.stdout.write(f"{'='*70}\n")


def cmd_record_enforcer_run(args):
    """Record what the RuleEnforcer did as repair graph entries."""
    conn = get_db()
    cur = conn.cursor()

    enforcer_results = [
        ("has_print", "print() -> pass", "rule_enforcer", "resolved", "12 files fixed"),
        ("has_decorator", "removed @property", "rule_enforcer", "resolved", "26 decorators removed from Config.py"),
        ("has_self_underscore", "self._ -> self.state", "rule_enforcer", "failed", "regex bug: only captured first char, broke syntax"),
        ("has_self_underscore", "reverted broken replacement", "cascade", "reverted", "fixed syntax, back to original self._"),
        ("trailing_whitespace", "stripped trailing whitespace", "rule_enforcer", "resolved", "3 files cleaned"),
    ]

    for vtype, action, tool, result, note in enforcer_results:
        cur.execute("""
            INSERT INTO repair_log (violation_type, action, result, tool, note)
            VALUES (?, ?, ?, ?, ?)
        """, (vtype, action, result, tool, note))

        if result == "resolved":
            cur.execute("""
                INSERT OR REPLACE INTO repair_routes (violation_type, route_name, steps, success_count, confidence)
                VALUES (?, ?, ?, 1, 0.8)
            """, (vtype, action, json.dumps([{"action": action, "tool": tool, "result": result}])))
        elif result == "failed":
            cur.execute("""
                INSERT OR REPLACE INTO repair_routes (violation_type, route_name, steps, success_count, fail_count, confidence)
                VALUES (?, ?, ?, 0, 1, 0.1)
            """, (vtype, action, json.dumps([{"action": action, "tool": tool, "result": result}])))

    conn.commit()
    conn.close()
    sys.stdout.write("Recorded RuleEnforcer run into repair graph.\n")


def main():
    parser = argparse.ArgumentParser(description="Repair Graph — the Garmin for code fixes")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("init", help="Create repair graph tables")
    sub.add_parser("import-violations", help="Import open violations as repair nodes")
    sub.add_parser("routes", help="Show saved repair routes")
    hist = sub.add_parser("history", help="Show repair trip history")
    hist.add_argument("--limit", type=int, default=50)
    sub.add_parser("stats", help="Show repair graph dashboard")
    sub.add_parser("record-enforcer", help="Record the RuleEnforcer run into repair graph")

    nav = sub.add_parser("navigate", help="Show all known paths for a violation type")
    nav.add_argument("violation_type")

    att = sub.add_parser("attempt", help="Record a fix attempt")
    att.add_argument("--violation-type", required=True)
    att.add_argument("--file", default="")
    att.add_argument("--fix", default="")
    att.add_argument("--result", default="unknown")
    att.add_argument("--tool", default="cascade")
    att.add_argument("--note", default="")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args)
    elif args.command == "import-violations":
        cmd_import_violations(args)
    elif args.command == "attempt":
        cmd_attempt(args)
    elif args.command == "routes":
        cmd_routes(args)
    elif args.command == "history":
        cmd_history(args)
    elif args.command == "navigate":
        cmd_navigate(args)
    elif args.command == "stats":
        cmd_stats(args)
    elif args.command == "record-enforcer":
        cmd_record_enforcer_run(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
