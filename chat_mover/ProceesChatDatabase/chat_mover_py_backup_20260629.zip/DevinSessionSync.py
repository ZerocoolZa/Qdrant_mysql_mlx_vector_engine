"""
#[@GHOST]{("file_path=/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/DevinSessionSync.py";"identity=DevinSessionSync";"purpose=Sync Devin CLI sessions.db + summaries + transcripts into MySQL devin database";"date=2026-06-29";"version=1.0";"author=Devin";"chat_link=")}
#[@VBSTYLE]{("auth=Devin";"role=domain_devin_sync";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded|no_tabs|no_self_underscore";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("DevinSessionSync")}
#[@METHODS]{("__init__";"Run";"Sync";"Status";"_ConnectMysql";"_ConnectSqlite";"_Close";"_TsToDt";"_ParseChatMessage";"_SyncSessions";"_SyncMessages";"_SyncToolCalls";"_SyncRenderedCommits";"_SyncTranscripts";"_SyncSummaries";"_SyncChatTurns";"_UpsertTurn";"_ExtractFilesFromToolCalls";"_ExtractFilePathsFromToolMsg";"_LogImport";"read_state";"set_config";"_p")}
#[@DOMAIN]{("devin_sync")}
"""

import glob
import json
import os
import re
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Dict, Tuple

from Config_devin_sync import DevinSyncConfig


_FILE_VIEW_RE = re.compile(r'<file-view\s+path="([^"]+)"', re.IGNORECASE)
_FILE_CREATED_RE = re.compile(r'File created successfully at:\s*(.+?)(?:\n|$)', re.IGNORECASE)
_FILE_UPDATED_RE = re.compile(r'The file\s+(.+?)\s+has been updated', re.IGNORECASE)


class DevinSessionSync:
    """Authority for syncing Devin session data from SQLite to MySQL."""

    def __init__(self, mem=None, db=None, param=None):
        cfg = DevinSyncConfig()
        ok, config, _ = cfg.Run("read_state", {})
        self.state = {
            "config": config,
            "catalog": [],
            "results": [],
            "memunit": mem,
            "db_manager": db,
            "sqlite_conn": None,
            "sqlite_cur": None,
            "mysql_conn": None,
            "mysql_cur": None,
        }
        if param and isinstance(param, dict):
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "sync":
            return self.Sync(params)
        elif command == "status":
            return self.Status(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        else:
            return (0, None, ("UNKNOWN_COMMAND", f"Unknown command: {command}", 0))

    def _p(self, params, key, default=None):
        if not params or not isinstance(params, dict):
            return default
        return params.get(key, default)

    def read_state(self, params):
        snapshot = dict(self.state)
        snapshot["sqlite_conn"] = "connected" if self.state["sqlite_conn"] else "disconnected"
        snapshot["mysql_conn"] = "connected" if self.state["mysql_conn"] else "disconnected"
        return (1, snapshot, None)

    def set_config(self, params):
        try:
            if not params or not isinstance(params, dict):
                return (0, None, ("SET_CONFIG_ERROR", "param dict required", 0))
            for key, value in params.items():
                self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("SET_CONFIG_ERROR", str(e), 0))

    def _TsToDt(self, params):
        ts = self._p(params, "ts", None)
        if ts is None:
            return (1, None, None)
        try:
            return (1, datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"), None)
        except (ValueError, TypeError, OSError):
            return (1, None, None)

    def _ParseChatMessage(self, params):
        raw = self._p(params, "raw", None)
        if not raw:
            return (1, None, None, None)
        if isinstance(raw, dict):
            obj = raw
        elif isinstance(raw, str):
            try:
                obj = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                return (1, None, raw[:65000], None)
        else:
            return (1, None, str(raw)[:65000], None)
        role = obj.get("role")
        content = obj.get("content", "")
        message_id = obj.get("message_id")
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False, default=str)
        if content and len(content) > 16000000:
            content = content[:16000000] + "\n...[truncated]"
        return (1, role, content, message_id)

    def _ConnectMysql(self, params):
        try:
            import mysql.connector
            cfg = self.state["config"]
            last = None
            for attempt in range(1, cfg["MAX_RETRIES"] + 1):
                try:
                    self.state["mysql_conn"] = mysql.connector.connect(
                        host=cfg["DB_HOST"],
                        port=cfg["DB_PORT"],
                        user=cfg["DB_USER"],
                        password=cfg["DB_PASSWORD"],
                        database=cfg["DB_NAME"],
                        charset=cfg["DB_CHARSET"],
                        autocommit=True,
                        connection_timeout=10,
                    )
                    self.state["mysql_cur"] = self.state["mysql_conn"].cursor(prepared=True)
                    return (1, True, None)
                except Exception as e:
                    last = e
                    wait = cfg["INITIAL_BACKOFF"] * (2 ** (attempt - 1))
                    time.sleep(wait)
            return (0, None, ("MYSQL_CONNECT_FAILED", str(last), 0))
        except Exception as e:
            return (0, None, ("MYSQL_CONNECT_ERROR", str(e), 0))

    def _ConnectSqlite(self, params):
        try:
            db_path = self.state["config"]["DEVIN_SQLITE_DB"]
            if not os.path.exists(db_path):
                return (0, None, ("NO_SQLITE", f"SQLite DB not found: {db_path}", 0))
            import subprocess
            sqlite3_exe = self.state["config"].get("SQLITE3_EXE", "sqlite3")
            try:
                check = subprocess.run([sqlite3_exe, "--version"], capture_output=True, text=True)
                if check.returncode != 0:
                    return (0, None, ("NO_SQLITE3_CLI", f"sqlite3 CLI not found: {sqlite3_exe}", 0))
            except Exception as e:
                return (0, None, ("NO_SQLITE3_CLI", str(e), 0))

            def load_table(table, columns):
                import csv
                import io
                import sys
                csv.field_size_limit(sys.maxsize)
                col_str = ", ".join(columns)
                sql = f"SELECT {col_str} FROM {table};"
                cmd = [sqlite3_exe, db_path, ".mode csv", sql]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                if not proc.stdout.strip():
                    if proc.stderr:
                        raise Exception(proc.stderr[:500])
                    return (columns, [])
                rows = []
                reader = csv.DictReader(io.StringIO(proc.stdout))
                for row in reader:
                    converted = {}
                    for key, value in row.items():
                        if value == "":
                            converted[key] = None
                        else:
                            converted[key] = value
                    rows.append(converted)
                return (columns, rows)

            try:
                catalog = {
                    "sessions": load_table("sessions", [
                        "id", "title", "working_directory", "backend_type", "model", "agent_mode",
                        "created_at", "last_activity_at", "hidden", "main_chain_id",
                        "shell_last_seen_index", "cogs_json", "workspace_dirs", "metadata"
                    ]),
                    "messages": load_table("message_nodes", [
                        "row_id", "session_id", "node_id", "parent_node_id", "chat_message", "created_at", "metadata"
                    ]),
                    "tool_calls": load_table("tool_call_state", [
                        "session_id", "tool_call_id", "tool_call_json", "tool_call_update_json"
                    ]),
                    "rendered_commits": load_table("rendered_commits", [
                        "id", "session_id", "sequence_number", "rendered_html", "created_at"
                    ]),
                }
            except Exception as e:
                return (0, None, ("SQLITE_LOAD_ERROR", str(e), 0))

            self.state["catalog"] = catalog
            self.state["sqlite_conn"] = None
            self.state["sqlite_cur"] = None
            return (1, True, None)
        except Exception as e:
            return (0, None, ("SQLITE_CONNECT_ERROR", str(e), 0))

    def _Close(self, params):
        try:
            if self.state.get("sqlite_conn"):
                self.state["sqlite_conn"].close()
                self.state["sqlite_conn"] = None
                self.state["sqlite_cur"] = None
            if self.state.get("mysql_conn"):
                self.state["mysql_conn"].close()
                self.state["mysql_conn"] = None
                self.state["mysql_cur"] = None
            return (1, True, None)
        except Exception:
            return (1, True, None)

    def _LogImport(self, params):
        try:
            mcur = self.state["mysql_cur"]
            step = self._p(params, "step", "")
            source = self._p(params, "source", "")
            rows = self._p(params, "rows", 0)
            status = self._p(params, "status", "OK")
            error = self._p(params, "error", None)
            mcur.execute(
                """INSERT INTO devin_import_log
                (import_step, source_file, rows_imported, status, error, imported_at)
                VALUES (%s, %s, %s, %s, %s, NOW())""",
                (step, source, rows, status, error)
            )
            return (1, True, None)
        except Exception as e:
            return (0, None, ("LOG_IMPORT_ERROR", str(e), 0))

    def _SyncSessions(self, params):
        try:
            mcur = self.state["mysql_cur"]
            mcur.execute("SELECT id FROM devin_sessions")
            existing = set(r[0] for r in mcur.fetchall())

            rows = self.state["catalog"]["sessions"][1]
            inserted = 0
            for r in rows:
                sid = r.get("id")
                if sid in existing:
                    continue
                created_at = r.get("created_at")
                last_activity_at = r.get("last_activity_at")
                ok, created_dt, _ = self._TsToDt({"ts": created_at})
                ok, last_dt, _ = self._TsToDt({"ts": last_activity_at})
                mcur.execute(
                    """INSERT IGNORE INTO devin_sessions
                    (id, title, working_directory, backend_type, model, agent_mode,
                     created_at, created_at_dt, last_activity_at, last_activity_at_dt,
                     hidden, main_chain_id, shell_last_seen_index, cogs_json, workspace_dirs, metadata, source)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (sid, r.get("title"), r.get("working_directory"),
                     r.get("backend_type"), r.get("model"), r.get("agent_mode"),
                     created_at, created_dt, last_activity_at, last_dt,
                     r.get("hidden"), r.get("main_chain_id"),
                     r.get("shell_last_seen_index"), r.get("cogs_json"),
                     r.get("workspace_dirs"), r.get("metadata"), "sessions.db")
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(rows)}, None)
        except Exception as e:
            return (0, None, ("SYNC_SESSIONS_ERROR", str(e), 0))

    def _SyncMessages(self, params):
        try:
            mcur = self.state["mysql_cur"]
            mcur.execute("SELECT message_id FROM devin_messages WHERE message_id IS NOT NULL")
            existing_msg = set(r[0] for r in mcur.fetchall())
            mcur.execute("SELECT row_id FROM devin_messages")
            existing_row = set(r[0] for r in mcur.fetchall())

            rows = self.state["catalog"]["messages"][1]
            inserted = 0
            seen = set()
            for obj in rows:
                ok, role, content, message_id = self._ParseChatMessage({"raw": obj.get("chat_message")})

                if message_id:
                    if message_id in existing_msg or message_id in seen:
                        continue
                    seen.add(message_id)
                elif obj.get("row_id") in existing_row:
                    continue

                meta = obj.get("metadata")
                if isinstance(meta, dict):
                    meta = json.dumps(meta, default=str)

                created_at = obj.get("created_at")
                ok, created_dt, _ = self._TsToDt({"ts": created_at})
                mcur.execute(
                    """INSERT IGNORE INTO devin_messages
                    (session_id, node_id, parent_node_id, message_id, role, content,
                     created_at, created_at_dt, metadata, source)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (obj.get("session_id"), obj.get("node_id"), obj.get("parent_node_id"),
                     message_id, role, content, created_at, created_dt, meta, "sessions.db")
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(rows)}, None)
        except Exception as e:
            return (0, None, ("SYNC_MESSAGES_ERROR", str(e), 0))

    def _SyncToolCalls(self, params):
        try:
            mcur = self.state["mysql_cur"]
            mcur.execute("SELECT tool_call_id FROM devin_tool_calls WHERE tool_call_id IS NOT NULL")
            existing = set(r[0] for r in mcur.fetchall())

            rows = self.state["catalog"]["tool_calls"][1]
            inserted = 0
            for obj in rows:
                tc_id = obj.get("tool_call_id")
                if tc_id and tc_id in existing:
                    continue
                if tc_id:
                    existing.add(tc_id)
                tc_json = obj.get("tool_call_json", "")
                if isinstance(tc_json, dict):
                    tc_json = json.dumps(tc_json, default=str)
                tc_update = obj.get("tool_call_update_json", "")
                if isinstance(tc_update, dict):
                    tc_update = json.dumps(tc_update, default=str)
                mcur.execute(
                    """INSERT IGNORE INTO devin_tool_calls
                    (session_id, tool_call_id, tool_call_json, tool_call_update_json)
                    VALUES (%s, %s, %s, %s)""",
                    (obj.get("session_id"), tc_id, tc_json, tc_update)
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(rows)}, None)
        except Exception as e:
            return (0, None, ("SYNC_TOOL_CALLS_ERROR", str(e), 0))

    def _SyncRenderedCommits(self, params):
        try:
            mcur = self.state["mysql_cur"]
            mcur.execute("SELECT session_id, sequence_number FROM devin_rendered_commits")
            existing = set((r[0], r[1]) for r in mcur.fetchall())

            rows = self.state["catalog"]["rendered_commits"][1]
            inserted = 0
            for obj in rows:
                key = (obj.get("session_id"), obj.get("sequence_number"))
                if key in existing:
                    continue
                existing.add(key)
                ok, created_dt, _ = self._TsToDt({"ts": obj.get("created_at")})
                mcur.execute(
                    """INSERT IGNORE INTO devin_rendered_commits
                    (session_id, sequence_number, rendered_html, created_at, created_at_dt)
                    VALUES (%s, %s, %s, %s, %s)""",
                    (obj.get("session_id"), obj.get("sequence_number"),
                     obj.get("rendered_html", ""), obj.get("created_at"), created_dt)
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(rows)}, None)
        except Exception as e:
            return (0, None, ("SYNC_COMMITS_ERROR", str(e), 0))

    def _SyncTranscripts(self, params):
        try:
            mcur = self.state["mysql_cur"]
            transcripts_dir = self.state["config"]["DEVIN_TRANSCRIPTS_DIR"]
            if not os.path.isdir(transcripts_dir):
                return (1, {"inserted": 0, "total": 0}, None)

            mcur.execute("SELECT transcript_file FROM devin_transcripts")
            existing = set(r[0] for r in mcur.fetchall())

            files = sorted(glob.glob(os.path.join(transcripts_dir, "*.json")))
            inserted = 0
            for fpath in files:
                fname = os.path.basename(fpath)
                if fname in existing:
                    continue
                existing.add(fname)
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                try:
                    data = json.loads(content)
                    session_id = data.get("session_id", fname.replace(".json", ""))
                    schema_version = data.get("schema_version", "")
                    agent = data.get("agent", {}) or {}
                    agent_name = agent.get("name", "")
                    agent_version = agent.get("version", "")
                    model_name = agent.get("model_name", "")
                except (json.JSONDecodeError, ValueError):
                    session_id = fname.replace(".json", "")
                    schema_version = ""
                    agent_name = ""
                    agent_version = ""
                    model_name = ""
                mcur.execute(
                    """INSERT IGNORE INTO devin_transcripts
                    (session_id, transcript_file, schema_version, agent_name, agent_version, model_name, raw_json, imported_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())""",
                    (session_id, fname, schema_version, agent_name, agent_version, model_name, content)
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(files)}, None)
        except Exception as e:
            return (0, None, ("SYNC_TRANSCRIPTS_ERROR", str(e), 0))

    def _SyncSummaries(self, params):
        try:
            mcur = self.state["mysql_cur"]
            summaries_dir = self.state["config"]["DEVIN_SUMMARIES_DIR"]
            if not os.path.isdir(summaries_dir):
                return (1, {"inserted": 0, "total": 0}, None)

            mcur.execute("SELECT summary_file FROM devin_summaries")
            existing = set(r[0] for r in mcur.fetchall())

            files = sorted(glob.glob(os.path.join(summaries_dir, "*.md")))
            inserted = 0
            for fpath in files:
                fname = os.path.basename(fpath)
                if fname in existing:
                    continue
                existing.add(fname)
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                mcur.execute(
                    """INSERT IGNORE INTO devin_summaries
                    (summary_file, content, file_size, imported_at)
                    VALUES (%s, %s, %s, NOW())""",
                    (fname, content, len(content))
                )
                if mcur.rowcount > 0:
                    inserted += 1
            return (1, {"inserted": inserted, "total": len(files)}, None)
        except Exception as e:
            return (0, None, ("SYNC_SUMMARIES_ERROR", str(e), 0))

    def _ExtractFilePathsFromToolMsg(self, params):
        content = self._p(params, "content", "")
        if not content:
            return (1, [], None)
        paths = []
        for m in _FILE_VIEW_RE.finditer(content):
            p = m.group(1)
            if p.startswith("/") or p.startswith("~"):
                paths.append((p, "read"))
        for m in _FILE_CREATED_RE.finditer(content):
            p = m.group(1).strip()
            if (p.startswith("/") or p.startswith("~")) and "\t" not in p:
                paths.append((p, "write"))
        for m in _FILE_UPDATED_RE.finditer(content):
            p = m.group(1).strip()
            if (p.startswith("/") or p.startswith("~")) and "\t" not in p:
                paths.append((p, "edit"))
        return (1, paths, None)

    def _ExtractFilesFromToolCalls(self, params):
        chat_message_json = self._p(params, "chat_message_json", None)
        if not chat_message_json:
            return (1, [], None)
        try:
            obj = json.loads(chat_message_json) if isinstance(chat_message_json, str) else chat_message_json
        except (json.JSONDecodeError, ValueError):
            return (1, [], None)
        files = []
        for tc in obj.get("tool_calls", []):
            name = tc.get("name", "")
            args = tc.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except (json.JSONDecodeError, ValueError):
                    continue
            if name in ("write", "edit", "str_replace", "file_write", "file_edit"):
                path = args.get("file_path") or args.get("path")
                if not path:
                    continue
                if name in ("write", "file_write"):
                    content = args.get("content", "")
                elif name in ("edit", "str_replace", "file_edit"):
                    content = args.get("new_string") or args.get("newText") or args.get("content", "")
                else:
                    content = args.get("content", "")
                files.append({"path": path, "operation": name, "content": content})
        return (1, files, None)

    def _UpsertTurn(self, params):
        try:
            mcur = self.state["mysql_cur"]
            turn = self._p(params, "turn", {})
            existing = self._p(params, "existing", set())

            key = (turn["session_id"], turn["turn_seq"])
            files_json = json.dumps(turn["files"], ensure_ascii=False, default=str)
            file_paths = ", ".join(sorted({f["path"] for f in turn["files"]}))
            ok, created_dt, _ = self._TsToDt({"ts": turn["created_at"]})

            if key in existing:
                mcur.execute(
                    """UPDATE devin_chat_turns
                    SET user_message=%s, assistant_message=%s,
                        files_json=%s, file_paths=%s, created_at=%s, created_at_dt=%s
                    WHERE session_id=%s AND turn_seq=%s""",
                    (turn["user_message"][:16000000],
                     turn["assistant_message"][:16000000],
                     files_json[:16000000], file_paths,
                     turn["created_at"], created_dt,
                     turn["session_id"], turn["turn_seq"])
                )
                return (1, 0, None)

            existing.add(key)
            mcur.execute(
                """INSERT IGNORE INTO devin_chat_turns
                (session_id, turn_seq, user_message, assistant_message,
                 files_json, file_paths, created_at, created_at_dt)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                (turn["session_id"], turn["turn_seq"],
                 turn["user_message"][:16000000],
                 turn["assistant_message"][:16000000],
                 files_json[:16000000], file_paths,
                 turn["created_at"], created_dt)
            )
            if mcur.rowcount > 0:
                return (1, 1, None)
            return (1, 0, None)
        except Exception as e:
            return (1, 0, None)

    def _SyncChatTurns(self, params):
        try:
            mcur = self.state["mysql_cur"]

            mcur.execute("SELECT DISTINCT session_id FROM devin_messages")
            session_ids = [r[0] for r in mcur.fetchall()]

            mcur.execute("SELECT session_id, turn_seq FROM devin_chat_turns")
            existing = set((r[0], r[1]) for r in mcur.fetchall())

            rows = self.state["catalog"]["messages"][1]
            by_session = {}
            for obj in rows:
                sid = obj.get("session_id")
                by_session.setdefault(sid, []).append(obj)

            inserted = 0
            for sid in session_ids:
                msg_rows = by_session.get(sid, [])
                msg_rows.sort(key=lambda r: (r.get("created_at"), r.get("node_id")))

                turn_seq = 0
                current = None
                seen_paths_this_turn = set()
                for obj in msg_rows:
                    chat_msg_raw = obj.get("chat_message")
                    node_id = obj.get("node_id")
                    created_at = obj.get("created_at")
                    try:
                        msg = json.loads(chat_msg_raw) if isinstance(chat_msg_raw, str) else chat_msg_raw
                    except (json.JSONDecodeError, ValueError):
                        continue
                    role = msg.get("role", "")
                    content = msg.get("content", "") or ""

                    if role == "user":
                        if current is not None:
                            ok, count, _ = self._UpsertTurn({"turn": current, "existing": existing})
                            inserted += count
                        turn_seq += 1
                        current = {
                            "session_id": sid,
                            "turn_seq": turn_seq,
                            "user_message": content,
                            "assistant_message": "",
                            "files": [],
                            "created_at": created_at,
                        }
                        seen_paths_this_turn = set()
                    elif current is None:
                        continue
                    elif role == "assistant":
                        current["assistant_message"] += content + "\n"
                        ok, files, _ = self._ExtractFilesFromToolCalls({"chat_message_json": msg})
                        for f in files:
                            if f["path"] in seen_paths_this_turn:
                                continue
                            seen_paths_this_turn.add(f["path"])
                            current["files"].append(f)
                    elif role == "tool":
                        ok, paths, _ = self._ExtractFilePathsFromToolMsg({"content": content})
                        for path, op in paths:
                            if path in seen_paths_this_turn:
                                continue
                            seen_paths_this_turn.add(path)
                            current["files"].append({"path": path, "operation": op, "content": ""})
                if current is not None:
                    ok, count, _ = self._UpsertTurn({"turn": current, "existing": existing})
                    inserted += count

            return (1, {"inserted": inserted, "total_sessions": len(session_ids)}, None)
        except Exception as e:
            return (0, None, ("SYNC_CHAT_TURNS_ERROR", str(e), 0))

    def Sync(self, params):
        try:
            dry_run = self._p(params, "dry_run", False)

            ok, _, error = self._ConnectSqlite({})
            if not ok:
                return (0, None, error)

            ok, _, error = self._ConnectMysql({})
            if not ok:
                self._Close({})
                return (0, None, error)

            results = {}
            steps = [
                ("sessions", self._SyncSessions),
                ("messages", self._SyncMessages),
                ("tool_calls", self._SyncToolCalls),
                ("rendered_commits", self._SyncRenderedCommits),
                ("transcripts", self._SyncTranscripts),
                ("summaries", self._SyncSummaries),
                ("chat_turns", self._SyncChatTurns),
            ]

            for name, method in steps:
                if dry_run:
                    results[name] = {"dry_run": True}
                    continue
                ok, data, error = method({})
                if ok:
                    results[name] = data
                    self._LogImport({"step": name, "source": self.state["config"]["DEVIN_SQLITE_DB"], "rows": data.get("inserted", 0), "status": "OK"})
                else:
                    results[name] = {"error": str(error)}
                    self._LogImport({"step": name, "source": self.state["config"]["DEVIN_SQLITE_DB"], "rows": 0, "status": "ERROR", "error": str(error)})

            self._Close({})
            self.state["results"] = results
            return (1, results, None)
        except Exception as e:
            self._Close({})
            return (0, None, ("SYNC_ERROR", str(e), 0))

    def Status(self, params):
        try:
            ok, _, error = self._ConnectMysql({})
            if not ok:
                return (0, None, error)

            mcur = self.state["mysql_cur"]
            tables = [
                "devin_sessions", "devin_messages", "devin_tool_calls",
                "devin_rendered_commits", "devin_transcripts",
                "devin_summaries", "devin_chat_turns"
            ]
            counts = {}
            for table in tables:
                mcur.execute(f"SELECT COUNT(*) FROM {table}")
                counts[table] = mcur.fetchone()[0]

            mcur.execute("SELECT COUNT(*) FROM devin_messages WHERE role='user'")
            user_msgs = mcur.fetchone()[0]
            mcur.execute("SELECT COUNT(*) FROM devin_messages WHERE role='assistant'")
            assistant_msgs = mcur.fetchone()[0]
            mcur.execute("SELECT COUNT(*) FROM devin_messages WHERE role='tool'")
            tool_msgs = mcur.fetchone()[0]

            self._Close({})

            status = {
                "database": self.state["config"]["DB_NAME"],
                "counts": counts,
                "user_messages": user_msgs,
                "assistant_messages": assistant_msgs,
                "tool_messages": tool_msgs
            }
            self.state["results"] = status
            return (1, status, None)
        except Exception as e:
            self._Close({})
            return (0, None, ("STATUS_ERROR", str(e), 0))
