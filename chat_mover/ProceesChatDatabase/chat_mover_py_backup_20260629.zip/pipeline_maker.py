#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/pipeline_maker.py"
# date="2026-06-28" author="Cascade" session_id="pipeline-maker"
# context="PipelineMaker CLI: walks AI through structured pipeline .md creation with stage validation, gap detection, and RMD embedding"}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="pipeline_maker.py" domain="ChatMover" authority="PipelineMaker"}
#[@SUMMARY]{summary="PipelineMaker: CLI that guides AI through creating structured, validated, executable pipeline .md files. Each stage validated before advancing. Outputs RMD with embedded code."}
#[@CLASS]{class="PipelineMaker" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="New" type="command"}
#[@METHOD]{method="Inventory" type="stage"}
#[@METHOD]{method="Spec" type="stage"}
#[@METHOD]{method="Graph" type="stage"}
#[@METHOD]{method="RefineSpec" type="stage"}
#[@METHOD]{method="Stages" type="stage"}
#[@METHOD]{method="Testing" type="stage"}
#[@METHOD]{method="Executable" type="stage"}
#[@METHOD]{method="Output" type="stage"}
#[@METHOD]{method="Validate" type="command"}
#[@METHOD]{method="Status" type="command"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import re
import sys
import hashlib
import argparse
import subprocess
from datetime import datetime

BCL_DIR = os.path.dirname(os.path.abspath(__file__))
if BCL_DIR not in sys.path:
    sys.path.insert(0, BCL_DIR)

from bcl_pipeline import BCLState

FORBIDDEN_SPEC_KEYWORDS = [
    "class ", "def ", "import ", "for ", "while ", "sqlite3", "threading",
    "json.load", "json.dump", "json.loads", "json.dumps",
    "self.", "return ", "try:", "except", "lambda ", "async ", "await ",
    "print(", "open(", ".connect(", ".cursor(",
]

VAGUE_SPEC_TERMS = [
    "something", "maybe", "somehow", "someway", "kind of",
    "sort of", "fast", "quick", "efficient", "big", "large",
    "small", "good", "nice", "proper", "decent",
]

REQUIRED_SPEC_FIELDS = ["goal", "inputs", "outputs", "constraints"]

PIPELINE_STAGES = [
    {"name": "INVENTORY", "desc": "What files/resources exist?", "required": True},
    {"name": "SPEC", "desc": "What should the pipeline do?", "required": True},
    {"name": "GRAPH", "desc": "Analyze spec for missing nodes/edges", "required": True},
    {"name": "REFINE_SPEC", "desc": "Fill gaps, iterate on spec", "required": True},
    {"name": "STAGES", "desc": "Define each pipeline stage", "required": True},
    {"name": "TESTING", "desc": "Define test criteria for each stage", "required": True},
    {"name": "EXECUTABLE", "desc": "Embed code/binary as RMD", "required": False},
    {"name": "OUTPUT", "desc": "Generate final pipeline.rmd.md", "required": True},
]

STAGE_ORDER = [s["name"] for s in PIPELINE_STAGES]

MD_TEMPLATE = """# {title} Pipeline — {subtitle}

> **Core thesis:** {thesis}

---

## Pipeline Overview

```
{flow_diagram}
```

---

## Stage 1: INVENTORY — What exists?

{inventory}

---

## Stage 2: SPEC — What should the pipeline do?

{spec}

---

## Stage 3: GRAPH — Gap Analysis

{graph}

---

## Stage 4: REFINED SPEC — Gaps Filled

{refined_spec}

---

## Stage 5: STAGES — Pipeline Stage Definitions

{stages}

---

## Stage 6: TESTING — Test Criteria

{testing}

---

## Stage 7: EXECUTABLE — Embedded Code

{executable}

---

## Files

{files_table}

---

## Usage

{usage}

---

## Compression Stats

{stats}

"""


class PipelineMaker:
    """CLI that guides AI through creating structured pipeline .md files."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "output_dir": "/Users/wws/Qdrant_mysql_mlx_vector_engine/core/Piplines",
                "validate_strict": True,
            },
            "project_name": None,
            "subtitle": "",
            "thesis": "",
            "flow_diagram": "",
            "inventory": "",
            "spec": "",
            "graph": "",
            "refined_spec": "",
            "stages": "",
            "testing": "",
            "executable": "",
            "files_table": "",
            "usage": "",
            "stats": "",
            "current_stage": 0,
            "completed_stages": [],
            "stage_data": {},
            "gaps_found": [],
            "gaps_fixed": [],
            "output_path": None,
            "md_content": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "new":
            return self.New(params)
        elif command == "auto_flow":
            return self.AutoFlow(params)
        elif command == "inventory":
            return self.Inventory(params)
        elif command == "spec":
            return self.Spec(params)
        elif command == "graph":
            return self.Graph(params)
        elif command == "refine":
            return self.RefineSpec(params)
        elif command == "stages":
            return self.Stages(params)
        elif command == "testing":
            return self.Testing(params)
        elif command == "executable":
            return self.Executable(params)
        elif command == "output":
            return self.Output(params)
        elif command == "validate":
            return self.Validate(params)
        elif command == "status":
            return self.Status(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def _check_stage_order(self, stage_name):
        stage_idx = STAGE_ORDER.index(stage_name)
        if stage_idx > 0:
            prev_stage = STAGE_ORDER[stage_idx - 1]
            if prev_stage not in self.state["completed_stages"]:
                return (0, None, ("STAGE_VIOLATION",
                    "Must complete %s before %s. Completed: %s" % (
                        prev_stage, stage_name, self.state["completed_stages"]), 0))
        if stage_name in self.state["completed_stages"]:
            return (0, None, ("ALREADY_DONE",
                "Stage %s already completed. Use 'validate' to check." % stage_name, 0))
        return (1, True, None)

    def _complete_stage(self, stage_name, data):
        self.state["completed_stages"].append(stage_name)
        self.state["stage_data"][stage_name] = data
        self.state["current_stage"] = STAGE_ORDER.index(stage_name) + 1
        mem = self.state.get("memunit")
        if mem is not None:
            mem.write("pipeline.%s" % stage_name.lower(), data)
            mem.write("pipeline.current_stage", self.state["current_stage"])
            mem.write("pipeline.completed", list(self.state["completed_stages"]))
            mem.write("pipeline.gaps_found", list(self.state["gaps_found"]))
            mem.write("pipeline.gaps_fixed", list(self.state["gaps_fixed"]))
        return (1, {
            "stage": stage_name,
            "completed": True,
            "next_stage": STAGE_ORDER[self.state["current_stage"]] if self.state["current_stage"] < len(STAGE_ORDER) else None,
            "stages_completed": len(self.state["completed_stages"]),
            "total_stages": len(STAGE_ORDER),
        }, None)

    def New(self, params):
        name = self._p(params, "name")
        if not name:
            return (0, None, ("MISSING_PARAM", "name required", 0))
        self.state["project_name"] = name
        self.state["subtitle"] = self._p(params, "subtitle", name)
        self.state["thesis"] = self._p(params, "thesis", "")
        self.state["flow_diagram"] = self._p(params, "flow", "")
        self.state["completed_stages"] = []
        self.state["stage_data"] = {}
        self.state["gaps_found"] = []
        self.state["gaps_fixed"] = []
        self.state["current_stage"] = 0
        return (1, {
            "project": name,
            "stages": [{"name": s["name"], "desc": s["desc"], "required": s["required"]} for s in PIPELINE_STAGES],
            "first_stage": STAGE_ORDER[0],
            "instructions": "Call 'inventory' stage next with files/resources list",
        }, None)

    def AutoFlow(self, params):
        name = self._p(params, "name")
        if not name:
            return (0, None, ("MISSING_PARAM", "name required", 0))
        new_rv = self.New({"name": name, "subtitle": self._p(params, "subtitle", name),
                           "thesis": self._p(params, "thesis", ""),
                           "flow": self._p(params, "flow", "")})
        if new_rv[0] != 1:
            return new_rv
        stages_map = {
            "INVENTORY": {"files": self._p(params, "files", []),
                          "resources": self._p(params, "resources", []),
                          "notes": self._p(params, "notes", "")},
            "SPEC": {"spec": self._p(params, "spec", ""),
                     "capabilities": self._p(params, "capabilities", [])},
            "GRAPH": {"nodes": self._p(params, "nodes", []),
                      "edges": self._p(params, "edges", []),
                      "gaps": self._p(params, "gaps", [])},
            "REFINE_SPEC": {"refinements": self._p(params, "refinements", []),
                            "updated_spec": self._p(params, "updated_spec", "")},
            "STAGES": {"stages": self._p(params, "stages", [])},
            "TESTING": {"tests": self._p(params, "tests", [])},
            "EXECUTABLE": {"binary_path": self._p(params, "binary_path"),
                           "script_path": self._p(params, "script_path"),
                           "run_cmd": self._p(params, "run_cmd", ""),
                           "version": self._p(params, "version", "1")},
            "OUTPUT": {"output_path": self._p(params, "output_path")},
        }
        results = []
        for stage_name in STAGE_ORDER:
            stage_params = stages_map.get(stage_name, {})
            cmd_map = {
                "INVENTORY": "inventory", "SPEC": "spec", "GRAPH": "graph",
                "REFINE_SPEC": "refine", "STAGES": "stages", "TESTING": "testing",
                "EXECUTABLE": "executable", "OUTPUT": "output",
            }
            rv = self.Run(cmd_map[stage_name], stage_params)
            results.append({"stage": stage_name, "ok": rv[0], "data": rv[1] if rv[0] else None,
                            "error": str(rv[2]) if rv[2] else None})
            if rv[0] != 1:
                return (0, None, ("AUTO_FLOW_FAILED",
                    "Stage %s failed: %s" % (stage_name, str(rv[2])), 0))
        return (1, {
            "project": name,
            "stages_run": len(results),
            "all_completed": True,
            "output_path": self.state["output_path"],
            "gaps_found": len(self.state["gaps_found"]),
            "gaps_fixed": len(self.state["gaps_fixed"]),
            "results": results,
        }, None)

    def Inventory(self, params):
        rv = self._check_stage_order("INVENTORY")
        if rv[0] != 1:
            return rv
        files = self._p(params, "files", [])
        resources = self._p(params, "resources", [])
        notes = self._p(params, "notes", "")
        if not files and not resources:
            return (0, None, ("MISSING_DATA",
                "Inventory requires 'files' or 'resources' list", 0))
        lines = []
        if files:
            lines.append("### Files\n")
            lines.append("| File | Location | Purpose |")
            lines.append("|------|----------|---------|")
            for f in files:
                if isinstance(f, dict):
                    lines.append("| `%s` | `%s` | %s |" % (
                        f.get("name", "?"), f.get("path", "?"), f.get("purpose", "?")))
                else:
                    lines.append("| `%s` | — | — |" % str(f))
            lines.append("")
        if resources:
            lines.append("### Resources\n")
            for r in resources:
                if isinstance(r, dict):
                    lines.append("- **%s**: %s" % (r.get("name", "?"), r.get("desc", "?")))
                else:
                    lines.append("- %s" % str(r))
            lines.append("")
        if notes:
            lines.append("### Notes\n\n%s\n" % notes)
        inventory_text = "\n".join(lines)
        self.state["inventory"] = inventory_text
        return self._complete_stage("INVENTORY", {"files": files, "resources": resources, "notes": notes})

    def _AskGemini(self, prompt):
        gemini_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                   "Cascade_toolStack", "bin_tools", "gemini_cli.py")
        if not os.path.exists(gemini_path):
            return None
        try:
            rv = subprocess.run(
                ["python3", gemini_path, prompt],
                capture_output=True, text=True, timeout=120,
            )
            if rv.returncode == 0 and rv.stdout.strip():
                return rv.stdout.strip()
            return None
        except Exception:
            return None

    def _ValidateSpec(self, spec_text):
        spec_lower = spec_text.lower()
        found_keywords = [kw.strip() for kw in FORBIDDEN_SPEC_KEYWORDS if kw in spec_lower]
        found_vague = [term for term in VAGUE_SPEC_TERMS if term in spec_lower]
        missing_fields = [f for f in REQUIRED_SPEC_FIELDS if f not in spec_lower]
        if found_keywords:
            suggestion = self._AskGemini(
                "This pipeline spec contains implementation keywords: " + ", ".join(found_keywords) +
                ". Rewrite it to describe WHAT not HOW. Keep goal, inputs, outputs, constraints. Remove all code.\n\nSpec:\n" + spec_text
            )
            return (0, None, ("SPEC_DRIFT",
                "Spec contains implementation keywords: " + ", ".join(found_keywords) + ". Describe WHAT not HOW." +
                ("\n\nGemini suggests:\n" + suggestion if suggestion else ""), 0))
        if found_vague:
            suggestion = self._AskGemini(
                "This pipeline spec contains vague terms: " + ", ".join(found_vague) +
                ". Rewrite it with concrete metrics and specific values.\n\nSpec:\n" + spec_text
            )
            return (0, None, ("SPEC_AMBIGUOUS",
                "Spec contains vague terms: " + ", ".join(found_vague) + ". Use concrete metrics." +
                ("\n\nGemini suggests:\n" + suggestion if suggestion else ""), 0))
        if missing_fields:
            return (0, None, ("SPEC_INCOMPLETE",
                "Spec missing required fields: " + ", ".join(missing_fields), 0))
        return (1, {"valid": True}, None)

    def Spec(self, params):
        rv = self._check_stage_order("SPEC")
        if rv[0] != 1:
            return rv
        spec_text = self._p(params, "spec", "")
        capabilities = self._p(params, "capabilities", [])
        if not spec_text and not capabilities:
            return (0, None, ("MISSING_DATA",
                "Spec requires 'spec' text or 'capabilities' list", 0))
        if spec_text:
            rv = self._ValidateSpec(spec_text)
            if rv[0] != 1:
                return rv
        lines = []
        if spec_text:
            lines.append(spec_text)
            lines.append("")
        if capabilities:
            lines.append("### Capabilities\n")
            for cap in capabilities:
                if isinstance(cap, dict):
                    lines.append("- **%s**: %s" % (cap.get("name", "?"), cap.get("desc", "?")))
                else:
                    lines.append("- %s" % str(cap))
            lines.append("")
        spec_content = "\n".join(lines)
        self.state["spec"] = spec_content
        return self._complete_stage("SPEC", {"spec": spec_text, "capabilities": capabilities})

    def Graph(self, params):
        rv = self._check_stage_order("GRAPH")
        if rv[0] != 1:
            return rv
        nodes = self._p(params, "nodes", [])
        edges = self._p(params, "edges", [])
        gaps = self._p(params, "gaps", [])
        if not nodes:
            return (0, None, ("MISSING_DATA",
                "Graph requires 'nodes' list", 0))
        lines = []
        lines.append("### Nodes\n")
        for n in nodes:
            if isinstance(n, dict):
                lines.append("- **%s** (%s): %s" % (
                    n.get("name", "?"), n.get("type", "?"), n.get("desc", "?")))
            else:
                lines.append("- %s" % str(n))
        lines.append("")
        if edges:
            lines.append("### Edges\n")
            lines.append("| From | To | Type | Justification |")
            lines.append("|------|----|------|---------------|")
            for e in edges:
                if isinstance(e, dict):
                    lines.append("| %s | %s | %s | %s |" % (
                        e.get("from", "?"), e.get("to", "?"),
                        e.get("type", "?"), e.get("why", "?")))
                else:
                    lines.append("| %s | — | — | — |" % str(e))
            lines.append("")
        if gaps:
            lines.append("### Gaps Found\n")
            for g in gaps:
                if isinstance(g, dict):
                    lines.append("- **GAP**: %s — %s" % (
                        g.get("name", "?"), g.get("desc", "?")))
                else:
                    lines.append("- **GAP**: %s" % str(g))
            lines.append("")
            self.state["gaps_found"] = gaps
        else:
            lines.append("### Gaps Found\n\nNo gaps detected.\n")
        graph_content = "\n".join(lines)
        self.state["graph"] = graph_content
        return self._complete_stage("GRAPH", {"nodes": nodes, "edges": edges, "gaps": gaps})

    def RefineSpec(self, params):
        rv = self._check_stage_order("REFINE_SPEC")
        if rv[0] != 1:
            return rv
        refinements = self._p(params, "refinements", [])
        updated_spec = self._p(params, "updated_spec", "")
        if not refinements and not updated_spec:
            if self.state["gaps_found"]:
                return (0, None, ("GAPS_UNADDRESSED",
                    "%d gaps found but no refinements provided" % len(self.state["gaps_found"]), 0))
            updated_spec = self.state["spec"]
        lines = []
        if refinements:
            lines.append("### Gap Fixes\n")
            for r in refinements:
                if isinstance(r, dict):
                    lines.append("- **Fixed**: %s → %s" % (
                        r.get("gap", "?"), r.get("fix", "?")))
                else:
                    lines.append("- %s" % str(r))
            lines.append("")
            self.state["gaps_fixed"] = refinements
        if updated_spec:
            lines.append("### Refined Spec\n\n%s\n" % updated_spec)
        else:
            lines.append("### Refined Spec\n\n%s\n" % self.state["spec"])
        refined_content = "\n".join(lines)
        self.state["refined_spec"] = refined_content
        return self._complete_stage("REFINE_SPEC", {"refinements": refinements, "updated_spec": updated_spec})

    def Stages(self, params):
        rv = self._check_stage_order("STAGES")
        if rv[0] != 1:
            return rv
        stage_defs = self._p(params, "stages", [])
        if not stage_defs:
            return (0, None, ("MISSING_DATA",
                "Stages requires 'stages' list with stage definitions", 0))
        lines = []
        lines.append("| # | Stage | Input | Output | Command |")
        lines.append("|---|-------|-------|--------|---------|")
        for i, s in enumerate(stage_defs, 1):
            if isinstance(s, dict):
                lines.append("| %d | %s | %s | %s | `%s` |" % (
                    i, s.get("name", "?"), s.get("input", "?"),
                    s.get("output", "?"), s.get("cmd", "?")))
            else:
                lines.append("| %d | %s | — | — | — |" % (i, str(s)))
        lines.append("")
        lines.append("### Stage Details\n")
        for i, s in enumerate(stage_defs, 1):
            if isinstance(s, dict):
                lines.append("#### Stage %d: %s\n" % (i, s.get("name", "?")))
                lines.append("- **Input**: %s" % s.get("input", "?"))
                lines.append("- **Output**: %s" % s.get("output", "?"))
                lines.append("- **Command**: `%s`" % s.get("cmd", "?"))
                if s.get("desc"):
                    lines.append("- **Description**: %s" % s["desc"])
                lines.append("")
        stages_content = "\n".join(lines)
        self.state["stages"] = stages_content
        return self._complete_stage("STAGES", {"stages": stage_defs})

    def Testing(self, params):
        rv = self._check_stage_order("TESTING")
        if rv[0] != 1:
            return rv
        tests = self._p(params, "tests", [])
        if not tests:
            return (0, None, ("MISSING_DATA",
                "Testing requires 'tests' list with test criteria", 0))
        lines = []
        lines.append("| # | Stage | Test | Command | Expected |")
        lines.append("|---|-------|------|---------|----------|")
        for i, t in enumerate(tests, 1):
            if isinstance(t, dict):
                lines.append("| %d | %s | %s | `%s` | %s |" % (
                    i, t.get("stage", "?"), t.get("name", "?"),
                    t.get("cmd", "?"), t.get("expected", "?")))
            else:
                lines.append("| %d | — | %s | — | — |" % (i, str(t)))
        lines.append("")
        lines.append("### Test Details\n")
        for i, t in enumerate(tests, 1):
            if isinstance(t, dict):
                lines.append("#### Test %d: %s\n" % (i, t.get("name", "?")))
                lines.append("- **Stage**: %s" % t.get("stage", "?"))
                lines.append("- **Command**: `%s`" % t.get("cmd", "?"))
                lines.append("- **Expected**: %s" % t.get("expected", "?"))
                if t.get("on_fail"):
                    lines.append("- **On Fail**: %s" % t["on_fail"])
                lines.append("")
        testing_content = "\n".join(lines)
        self.state["testing"] = testing_content
        return self._complete_stage("TESTING", {"tests": tests})

    def Executable(self, params):
        rv = self._check_stage_order("EXECUTABLE")
        if rv[0] != 1:
            return rv
        binary_path = self._p(params, "binary_path")
        script_path = self._p(params, "script_path")
        run_cmd = self._p(params, "run_cmd", "")
        version = self._p(params, "version", "1")
        if not binary_path and not script_path:
            self.state["executable"] = "No embedded binary. Pipeline uses external scripts."
            return self._complete_stage("EXECUTABLE", {"embedded": False})
        target = binary_path or script_path
        if not os.path.isfile(target):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + target, 0))
        try:
            from rmd_packer import RmdPacker
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            try:
                from rmd_packer import RmdPacker
            except ImportError:
                self.state["executable"] = "RMD packer not available. Binary: `%s`" % target
                return self._complete_stage("EXECUTABLE", {"embedded": False, "path": target})
        packer = RmdPacker()
        tmp_md = os.path.join("/tmp", "rmd_stage_tmp.md")
        with open(tmp_md, "w") as f:
            f.write("# temp")
        pack_rv = packer.Run("pack", {
            "md_path": tmp_md,
            "binary_path": target,
            "run_cmd": run_cmd,
            "version": version,
            "output_path": tmp_md,
        })
        if pack_rv[0] != 1:
            return (0, None, ("PACK_ERROR", str(pack_rv[2]), 0))
        with open(tmp_md, "r") as f:
            content = f.read()
        tag_start = content.find("#[@RUNNABLE]")
        if tag_start >= 0:
            tag_block = content[tag_start:]
            self.state["executable"] = tag_block
        else:
            self.state["executable"] = "Binary: `%s` (RMD pack failed silently)" % target
        os.unlink(tmp_md)
        return self._complete_stage("EXECUTABLE", {
            "embedded": True,
            "path": target,
            "size": pack_rv[1].get("binary_size", 0),
            "md5": pack_rv[1].get("md5", ""),
        })

    def Output(self, params):
        rv = self._check_stage_order("OUTPUT")
        if rv[0] != 1:
            return rv
        output_path = self._p(params, "output_path")
        if not output_path:
            safe_name = re.sub(r"[^A-Za-z0-9_]", "_", self.state["project_name"] or "pipeline").upper()
            output_path = os.path.join(self.state["config"]["output_dir"], safe_name + "_PIPELINE.md")
        if not self.state["executable"]:
            self.state["executable"] = "No embedded binary. Pipeline uses external scripts."
        if not self.state["files_table"]:
            self.state["files_table"] = "| File | Location | Purpose |\n|------|----------|---------|\n| (auto-generated) | — | — |"
        if not self.state["usage"]:
            self.state["usage"] = "```bash\n# See stage definitions above for commands\n```"
        if not self.state["stats"]:
            self.state["stats"] = "| Metric | Value |\n|--------|-------|\n| Stages | %d |\n| Gaps Found | %d |\n| Gaps Fixed | %d |" % (
                len(self.state["stage_data"].get("STAGES", {}).get("stages", [])),
                len(self.state["gaps_found"]),
                len(self.state["gaps_fixed"]),
            )
        replacements = {
            "{title}": self.state["project_name"] or "Untitled",
            "{subtitle}": self.state["subtitle"] or "",
            "{thesis}": self.state["thesis"] or "(not specified)",
            "{flow_diagram}": self.state["flow_diagram"] or " -> ".join(STAGE_ORDER),
            "{inventory}": self.state["inventory"] or "(not specified)",
            "{spec}": self.state["spec"] or "(not specified)",
            "{graph}": self.state["graph"] or "(not specified)",
            "{refined_spec}": self.state["refined_spec"] or "(not specified)",
            "{stages}": self.state["stages"] or "(not specified)",
            "{testing}": self.state["testing"] or "(not specified)",
            "{executable}": self.state["executable"] or "(none)",
            "{files_table}": self.state["files_table"],
            "{usage}": self.state["usage"],
            "{stats}": self.state["stats"],
        }
        md = MD_TEMPLATE
        for placeholder, value in replacements.items():
            md = md.replace(placeholder, str(value))
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(md)
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))
        self.state["output_path"] = output_path
        self.state["md_content"] = md
        return self._complete_stage("OUTPUT", {
            "output_path": output_path,
            "size": len(md),
            "lines": md.count("\n") + 1,
        })

    def Validate(self, params):
        stage = self._p(params, "stage")
        if stage:
            if stage not in STAGE_ORDER:
                return (0, None, ("INVALID_STAGE", "Unknown stage: " + stage, 0))
            if stage in self.state["completed_stages"]:
                data = self.state["stage_data"].get(stage, {})
                return (1, {"stage": stage, "status": "COMPLETED", "data": data}, None)
            return (1, {"stage": stage, "status": "PENDING"}, None)
        results = []
        for s in PIPELINE_STAGES:
            name = s["name"]
            status = "COMPLETED" if name in self.state["completed_stages"] else "PENDING"
            results.append({
                "name": name,
                "desc": s["desc"],
                "required": s["required"],
                "status": status,
            })
        completed = len(self.state["completed_stages"])
        total = len(STAGE_ORDER)
        all_done = completed == total
        return (1, {
            "stages": results,
            "completed": completed,
            "total": total,
            "all_done": all_done,
            "gaps_found": len(self.state["gaps_found"]),
            "gaps_fixed": len(self.state["gaps_fixed"]),
            "output_path": self.state["output_path"],
        }, None)

    def Status(self, params):
        completed = self.state["completed_stages"]
        current = STAGE_ORDER[self.state["current_stage"]] if self.state["current_stage"] < len(STAGE_ORDER) else "DONE"
        return (1, {
            "project": self.state["project_name"],
            "current_stage": current,
            "completed": completed,
            "stages_completed": len(completed),
            "total_stages": len(STAGE_ORDER),
            "gaps_found": len(self.state["gaps_found"]),
            "gaps_fixed": len(self.state["gaps_fixed"]),
            "output_path": self.state["output_path"],
        }, None)


def main():
    parser = argparse.ArgumentParser(
        description="PipelineMaker — structured pipeline .md creation CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Workflow:
  1. python3 pipeline_maker.py new --name "My Pipeline" --thesis "..."
  2. python3 pipeline_maker.py inventory --files-bcl '[@Files]{...}'
  3. python3 pipeline_maker.py spec --spec "..." --capabilities-bcl '[@Caps]{...}'
  4. python3 pipeline_maker.py graph --nodes-bcl '[@Nodes]{...}' --gaps-bcl '[@Gaps]{...}'
  5. python3 pipeline_maker.py refine --refinements-bcl '[@Fixes]{...}'
  6. python3 pipeline_maker.py stages --stages-bcl '[@Stages]{...}'
  7. python3 pipeline_maker.py testing --tests-bcl '[@Tests]{...}'
  8. python3 pipeline_maker.py executable --binary /path/to/binary
  9. python3 pipeline_maker.py output --output /path/to/pipeline.md

Check progress:
  python3 pipeline_maker.py status
  python3 pipeline_maker.py validate

All data I/O uses BCL (Bracket Command Language), NOT JSON.
BCL format: [@Container]{("key";"value")("key2";123)[@Child]{...}}
        """)
    sub = parser.add_subparsers(dest="command")

    new_p = sub.add_parser("new", help="Start a new pipeline")
    new_p.add_argument("--name", required=True, help="Pipeline name")
    new_p.add_argument("--subtitle", help="Short subtitle")
    new_p.add_argument("--thesis", help="Core thesis (one sentence)")
    new_p.add_argument("--flow", help="Flow diagram (ASCII arrows)")

    inv_p = sub.add_parser("inventory", help="Stage 1: List files/resources")
    inv_p.add_argument("--files-bcl", help="BCL list of files")
    inv_p.add_argument("--resources-bcl", help="BCL list of resources")
    inv_p.add_argument("--notes", help="Additional notes")

    spec_p = sub.add_parser("spec", help="Stage 2: Define what pipeline does")
    spec_p.add_argument("--spec", help="Spec text")
    spec_p.add_argument("--capabilities-bcl", help="BCL list of capabilities")

    graph_p = sub.add_parser("graph", help="Stage 3: Gap analysis")
    graph_p.add_argument("--nodes-bcl", required=True, help="BCL list of nodes")
    graph_p.add_argument("--edges-bcl", help="BCL list of edges")
    graph_p.add_argument("--gaps-bcl", help="BCL list of gaps found")

    ref_p = sub.add_parser("refine", help="Stage 4: Fill gaps")
    ref_p.add_argument("--refinements-bcl", help="BCL list of gap fixes")
    ref_p.add_argument("--updated-spec", help="Updated spec text")

    stg_p = sub.add_parser("stages", help="Stage 5: Define pipeline stages")
    stg_p.add_argument("--stages-bcl", required=True, help="BCL list of stage defs")

    test_p = sub.add_parser("testing", help="Stage 6: Define test criteria")
    test_p.add_argument("--tests-bcl", required=True, help="BCL list of test criteria")

    exe_p = sub.add_parser("executable", help="Stage 7: Embed code/binary")
    exe_p.add_argument("--binary", help="Path to compiled binary")
    exe_p.add_argument("--script", help="Path to Python script")
    exe_p.add_argument("--cmd", help="Run command")
    exe_p.add_argument("--version", default="1", help="Version label")

    out_p = sub.add_parser("output", help="Stage 8: Generate pipeline.md")
    out_p.add_argument("--output", help="Output path")

    sub.add_parser("status", help="Show current progress")
    sub.add_parser("validate", help="Validate all stages")

    parser.add_argument("--state-file", default="/tmp/pipeline_maker_state.bcl",
                        help="State file path (default: /tmp/pipeline_maker_state.bcl)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    maker = PipelineMaker()

    state_file = args.state_file
    bcl = BCLState()
    if os.path.isfile(state_file) and args.command not in ("new",):
        try:
            with open(state_file, "r") as f:
                saved_text = f.read()
            des_rv = bcl.Deserialize({"text": saved_text})
            if des_rv[0] == 1 and des_rv[1]:
                saved = des_rv[1]
                for key, value in saved.items():
                    if key != "config":
                        maker.state[key] = value
        except Exception:
            pass

    def bcl_list(text):
        if not text:
            return []
        rv = bcl.Deserialize({"text": text})
        if rv[0] != 1 or not rv[1]:
            return []
        for key, val in rv[1].items():
            if isinstance(val, list):
                return val
            if isinstance(val, dict):
                return list(val.values())
        return []

    params = {}
    if args.command == "new":
        params = {"name": args.name, "subtitle": args.subtitle, "thesis": args.thesis, "flow": args.flow}
        rv = maker.Run("new", params)
    elif args.command == "inventory":
        params = {}
        if args.files_bcl:
            params["files"] = bcl_list(args.files_bcl)
        if args.resources_bcl:
            params["resources"] = bcl_list(args.resources_bcl)
        if args.notes:
            params["notes"] = args.notes
        rv = maker.Run("inventory", params)
    elif args.command == "spec":
        params = {}
        if args.spec:
            params["spec"] = args.spec
        if args.capabilities_bcl:
            params["capabilities"] = bcl_list(args.capabilities_bcl)
        rv = maker.Run("spec", params)
    elif args.command == "graph":
        params = {"nodes": bcl_list(args.nodes_bcl)}
        if args.edges_bcl:
            params["edges"] = bcl_list(args.edges_bcl)
        if args.gaps_bcl:
            params["gaps"] = bcl_list(args.gaps_bcl)
        rv = maker.Run("graph", params)
    elif args.command == "refine":
        params = {}
        if args.refinements_bcl:
            params["refinements"] = bcl_list(args.refinements_bcl)
        if args.updated_spec:
            params["updated_spec"] = args.updated_spec
        rv = maker.Run("refine", params)
    elif args.command == "stages":
        params = {"stages": bcl_list(args.stages_bcl)}
        rv = maker.Run("stages", params)
    elif args.command == "testing":
        params = {"tests": bcl_list(args.tests_bcl)}
        rv = maker.Run("testing", params)
    elif args.command == "executable":
        params = {"version": args.version}
        if args.binary:
            params["binary_path"] = args.binary
        if args.script:
            params["script_path"] = args.script
        if args.cmd:
            params["run_cmd"] = args.cmd
        rv = maker.Run("executable", params)
    elif args.command == "output":
        params = {}
        if args.output:
            params["output_path"] = args.output
        rv = maker.Run("output", params)
    elif args.command == "status":
        rv = maker.Run("status", params)
    elif args.command == "validate":
        rv = maker.Run("validate", params)
    else:
        parser.print_help()
        sys.exit(1)

    if rv[0] == 1:
        ser_rv = bcl.Serialize({"data": rv[1], "name": "Result"})
        if ser_rv[0] == 1:
            print(ser_rv[1])
        else:
            print('[@Result]{("error";"serialize failed")}')
        try:
            saveable = {k: v for k, v in maker.state.items() if k not in ("config", "memunit", "db_manager")}
            save_rv = bcl.Serialize({"data": saveable, "name": "PipelineState"})
            if save_rv[0] == 1:
                with open(state_file, "w") as f:
                    f.write(save_rv[1])
        except Exception:
            pass
    else:
        err_str = str(rv[2])
        err_escaped = err_str.replace('"', '\\"').replace("\n", "\\n")
        print('[@Error]{("detail";"' + err_escaped + '")}', file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
