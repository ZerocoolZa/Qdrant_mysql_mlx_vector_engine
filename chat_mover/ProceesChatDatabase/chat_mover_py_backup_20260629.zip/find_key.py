#!/usr/bin/env python3
"""Find the AES key via Go slice header pattern in a Mach-O core dump.

Strategy:
1. Build a map: virtual address → file offset (from Mach-O LC_SEGMENT_64 entries)
2. Scan all RW data for 24-byte regions matching SliceHeader pattern:
     bytes[0:8]  = pointer (some 8-byte value, must be in mapped range)
     bytes[8:16] = length (uint64 LE, must be 16, 24, or 32 — common AES/ChaCha key sizes)
     bytes[16:24]= capacity (uint64 LE, must equal length)
3. For each candidate slice header, follow ptr to actual key bytes
4. Test each as encryption key against a .pb file

Much faster: SliceHeader pattern is very specific, candidates count ~ hundreds.
"""
import os
import sys
import struct
import math
from collections import Counter
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305

# Configure these three paths before running.
# The .core file is obtained via:  lldb -b -o "process attach --pid $(pgrep -f language_server | head -1)" -o "process save-core ./language-server.core" -o "detach"
DUMP = "./language-server.core"
TARGET_PB = os.path.expanduser("~/.codeium/windsurf/cascade/<your-trajectory-uuid>.pb")
KEY_OUT = "./cascade_key.bin"


def parse_macho_regions(path):
    """Yield list of (segname, vmaddr, vmsize, fileoff, fsize, prot)."""
    with open(path, 'rb') as f:
        magic = f.read(4)
        assert magic == b'\xcf\xfa\xed\xfe'
        cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags, reserved = struct.unpack('<iiiIIII', f.read(28))
        regions = []
        for _ in range(ncmds):
            lc_pos = f.tell()
            cmd, cmdsize = struct.unpack('<II', f.read(8))
            f.seek(lc_pos)
            f.read(8)
            if cmd == 0x19:  # LC_SEGMENT_64
                segname = f.read(16).rstrip(b'\x00').decode('ascii', errors='replace')
                vmaddr, vmsize, fileoff, fsize, maxprot, initprot, nsects, flags2 = \
                    struct.unpack('<QQQQIIII', f.read(48))
                regions.append((segname, vmaddr, vmsize, fileoff, fsize, initprot))
                f.seek(lc_pos + cmdsize)
            else:
                f.seek(lc_pos + cmdsize)
        return regions


def build_vm_to_file_map(regions):
    """Sorted list of (vmaddr_start, vmaddr_end, fileoff, fsize) for fast lookup."""
    intervals = []
    for name, vmaddr, vmsize, fileoff, fsize, prot in regions:
        if fsize > 0:
            intervals.append((vmaddr, vmaddr + fsize, fileoff, fsize))
    intervals.sort()
    return intervals


def vm_to_file(intervals, vmaddr, length):
    """Translate virtual address to file offset. Return None if not in mapped range."""
    import bisect
    starts = [iv[0] for iv in intervals]
    idx = bisect.bisect_right(starts, vmaddr) - 1
    if idx < 0:
        return None
    vstart, vend, fileoff, fsize = intervals[idx]
    if vmaddr + length > vend:
        return None
    return fileoff + (vmaddr - vstart)


def shannon_entropy(b):
    if not b: return 0
    c = Counter(b)
    total = len(b)
    return -sum((cnt/total) * math.log2(cnt/total) for cnt in c.values())


def try_decrypt(key, ciphertext):
    """Try AES-GCM (12-byte nonce) and ChaCha20-Poly1305 (12-byte nonce)."""
    if len(ciphertext) < 28:
        return None, None
    nonce = ciphertext[:12]
    ct_tag = ciphertext[12:]
    # AES-GCM (key 16 or 32)
    if len(key) in (16, 24, 32):
        try:
            return "AES-GCM", AESGCM(key).decrypt(nonce, ct_tag, None)
        except Exception:
            pass
    # ChaCha20-Poly1305 (key 32 only)
    if len(key) == 32:
        try:
            return "ChaCha20-Poly1305", ChaCha20Poly1305(key).decrypt(nonce, ct_tag, None)
        except Exception:
            pass
    return None, None


def main():
    pass  # TODO: replace with Report
    with open(TARGET_PB, 'rb') as f:
        target = f.read()
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    regions = parse_macho_regions(DUMP)
    intervals = build_vm_to_file_map(regions)
    pass  # TODO: replace with Report
    # Determine vm range
    vm_min = min(iv[0] for iv in intervals)
    vm_max = max(iv[1] for iv in intervals)
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    candidate_count = 0
    tested = 0
    found_keys = []
    seen_keys = set()

    with open(DUMP, 'rb') as f:
        for seg_idx, (vstart, vend, fileoff, fsize) in enumerate(intervals):
            f.seek(fileoff)
            buf = f.read(fsize)
            # 8-byte aligned scan
            for off in range(0, len(buf) - 24, 8):
                # Read 3 uint64 LE
                ptr = int.from_bytes(buf[off:off+8], 'little')
                length = int.from_bytes(buf[off+8:off+16], 'little')
                capacity = int.from_bytes(buf[off+16:off+24], 'little')

                # Filter: length must be 16/24/32 and cap == length
                if length not in (16, 24, 32):
                    continue
                if capacity != length:
                    continue
                # Pointer must be in mapped range
                if ptr < vm_min or ptr >= vm_max:
                    continue
                candidate_count += 1

                # Translate ptr to file offset
                key_fileoff = vm_to_file(intervals, ptr, length)
                if key_fileoff is None:
                    continue

                # Read key bytes
                f_save = f.tell()
                f.seek(key_fileoff)
                key = f.read(length)
                f.seek(f_save)

                if len(key) != length:
                    continue

                # Reject all-zeros / low-entropy
                if key.count(0) > length // 4:
                    continue
                if len(set(key)) < length // 2:
                    continue
                e = shannon_entropy(key)
                if e < 3.5:
                    continue

                kh = bytes(key)
                if kh in seen_keys:
                    continue
                seen_keys.add(kh)

                tested += 1
                # Try decryption
                algo, pt = try_decrypt(key, target)
                if pt:
                    pass  # TODO: replace with Report
                    pass  # TODO: replace with Report
                    pass  # TODO: replace with Report
                    pass  # TODO: replace with Report
                    pass  # TODO: replace with Report
                    pass  # TODO: replace with Report
                    with open(KEY_OUT, 'wb') as kf:
                        kf.write(key)
                    pass  # TODO: replace with Report
                    found_keys.append((algo, length, key))
                    # Don't return — keep searching for more

                if tested % 1000 == 0:
                    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    if found_keys:
        pass  # TODO: replace with Report
        return 0
    else:
        pass  # TODO: replace with Report
        return 1


if __name__ == "__main__":
    sys.exit(main())
