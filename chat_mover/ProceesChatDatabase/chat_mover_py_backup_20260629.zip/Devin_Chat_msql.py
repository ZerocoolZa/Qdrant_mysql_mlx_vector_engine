#!/usr/bin/env python3
"""
Import Devin CLI raw transcripts into Chat_History MySQL.

Transcript format (schema_version ATIF-v1.7):
  {
    "schema_version": "ATIF-v1.7",
    "session_id": "abyssinian-show",
    "agent": { "name": "devin", "version": "...", "model_name": "..." },
    "steps": [
      { "step_id": 1, "timestamp": "...", "source": "system|user|agent",
        "message": "...", "extra": {...} },
      ...
    ],
    "final_metrics": {...}
  }

The existing chat_mover.parse_json_chat() does NOT handle this `steps`-based
format (it expects `messages`/`mapping`/`conversation` keys), so this script
provides a dedicated parser + importer.

Usage:
  cd /Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover
  python3 import_devin_transcripts.py
  python3 import_devin_transcripts.py --dry-run
  python3 import_devin_transcripts.py --folder ~/.local/share/devin/cli/transcripts/
"""

import argparse
import glob
import hashlib
import json
import os
import sys
from datetime import datetime

try:
    import mysql.connector
except ImportError:
    pass  # TODO: replace with Report
    sys.exit(1)

from Config import cfg

# Map transcript `source` values to Chat_History roles.
SOURCE_TO_ROLE = {
    "user": "user",
    "agent": "assistant",   # Devin agent responses = assistant
    "system": "system",
}


def parse_transcript(filepath):
    """Parse a single Devin CLI transcript JSON into a session dict.

    Returns:
      {
        "session_id": str,        # transcript session_id (e.g. "abyssinian-show")
        "title": str,             # meaningful session title
        "model": str,             # agent model_name if available
        "created_at": str,        # ISO timestamp of first step
        "messages": [ {role, content, sequence, timestamp}, ... ],
        "content_hash": str,      # SHA-256 of all message content
      }
      or None if the file cannot be parsed / has no usable messages.
    """
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        pass  # TODO: replace with Report
        return None

    if not isinstance(data, dict):
        pass  # TODO: replace with Report
        return None

    steps = data.get("steps", [])
    if not isinstance(steps, list) or not steps:
        pass  # TODO: replace with Report
        return None

    session_id = data.get("session_id") or os.path.splitext(os.path.basename(filepath))[0]
    agent_info = data.get("agent", {}) or {}
    model = agent_info.get("model_name", "") or ""

    # Build a meaningful title: session_id + first user message snippet.
    first_user_msg = ""
    for s in steps:
        if s.get("source") == "user" and s.get("message", "").strip():
            first_user_msg = s["message"].strip().replace("\n", " ")[:80]
            break

    if first_user_msg:
        title = f"{session_id}: {first_user_msg}"
    else:
        title = session_id

    if len(title) > 300:
        title = title[:300]

    # Extract messages — skip empty messages (e.g. pure tool-call steps).
    messages = []
    seq = 0
    first_ts = None
    for step in steps:
        src = step.get("source", "")
        role = SOURCE_TO_ROLE.get(src)
        if role is None:
            # Unknown source — treat as system for traceability.
            role = "system"
        msg_text = step.get("message", "")
        if not msg_text or not msg_text.strip():
            continue
        ts = step.get("timestamp", "")
        if first_ts is None and ts:
            first_ts = ts
        messages.append({
            "role": role,
            "content": str(msg_text),
            "sequence": seq,
            "timestamp": ts,
        })
        seq += 1

    if not messages:
        pass  # TODO: replace with Report
        return None

    combined = "\n".join(m["content"] for m in messages)
    content_hash = hashlib.sha256(combined.encode("utf-8")).hexdigest()

    return {
        "session_id": session_id,
        "title": title,
        "model": model,
        "created_at": first_ts,
        "messages": messages,
        "content_hash": content_hash,
        "file_path": filepath,
    }


def import_session(cur, session, source_db="disk", source_table="devin_transcripts"):
    """Insert one parsed session into sessions + messages + prompts tables.

    Live Chat_History schema (matches Config.py SCHEMA_SQL):
      sessions:  row_id, session_name, model, created_at(bigint), imported_at,
                 source_db, source_table, source_format, source_created_at,
                 source_modified_at, message_count, status, content_hash, metadata
      messages:  row_id, session_id, role, content, sequence, source_row_id,
                 embedded, created_at
      prompts:   row_id, session_id, prompt_text, prompt_type, created_at

    Dedup by content_hash, then by (source_db, source_table, session_name).

    Returns True if imported, False if skipped (duplicate).
    """
    title = session["title"]
    content_hash = session["content_hash"]

    # Dedup by content_hash.
    cur.execute(
        "SELECT row_id FROM sessions WHERE content_hash=%s",
        (content_hash,)
    )
    if cur.fetchone():
        pass  # TODO: replace with Report
        return False

    # Dedup by source_db + source_table + session_name.
    cur.execute(
        "SELECT row_id FROM sessions WHERE source_db=%s AND source_table=%s AND session_name=%s",
        (source_db, source_table, title)
    )
    if cur.fetchone():
        pass  # TODO: replace with Report
        return False

    metadata = json.dumps({
        "transcript_session_id": session["session_id"],
        "file_path": session["file_path"],
        "schema_source": "devin_cli_transcript",
    })

    cur.execute(
        """INSERT INTO sessions
           (session_name, source_db, source_table, source_format,
            source_created_at, source_modified_at, message_count, status, content_hash, metadata)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (title, source_db, source_table, ".json",
         session.get("created_at"), session.get("created_at"),
         len(session["messages"]), "imported", content_hash, metadata)
    )
    session_row_id = cur.lastrowid

    # Insert messages in batches.
    batch_size = 500
    msgs = session["messages"]
    for i in range(0, len(msgs), batch_size):
        batch = msgs[i:i + batch_size]
        values = [(session_row_id, 0, m["role"], m["content"], m["sequence"], None)
                  for m in batch]
        cur.executemany(
            "INSERT INTO messages (session_id, node_id, role, content, sequence, source_row_id) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            values
        )

    # Insert prompts (user messages).
    first_user = True
    for m in msgs:
        if m["role"] == "user":
            cur.execute(
                "INSERT INTO prompts (session_id, content) VALUES (%s, %s)",
                (session_row_id, m["content"])
            )
            first_user = False

    return True


def _iso_to_epoch_ms(iso_str):
    """Convert an ISO-8601 timestamp to unix epoch milliseconds (bigint).

    Returns None if input is empty/invalid. Kept for reference; the live
    sessions table stores source_created_at as a TIMESTAMP string.
    """
    if not iso_str:
        return None
    s = iso_str.strip()
    try:
        dt = datetime.fromisoformat(s)
        return int(dt.timestamp() * 1000)
    except (ValueError, TypeError):
        pass
    try:
        import re
        core = re.sub(r'(\.\d+)?([+-]\d{2}(:?\d{2})?)$', '', s)
        dt = datetime.fromisoformat(core)
        return int(dt.timestamp() * 1000)
    except (ValueError, TypeError):
        return None


def main():
    parser = argparse.ArgumentParser(description="Import Devin CLI raw transcripts into Chat_History MySQL.")
    parser.add_argument("--folder", default=os.path.expanduser("~/.local/share/devin/cli/transcripts/"),
                        help="Folder containing transcript .json files")
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse only, do not write to MySQL")
    args = parser.parse_args()

    folder = os.path.expanduser(args.folder)
    if not os.path.isdir(folder):
        pass  # TODO: replace with Report
        sys.exit(1)

    files = sorted(glob.glob(os.path.join(folder, "*.json")))
    if not files:
        pass  # TODO: replace with Report
        sys.exit(0)

    pass  # TODO: replace with Report
    print()

    sessions = []
    for fp in files:
        pass  # TODO: replace with Report
        sess = parse_transcript(fp)
        if sess:
            print(f"  -> {sess['session_id']}: {len(sess['messages'])} messages, "
                  f"model={sess['model'] or 'n/a'}")
            sessions.append(sess)

    total_messages = sum(len(s["messages"]) for s in sessions)
    print()
    pass  # TODO: replace with Report
    if args.dry_run:
        pass  # TODO: replace with Report
        for s in sessions:
            pass  # TODO: replace with Report
        return

    if not sessions:
        pass  # TODO: replace with Report
        return

    # Connect to MySQL.
    mc = cfg.GetMysqlConfig()
    dest_db = cfg.DESTINATION_DB()
    pass  # TODO: replace with Report
    conn = mysql.connector.connect(
        host=mc["host"], port=mc["port"],
        user=mc["user"], password=mc["password"],
        database=dest_db, charset="utf8mb4",
        autocommit=False, connection_timeout=10,
    )
    cur = conn.cursor()

    # Debug: verify we're in the right database and schema.
    cur.execute("SELECT DATABASE()")
    db_name = cur.fetchone()[0]
    pass  # TODO: replace with Report
    cur.execute("SELECT row_id, session_name FROM sessions ORDER BY row_id DESC LIMIT 1")
    row = cur.fetchone()
    pass  # TODO: replace with Report
    imported = 0
    skipped = 0
    imported_messages = 0
    try:
        for s in sessions:
            pass  # TODO: replace with Report
            ok = import_session(cur, s)
            if ok:
                imported += 1
                imported_messages += len(s["messages"])
                pass  # TODO: replace with Report
            else:
                skipped += 1
        conn.commit()
    except Exception as e:
        conn.rollback()
        pass  # TODO: replace with Report
        raise
    finally:
        cur.close()
        conn.close()

    print()
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
if __name__ == "__main__":
    main()
