#!/usr/bin/env python3
"""Generate CodeGPS Repair Map SVG via the Wizard Engine."""
import sqlite3, json, os, subprocess, math

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
ENGINE_BIN = "/Users/wws/Qdrant_mysql_mlx_vector_engine/svg_engine/c/wizard_engine"
SVG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "codegps_svg")

def main():
    os.makedirs(SVG_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("SELECT violation_type, severity, COUNT(*) FROM violations GROUP BY violation_type, severity ORDER BY COUNT(*) DESC")
    violations = cur.fetchall()

    cur.execute("SELECT violation_type, route_name, success_count, fail_count, confidence FROM repair_routes")
    routes = {r[0]: r for r in cur.fetchall()}
    conn.close()

    width, height = 1200, 900
    objects = []

    # Start node (glowing blue)
    objects.append({
        "id": "start",
        "type": "mcp_node",
        "position": [80, height // 2],
        "rotation": 0, "scale": 1.5, "opacity": 1.0,
        "color": "#58a6ff", "stroke_color": "#58a6ff", "stroke_width": 2,
        "node_label": "START", "node_status": 1, "text": "",
        "motion": {"type": "glow", "speed": 0.3, "amplitude": 0, "radius": 0, "phase": 0, "center": [80, height // 2], "seed": 42}
    })

    n = len(violations)
    spacing = min(90, (height - 120) // max(n, 1))
    cx = width // 2
    end_x = width - 120

    for i, (vtype, sev, cnt) in enumerate(violations):
        y = 90 + i * spacing

        if sev == "error":
            status = 3
            color = "#f85149"
        else:
            status = 2
            color = "#d29922"

        route = routes.get(vtype)
        if route:
            _, name, success, fail, conf = route
            if success > 0 and fail == 0:
                road_color = "#3fb950"
            elif fail > 0 and success == 0:
                road_color = "#f85149"
            else:
                road_color = "#d29922"
        else:
            road_color = "#484f58"

        # Road from start to destination
        dist_in = math.sqrt((cx - 80) ** 2 + (y - height // 2) ** 2)
        objects.append({
            "id": f"link_in_{i}",
            "type": "rect",
            "position": [(80 + cx) / 2, (height // 2 + y) / 2],
            "rotation": math.degrees(math.atan2(y - height // 2, cx - 80)),
            "scale": 1.0, "opacity": 0.3,
            "color": road_color, "stroke_color": road_color, "stroke_width": 0,
            "width": dist_in, "height": 1.5, "text": ""
        })

        # Destination node (pulsing)
        objects.append({
            "id": f"dest_{i}",
            "type": "mcp_node",
            "position": [cx, y],
            "rotation": 0, "scale": 0.8, "opacity": 1.0,
            "color": color, "stroke_color": color, "stroke_width": 2,
            "node_label": vtype[:18], "node_status": status, "text": "",
            "motion": {"type": "pulse", "speed": 0.5, "amplitude": 3.0, "radius": 0, "phase": i * 0.1, "center": [cx, y], "seed": 42}
        })

        # Result node
        if route:
            _, name, success, fail, conf = route
            if success > 0 and fail == 0:
                rs, rc, rl = 1, "#3fb950", "OK"
            elif fail > 0 and success == 0:
                rs, rc, rl = 3, "#f85149", "FAIL"
            else:
                rs, rc, rl = 2, "#d29922", "?"
        else:
            rs, rc, rl = 0, "#484f58", "—"

        # Road from destination to result
        objects.append({
            "id": f"link_out_{i}",
            "type": "rect",
            "position": [(cx + end_x) / 2, y],
            "rotation": 0, "scale": 1.0, "opacity": 0.3,
            "color": road_color, "stroke_color": road_color, "stroke_width": 0,
            "width": end_x - cx, "height": 1.5, "text": ""
        })

        objects.append({
            "id": f"result_{i}",
            "type": "mcp_node",
            "position": [end_x, y],
            "rotation": 0, "scale": 0.5, "opacity": 0.8,
            "color": rc, "stroke_color": rc, "stroke_width": 1,
            "node_label": rl, "node_status": rs, "text": "",
            "motion": {"type": "pulse", "speed": 0.3, "amplitude": 2.0, "radius": 0, "phase": i * 0.15, "center": [end_x, y], "seed": 42}
        })

    # Background particles (purple dust)
    objects.append({
        "id": "bg_particles",
        "type": "emitter",
        "position": [width / 2, height / 2],
        "rotation": 0, "scale": 1.0, "opacity": 1.0,
        "color": "#7b2ff7", "stroke_color": "#ffffff", "stroke_width": 1,
        "emitter": {
            "type": "dust", "rate": 8, "speed": 15, "speed_var": 10,
            "size": 1.5, "size_var": 0.5, "life": 4.0, "life_var": 1.0,
            "gravity": -5, "drag": 0.98, "area": [400, 300], "max": 80
        },
        "text": ""
    })

    scene = {
        "name": "CodeGPS Repair Map",
        "width": width,
        "height": height,
        "background": [0.02, 0.02, 0.06],
        "duration": 8.0,
        "fps": 60,
        "objects": objects,
    }

    scene_path = os.path.join(SVG_DIR, "repair_map.json")
    svg_path = os.path.join(SVG_DIR, "repair_map.svg")

    with open(scene_path, "w") as f:
        json.dump(scene, f, indent=2)

    result = subprocess.run([ENGINE_BIN, scene_path, svg_path], capture_output=True, text=True, timeout=30)
    if result.returncode == 0:
        abspath = os.path.abspath(svg_path)
        size = os.path.getsize(svg_path)
        sys.stdout.write(f"SVG generated: {abspath}\n")
        sys.stdout.write(f"File size: {size} bytes\n")
        sys.stdout.write(f"Objects: {len(objects)}\n")
        sys.stdout.write(f"Open in browser: file://{abspath}\n")
    else:
        sys.stdout.write(f"Error: {result.stderr}\n")


if __name__ == "__main__":
    import sys
    main()
