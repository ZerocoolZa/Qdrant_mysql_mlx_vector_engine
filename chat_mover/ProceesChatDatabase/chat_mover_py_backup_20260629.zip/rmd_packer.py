#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/rmd_packer.py"
# date="2026-06-28" author="Cascade" session_id="rmd-concept"
# context="RMD Packer: embeds compiled binary into markdown as base64 [@RUNNABLE] tag"}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="rmd_packer.py" domain="ChatMover" authority="RmdPacker"}
#[@SUMMARY]{summary="RMD Packer: takes a compiled binary + a pipeline .md doc, embeds the binary as base64 in a [@RUNNABLE] tag inside the markdown. AI reads the .md, extracts the binary, runs it. No build step needed."}
#[@CLASS]{class="RmdPacker" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="pack" type="command"}
#[@METHOD]{method="unpack" type="command"}
#[@METHOD]{method="embed_binary" type="command"}
#[@METHOD]{method="extract_binary" type="command"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import base64
import hashlib
import platform
import subprocess
import tempfile
import zlib

RMD_TAG_TEMPLATE = '''#[@RUNNABLE]{{
  format="{format_type}";
  compression="zlib";
  binary="{binary_name}";
  version="{version}";
  size={binary_size};
  compressed_size={compressed_size};
  md5="{binary_md5}";
  platform="{platform}";
  arch="{arch}";
  cmd="{run_cmd}";
  embedded_date="{date}";
  source="{source_path}";
}}
```{lang_tag}
{embedded_data}
```
#[@/RUNNABLE]
'''

UNPACK_SCRIPT = '''#!/usr/bin/env python3
"""RMD Unpacker: extracts [@RUNNABLE] binary from markdown and executes it."""
import re, base64, os, sys, tempfile, subprocess, hashlib

def find_runnable(md_path):
    with open(md_path, "r") as f:
        content = f.read()
    # Find [@RUNNABLE] tag
    tag_match = re.search(r'#\[@RUNNABLE\]\{(.*?)\}', content, re.DOTALL)  # noqa
    if not tag_match:
        return None, None
    tag_body = tag_match.group(1)
    # Extract fields
    fields = {}
    for m in re.finditer(r'(\w+)="([^"]*)"', tag_body):
        fields[m.group(1)] = m.group(2)
    for m in re.finditer(r'(\w+)=(\d+)', tag_body):
        fields[m.group(1)] = m.group(2)
    # Extract base64 block
    b64_match = re.search(r'```base64\n(.*?)\n```', content, re.DOTALL)
    if not b64_match:
        return fields, None
    return fields, b64_match.group(1).strip()

def unpack_and_run(md_path, args=None):
    args = args or []
    fields, b64_data = find_runnable(md_path)
    if not fields:
        print("ERROR: No [@RUNNABLE] tag found in", md_path)
        return 1
    if not b64_data:
        print("ERROR: No base64 binary found in", md_path)
        return 1
    binary_name = fields.get("binary", "rmd_binary")
    expected_md5 = fields.get("md5", "")
    run_cmd = fields.get("cmd", "./" + binary_name)
    # Decode
    binary_data = base64.b64decode(b64_data)
    # Verify MD5
    actual_md5 = hashlib.md5(binary_data).hexdigest()
    if expected_md5 and actual_md5 != expected_md5:
        print("WARNING: MD5 mismatch — expected %s, got %s" % (expected_md5, actual_md5))
    # Write to temp file
    tmpdir = tempfile.mkdtemp(prefix="rmd_")
    binary_path = os.path.join(tmpdir, binary_name)
    with open(binary_path, "wb") as f:
        f.write(binary_data)
    os.chmod(binary_path, 0o755)
    # Run
    cmd_parts = run_cmd.replace("./" + binary_name, binary_path).split()
    cmd_parts.extend(args)
    print("Running: %s" % " ".join(cmd_parts))
    result = subprocess.run(cmd_parts, capture_output=False)
    return result.returncode

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 rmd_unpack.py <pipeline.md> [args...]")
        sys.exit(1)
    md_path = sys.argv[1]
    args = sys.argv[2:]
    rc = unpack_and_run(md_path, args)
    sys.exit(rc)
'''


class RmdPacker:
    """Embeds compiled binaries into markdown as base64 [@RUNNABLE] tags."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "compress": True,
                "chunk_size": 76,
            },
            "md_path": None,
            "binary_path": None,
            "output_path": None,
            "binary_data": None,
            "binary_md5": None,
            "binary_size": 0,
            "base64_data": "",
            "output": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "pack":
            return self.Pack(params)
        elif command == "unpack":
            return self.Unpack(params)
        elif command == "embed_binary":
            return self.EmbedBinary(params)
        elif command == "extract_binary":
            return self.ExtractBinary(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Pack(self, params):
        md_path = self._p(params, "md_path")
        binary_path = self._p(params, "binary_path")
        output_path = self._p(params, "output_path")
        run_cmd = self._p(params, "run_cmd")
        version = self._p(params, "version", "1")
        if not md_path or not binary_path:
            return (0, None, ("MISSING_PARAM", "md_path and binary_path required", 0))

        is_python = binary_path.endswith(".py")
        rv = self.EmbedBinary({"binary_path": binary_path, "run_cmd": run_cmd, "is_python": is_python})
        if rv[0] != 1:
            return rv

        try:
            with open(md_path, "r", encoding="utf-8") as f:
                md_content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        format_type = "python" if is_python else "base64"
        lang_tag = "python" if is_python else "base64"
        embedded_data = self.state["base64_data"] if is_python else self.state["base64_data"]
        runnable_tag = RMD_TAG_TEMPLATE.format(
            format_type=format_type,
            binary_name=os.path.basename(binary_path),
            version=version,
            binary_size=self.state["binary_size"],
            binary_md5=self.state["binary_md5"],
            compressed_size=self.state.get("compressed_size", 0),
            platform=platform.system().lower(),
            arch=platform.machine(),
            run_cmd=run_cmd or ("./" + os.path.basename(binary_path)),
            date=__import__("datetime").datetime.now().strftime("%Y-%m-%d"),
            source_path=binary_path,
            lang_tag=lang_tag,
            embedded_data=embedded_data,
        )

        marker = "---\n## Executable Pipeline"
        if marker in md_content:
            parts = md_content.split(marker, 1)
            before = parts[0]
            after = parts[1].split("---", 1)[1] if "---" in parts[1] else ""
            output = before + runnable_tag + after
        else:
            output = md_content + "\n\n---\n## Embedded Runnable Binary\n\n" + runnable_tag

        if not output_path:
            base, ext = os.path.splitext(md_path)
            output_path = base + ".rmd" + ext

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(output)
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))

        self.state["output_path"] = output_path
        return (1, {
            "output_path": output_path,
            "binary_size": self.state["binary_size"],
            "base64_size": len(self.state["base64_data"]),
            "md5": self.state["binary_md5"],
        }, None)

    def Unpack(self, params):
        md_path = self._p(params, "md_path")
        run = self._p(params, "run", False)
        args = self._p(params, "args", [])
        if not md_path:
            return (0, None, ("MISSING_PARAM", "md_path required", 0))

        rv = self.ExtractBinary({"md_path": md_path})
        if rv[0] != 1:
            return rv

        data = rv[1]
        binary_path = data["binary_path"]

        if run:
            cmd_parts = data["run_cmd"].replace("./" + data["binary_name"], binary_path).split()
            cmd_parts.extend(args)
            try:
                result = subprocess.run(cmd_parts, capture_output=False)
                return (1, {"binary_path": binary_path, "returncode": result.returncode}, None)
            except Exception as exc:
                return (0, None, ("RUN_ERROR", str(exc), 0))

        return (1, {"binary_path": binary_path, "fields": data.get("fields", {})}, None)

    def EmbedBinary(self, params):
        binary_path = self._p(params, "binary_path")
        run_cmd = self._p(params, "run_cmd")
        is_python = self._p(params, "is_python", False)
        if not binary_path or not os.path.isfile(binary_path):
            return (0, None, ("FILE_NOT_FOUND", "Binary not found: " + str(binary_path), 0))

        if is_python:
            try:
                with open(binary_path, "r", encoding="utf-8") as f:
                    source_text = f.read()
            except Exception as exc:
                return (0, None, ("READ_ERROR", str(exc), 0))
            binary_data = source_text.encode("utf-8")
            self.state["binary_path"] = binary_path
            self.state["binary_data"] = binary_data
            self.state["binary_size"] = len(binary_data)
            self.state["binary_md5"] = hashlib.md5(binary_data).hexdigest()
            compressed = zlib.compress(binary_data, 9)
            encoded = base64.b64encode(compressed).decode("ascii")
            lines = [encoded[i:i+self.state["config"]["chunk_size"]] for i in range(0, len(encoded), self.state["config"]["chunk_size"])]
            self.state["base64_data"] = "\n".join(lines)
            self.state["compressed_size"] = len(compressed)
            return (1, {
                "binary_name": os.path.basename(binary_path),
                "size": self.state["binary_size"],
                "compressed_size": len(compressed),
                "md5": self.state["binary_md5"],
                "format": "python",
            }, None)

        try:
            with open(binary_path, "rb") as f:
                binary_data = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        self.state["binary_path"] = binary_path
        self.state["binary_data"] = binary_data
        self.state["binary_size"] = len(binary_data)
        self.state["binary_md5"] = hashlib.md5(binary_data).hexdigest()
        compressed = zlib.compress(binary_data, 9)
        encoded = base64.b64encode(compressed).decode("ascii")
        lines = [encoded[i:i+self.state["config"]["chunk_size"]] for i in range(0, len(encoded), self.state["config"]["chunk_size"])]
        self.state["base64_data"] = "\n".join(lines)
        self.state["compressed_size"] = len(compressed)
        return (1, {
            "binary_name": os.path.basename(binary_path),
            "size": self.state["binary_size"],
            "compressed_size": len(compressed),
            "md5": self.state["binary_md5"],
            "base64_lines": len(lines),
        }, None)

    def ExtractBinary(self, params):
        md_path = self._p(params, "md_path")
        if not md_path or not os.path.isfile(md_path):
            return (0, None, ("FILE_NOT_FOUND", "Markdown not found: " + str(md_path), 0))
        try:
            with open(md_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        import re
        tag_match = re.search(r'#\[@RUNNABLE\]\{(.*?)\}', content, re.DOTALL)  # noqa
        if not tag_match:
            return (0, None, ("NO_RUNNABLE", "No [@RUNNABLE] tag found in markdown", 0))
        tag_body = tag_match.group(1)
        fields = {}
        for m in re.finditer(r'(\w+)="([^"]*)"', tag_body):
            fields[m.group(1)] = m.group(2)
        for m in re.finditer(r'(\w+)=(\d+)', tag_body):
            fields[m.group(1)] = m.group(2)

        b64_match = re.search(r'```base64\n(.*?)\n```', content, re.DOTALL)
        if not b64_match:
            return (0, None, ("NO_BASE64", "No base64 block found in markdown", 0))

        binary_name = fields.get("binary", "rmd_binary")
        b64_data = b64_match.group(1).strip()
        raw_data = base64.b64decode(b64_data)

        compression = fields.get("compression", "")
        if compression == "zlib":
            binary_data = zlib.decompress(raw_data)
        else:
            binary_data = raw_data

        expected_md5 = fields.get("md5", "")
        actual_md5 = hashlib.md5(binary_data).hexdigest()
        if expected_md5 and actual_md5 != expected_md5:
            return (0, None, ("MD5_MISMATCH",
                "Expected %s, got %s" % (expected_md5, actual_md5), 0))

        tmpdir = tempfile.mkdtemp(prefix="rmd_")
        binary_path = os.path.join(tmpdir, binary_name)
        with open(binary_path, "wb") as f:
            f.write(binary_data)
        os.chmod(binary_path, 0o755)

        return (1, {
            "binary_path": binary_path,
            "binary_name": binary_name,
            "run_cmd": fields.get("cmd", "./" + binary_name),
            "fields": fields,
            "size": len(binary_data),
        }, None)


def main():
    import sys
    import argparse

    parser = argparse.ArgumentParser(description="RMD Packer — Runnable Markdown Document")
    sub = parser.add_subparsers(dest="command")

    pack_p = sub.add_parser("pack", help="Embed binary into markdown")
    pack_p.add_argument("--md", required=True, help="Pipeline markdown file")
    pack_p.add_argument("--binary", required=True, help="Compiled binary to embed")
    pack_p.add_argument("--output", help="Output .rmd.md file (default: <md>.rmd.md)")
    pack_p.add_argument("--cmd", help="Run command (default: ./<binary_name>)")
    pack_p.add_argument("--version", default="1", help="Version label (default: 1)")

    unpack_p = sub.add_parser("unpack", help="Extract binary from markdown")
    unpack_p.add_argument("--md", required=True, help="RMD markdown file")
    unpack_p.add_argument("--run", action="store_true", help="Run the binary after extraction")
    unpack_p.add_argument("args", nargs="*", help="Arguments to pass to binary")

    sub.add_parser("unpack-script", help="Print the standalone unpacker script")

    args = parser.parse_args()

    if args.command == "pack":
        packer = RmdPacker()
        rv = packer.Run("pack", {
            "md_path": args.md,
            "binary_path": args.binary,
            "output_path": args.output,
            "run_cmd": args.cmd,
            "version": args.version,
        })
        if rv[0] == 1:
            d = rv[1]
            print("Packed: %s" % d["output_path"], file=sys.stderr)
            print("  binary: %d bytes" % d["binary_size"], file=sys.stderr)
            print("  base64: %d bytes" % d["base64_size"], file=sys.stderr)
            print("  md5: %s" % d["md5"], file=sys.stderr)
        else:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)

    elif args.command == "unpack":
        packer = RmdPacker()
        rv = packer.Run("unpack", {
            "md_path": args.md,
            "run": args.run,
            "args": args.args,
        })
        if rv[0] == 1:
            d = rv[1]
            print("Extracted: %s" % d["binary_path"], file=sys.stderr)
            if "returncode" in d:
                print("Return code: %d" % d["returncode"], file=sys.stderr)
        else:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)

    elif args.command == "unpack-script":
        print(UNPACK_SCRIPT)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
