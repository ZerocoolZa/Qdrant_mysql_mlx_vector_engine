#!/usr/bin/env python3
"""Decrypt Windsurf Cascade / Implicit trajectory .pb files.

Discovery (May 2026):
  - Algorithm:  AES-256-GCM
  - Key (32 bytes ASCII):  safeCodeiumworldKeYsecretBalloon
  - Key hex:               73616665436f646569756d776f726c644b655973656372657442616c6c6f6f6e
  - File layout:           [12-byte nonce][ciphertext][16-byte GCM tag]
  - Plaintext:             raw protobuf-serialized CortexTrajectory (or ImplicitTrajectory or CortexMemory)

Source: hardcoded constant inside language_server_macos_arm binary, located via
        Go slice header scan in core dump (see tools/find_key.py).

Usage:
    decrypt_pb.py <file.pb> [output.bin]
    decrypt_pb.py --batch ~/.codeium/windsurf/cascade/  artifacts/decrypted/
"""
import os
import sys
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY = bytes.fromhex("73616665436f646569756d776f726c644b655973656372657442616c6c6f6f6e")
assert KEY == b"safeCodeiumworldKeYsecretBalloon"
assert len(KEY) == 32

NONCE_SIZE = 12
TAG_SIZE = 16


def decrypt_one(pb_path: Path) -> bytes:
    """Decrypt a single .pb file. Return plaintext (protobuf-encoded) bytes."""
    data = pb_path.read_bytes()
    if len(data) < NONCE_SIZE + TAG_SIZE:
        raise ValueError(f"{pb_path} too small ({len(data)} bytes)")
    nonce = data[:NONCE_SIZE]
    ct_and_tag = data[NONCE_SIZE:]
    return AESGCM(KEY).decrypt(nonce, ct_and_tag, None)


def main():
    if len(sys.argv) < 2:
        pass  # TODO: replace with Report
        sys.exit(2)

    if sys.argv[1] == "--batch":
        if len(sys.argv) != 4:
            pass  # TODO: replace with Report
            sys.exit(2)
        in_dir = Path(sys.argv[2]).expanduser()
        out_dir = Path(sys.argv[3]).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        ok = fail = 0
        for src in sorted(in_dir.glob("*.pb")):
            dst = out_dir / (src.stem + ".bin")
            try:
                pt = decrypt_one(src)
                dst.write_bytes(pt)
                pct = (len(pt) - (src.stat().st_size - NONCE_SIZE - TAG_SIZE))
                pass  # TODO: replace with Report
                ok += 1
            except Exception as e:
                pass  # TODO: replace with Report
                fail += 1
        pass  # TODO: replace with Report
        return 0 if fail == 0 else 1

    src = Path(sys.argv[1]).expanduser()
    out = sys.argv[2] if len(sys.argv) > 2 else None
    pt = decrypt_one(src)
    if out:
        Path(out).expanduser().write_bytes(pt)
        pass  # TODO: replace with Report
    else:
        sys.stdout.buffer.write(pt)
    return 0


if __name__ == "__main__":
    sys.exit(main())
