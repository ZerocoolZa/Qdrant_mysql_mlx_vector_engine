"""
#[@GHOST]{("file_path=/Users/wws/Downloads/chatgpt_mysql_ingest.py";"identity=Chatgpt Mysql Ingest";"purpose=Ingest ChatGPT conversations from local JSON files into MySQL database `chatgpt_chats`.";"date=2026-06-26";"version=1.0";"author=Cascade";"chat_link=mysql://devin/devin_sessions?id=mirror-theory")}
#[@VBSTYLE]{("auth=Cascade";"role=tool";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete")}
#[@FILEID]{("session_id=mirror-theory";"context=Windsurf Decryption + ChatGPT Export + Anti-Collapse System";"purpose=Ingest ChatGPT conversations from local JSON files into MySQL database `chatgpt_chats`.")}
#[@SUMMARY]{("Created during Windsurf Decryption + ChatGPT Export + Anti-Collapse System session on 2026-06-26")}
"""

"""
Ingest ChatGPT conversations from local JSON files into MySQL database `chatgpt_chats`.

Usage:
    python3 chatgpt_mysql_ingest.py [chats_dir]
    python3 chatgpt_mysql_ingest.py /Users/wws/Downloads/chatgpt_chats
"""

import os
import sys
import json
import re
import time
import argparse
import mysql.connector
from datetime import datetime, timezone


DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "chatgpt_chats",
    "charset": "utf8mb4",
}

DEFAULT_CHAT_DIR = os.path.expanduser("~/Downloads/chatgpt_chats")
ACCOUNT_EMAIL = "najmalodewyk@gmail.com"


def CountWords(text):
    """Count words in text."""
    if not text:
        return 0
    return len(text.split())


def EstimateTokens(text):
    """Rough token estimate (~4 chars per token)."""
    if not text:
        return 0
    return len(text) // 4


def ExtractMessages(conv_detail):
    """Extract messages from conversation mapping, sorted by time."""
    if not conv_detail or "mapping" not in conv_detail:
        return []

    mapping = conv_detail["mapping"]
    nodes = []
    for node_id, node in mapping.items():
        msg = node.get("message")
        if msg and msg.get("content") and msg["content"].get("parts"):
            nodes.append((node_id, msg))

    nodes.sort(key=lambda pair: pair[1].get("create_time") or 0)

    messages = []
    for node_id, msg in nodes:
        role = msg.get("author", {}).get("role", "unknown")
        parts = msg.get("content", {}).get("parts", [])
        text_parts = []
        for p in parts:
            if isinstance(p, str):
                text_parts.append(p)
            elif isinstance(p, dict):
                text_parts.append(json.dumps(p, indent=2))
        text = "\n".join(text_parts)
        if text.strip():
            content_type = msg.get("content", {}).get("content_type", "text")
            author = msg.get("author", {})
            messages.append({
                "node_id": node_id,
                "role": role,
                "content_type": content_type,
                "author_name": author.get("name", ""),
                "text": text,
                "word_count": CountWords(text),
                "token_count": EstimateTokens(text),
                "create_time": msg.get("create_time"),
                "model_slug": msg.get("metadata", {}).get("model_slug", ""),
            })

    return messages


def TimeToDate(t):
    """Convert Unix timestamp (float) to datetime, or None."""
    if t is None:
        return None
    try:
        return datetime.fromtimestamp(float(t), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError, OSError):
        return None


def IngestConversation(cursor, conv_data, account_email):
    """Insert/update a conversation and its messages. Returns (conv_id, msg_count)."""
    conv_id = conv_data.get("id") or conv_data.get("conversation_id") or ""
    if not conv_id:
        return None, 0

    title = conv_data.get("title", "Untitled")
    create_time = conv_data.get("create_time")
    update_time = conv_data.get("update_time")
    create_date = TimeToDate(create_time)
    update_date = TimeToDate(update_time)
    is_archived = 1 if conv_data.get("is_archived") else 0
    is_starred = 1 if conv_data.get("is_starred") else 0
    is_temporary = 1 if conv_data.get("is_temporary_chat") else 0

    # Extract messages
    messages = ExtractMessages(conv_data)
    msg_count = len(messages)
    total_words = sum(m["word_count"] for m in messages)
    total_tokens = sum(m["token_count"] for m in messages)

    # Get model slug from first assistant message
    model_slug = ""
    for m in messages:
        if m["role"] == "assistant" and m["model_slug"]:
            model_slug = m["model_slug"]
            break

    # Upsert conversation
    cursor.execute("""
        INSERT INTO conversations
            (id, title, create_time, create_date, update_time, update_date,
             model_slug, is_archived, is_starred, is_temporary,
             message_count, word_count, token_count, account_email, source)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'local')
        ON DUPLICATE KEY UPDATE
            title=VALUES(title), create_time=VALUES(create_time),
            create_date=VALUES(create_date), update_time=VALUES(update_time),
            update_date=VALUES(update_date), model_slug=VALUES(model_slug),
            is_archived=VALUES(is_archived), is_starred=VALUES(is_starred),
            is_temporary=VALUES(is_temporary),
            message_count=VALUES(message_count), word_count=VALUES(word_count),
            token_count=VALUES(token_count), account_email=VALUES(account_email)
    """, (conv_id, title, create_time, create_date, update_time, update_date,
          model_slug, is_archived, is_starred, is_temporary,
          msg_count, total_words, total_tokens, account_email))

    # Delete old messages for this conversation (in case of re-ingest)
    cursor.execute("DELETE FROM messages WHERE conversation_id=%s", (conv_id,))

    # Insert messages
    for m in messages:
        m_date = TimeToDate(m["create_time"])
        cursor.execute("""
            INSERT INTO messages
                (conversation_id, node_id, role, content_type, author_name,
                 text, word_count, token_count, create_time, create_date, model_slug)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (conv_id, m["node_id"], m["role"], m["content_type"],
              m["author_name"], m["text"], m["word_count"], m["token_count"],
              m["create_time"], m_date, m["model_slug"]))

    return conv_id, msg_count


def main():
    parser = argparse.ArgumentParser(description="Ingest ChatGPT chats into MySQL")
    parser.add_argument("chats_dir", nargs="?", default=DEFAULT_CHAT_DIR,
                        help="Directory with chat .json files")
    parser.add_argument("--account", default=ACCOUNT_EMAIL,
                        help="Account email to tag conversations with")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would be ingested without writing")
    args = parser.parse_args()

    chats_dir = args.chats_dir
    if not os.path.isdir(chats_dir):
        pass  # TODO: replace with Report
        sys.exit(1)

    json_files = sorted([f for f in os.listdir(chats_dir) if f.endswith(".json")])
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    print()

    if args.dry_run:
        pass  # TODO: replace with Report
        total_msgs = 0
        total_words = 0
        for fname in json_files:
            fpath = os.path.join(chats_dir, fname)
            with open(fpath) as f:
                data = json.load(f)
            messages = ExtractMessages(data)
            words = sum(CountWords(m["text"]) for m in messages)
            total_msgs += len(messages)
            total_words += words
            pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        return

    # Connect to MySQL
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(prepared=True)

    # Check what's already in the DB
    cursor.execute("SELECT COUNT(*) FROM conversations")
    existing_convs = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM messages")
    existing_msgs = cursor.fetchone()[0]
    pass  # TODO: replace with Report
    print()

    # Ingest each file
    ingested = 0
    failed = 0
    total_msgs = 0
    total_words = 0
    start_time = time.time()

    for i, fname in enumerate(json_files):
        fpath = os.path.join(chats_dir, fname)
        try:
            with open(fpath) as f:
                data = json.load(f)

            conv_id, msg_count = IngestConversation(cursor, data, args.account)
            if conv_id:
                words = sum(CountWords(m["text"]) for m in ExtractMessages(data))
                total_msgs += msg_count
                total_words += words
                ingested += 1
                title = data.get("title", "?")[:50]
                if (i + 1) % 10 == 0 or i == 0:
                    elapsed = time.time() - start_time
                    pass  # TODO: replace with Report
            else:
                failed += 1
                pass  # TODO: replace with Report
        except Exception as e:
            failed += 1
            pass  # TODO: replace with Report
        # Commit in batches
        if (i + 1) % 50 == 0:
            conn.commit()

    conn.commit()

    elapsed = time.time() - start_time
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    # Verify
    cursor.execute("SELECT COUNT(*) FROM conversations")
    final_convs = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM messages")
    final_msgs = cursor.fetchone()[0]
    cursor.execute("SELECT SUM(word_count) FROM messages")
    final_words = cursor.fetchone()[0] or 0
    pass  # TODO: replace with Report
    cursor.close()
    conn.close()


if __name__ == "__main__":
    main()
