#!/usr/bin/env python3

#[@GHOST]{[@file<Config_Config_chat_mover.py>][@domain<chat_mover>][@role<config>][@auth<cascade>][@date<2026-06-22>][@ver<1.0>]}
#[@VBSTYLE]{[@auth<cascade>][@role<config>][@return<dict>][@no<decorators|print|hardcoded_paths>]}

"""
Config for chat_mover domain.

Auto-generated file inventory, class/method index, and VBStyle compliance check.
DO NOT EDIT MANUALLY -- regenerate with _generate_configs.py.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# -- File Inventory --------------------------------------------
    # -- Config.py --
    # Purpose: N/A
    # Lines: 476 | Classes: 1 | Methods: 0
    #   Class: ChatMoverConfig -- methods: __init__, _load, _get, _get_int, _get_bool, _get_json, MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD
    #   VBStyle: NO_Run | init | NO_state | no_print | DECOR

    # -- chat_mover.py --
    # Purpose: Chat Mover — Chat-to-Database Pipeline
    # Lines: 1136 | Classes: 2 | Methods: 27
    #   Class: MySQLConn -- methods: __init__, connect, reconnect, cursor, commit, rollback, close, test
    #   Class: StepFilter -- methods: __init__, filter
    #   Functions: setup_logging, create_schema, classify_content, classify_md, classify_json, should_skip_filename, should_skip_path, read_mysql_sources, read_disk_sources, parse_md_chat
    #   VBStyle: NO_Run | init | NO_state | no_print | no_decorator

    # -- vscode.py --
    # Purpose: N/A
    # Lines: 302 | Classes: 5 | Methods: 0
    #   Class: EditorTabs -- methods: __init__
    #   Class: FileExplorer -- methods: __init__
    #   Class: AIPanel -- methods: __init__
    #   Class: Terminal -- methods: __init__
    #   Class: IDEWindow -- methods: __init__
    #   VBStyle: NO_Run | init | NO_state | no_print | no_decorator

# -- Files Dict ------------------------------------------------
FILES = {
    "Config.py": {
        "purpose": "",
        "lines": 476,
        "classes": ["ChatMoverConfig"],
        "methods": [],
    },
    "chat_mover.py": {
        "purpose": "Chat Mover — Chat-to-Database Pipeline",
        "lines": 1136,
        "classes": ["MySQLConn", "StepFilter"],
        "methods": ["setup_logging", "create_schema", "classify_content", "classify_md", "classify_json", "should_skip_filename", "should_skip_path", "read_mysql_sources", "read_disk_sources", "parse_md_chat", "parse_json_chat", "parse_chat", "extract_session_name", "extract_prompts", "compute_content_hash", "import_session", "qdrant_health_check", "ensure_qdrant_collection", "embed_messages", "embed_batch", "verify_import", "save_pipeline_state", "get_pipeline_state", "acquire_lock", "release_lock", "run_pipeline", "main"],
    },
    "vscode.py": {
        "purpose": "",
        "lines": 302,
        "classes": ["EditorTabs", "FileExplorer", "AIPanel", "Terminal", "IDEWindow"],
        "methods": [],
    },
}
# -- Classes Dict ----------------------------------------------
CLASSES = {
    "ChatMoverConfig": {
        "file": "Config.py",
        "methods": ["__init__", "_load", "_get", "_get_int", "_get_bool", "_get_json", "MYSQL_HOST", "MYSQL_PORT", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_CHARSET", "MYSQL_AUTOCOMMIT", "MYSQL_CONNECTION_TIMEOUT", "DESTINATION_DB", "SOURCE_TABLES", "QDRANT_HOST", "QDRANT_PORT", "QDRANT_COLLECTION", "EMBED_MODEL", "EMBED_DIMENSIONS", "EMBED_MAX_TOKENS", "BATCH_SIZE", "BATCH_SIZE_MIN", "MAX_ROWS_PER_TABLE", "LOG_FILE", "LOG_MAX_BYTES", "LOG_BACKUP_COUNT", "LOCK_FILE", "DISK_FOLDERS", "SKIP_FILENAMES", "SKIP_PATHS", "GetMysqlConfig", "GetQdrantUrl", "GetSchemaSql", "GetAbout", "GetHelp", "GetAllConfig", "GetFileIndex", "GetFileList"],
    },
    "MySQLConn": {
        "file": "chat_mover.py",
        "methods": ["__init__", "connect", "reconnect", "cursor", "commit", "rollback", "close", "test"],
    },
    "StepFilter": {
        "file": "chat_mover.py",
        "methods": ["__init__", "filter"],
    },
    "EditorTabs": {
        "file": "vscode.py",
        "methods": ["__init__"],
    },
    "FileExplorer": {
        "file": "vscode.py",
        "methods": ["__init__"],
    },
    "AIPanel": {
        "file": "vscode.py",
        "methods": ["__init__"],
    },
    "Terminal": {
        "file": "vscode.py",
        "methods": ["__init__"],
    },
    "IDEWindow": {
        "file": "vscode.py",
        "methods": ["__init__"],
    },
}
# -- VBStyle Compliance ----------------------------------------
VBSTYLE_COMPLIANCE = {
    "total_files": 3,
    "files_with_Run": 0,
    "files_with_state": 0,
    "files_with_print": 0,
    "files_with_decorator": 1,
    "pass_rate": 0.0,
}
# -- Domain Summary --------------------------------------------
DOMAIN = "chat_mover"
FILE_COUNT = 3
CLASS_COUNT = 8

# ═════════════════════════════════════════════════════════════
# BCL CHAT STORE — SQLite database for original chats + BCL output
# ═════════════════════════════════════════════════════════════

BCL_CHAT_DB_DIR = os.path.join(BASE_DIR, "ProceesChatDatabase")
BCL_CHAT_DB_PATH = os.path.join(BCL_CHAT_DB_DIR, "bcl_chat_store.db")

BCL_CHAT_STORE_CONFIG = {
    "db_path": BCL_CHAT_DB_PATH,
    "db_dir": BCL_CHAT_DB_DIR,
    "schema_tables": [
        "original_chats",
        "bcl_stage1",
        "bcl_stage2",
        "chat_items",
    ],
    "stage1_min_lines": 500,
    "stage1_extractors": [
        "errors", "files", "commands", "frustration",
        "dialogue", "questions", "code_blocks", "topic_boundaries",
    ],
    "stage2_extractors": [
        "problems", "unresolved", "decisions",
        "successes", "failed", "lessons",
    ],
    "chat_sources_dir": os.path.expanduser("~/Downloads"),
    "compression_module": "bcl_chat_compressor",
    "stage2_module": "bcl_chat_ai_prompt",
    "store_module": "bcl_chat_store",
}

MYSQL_CONFIG = {
    "user": "root",
    "host": "localhost",
    "port": 3306,
    "database": "vb_shared",
}

CHAT_PROCESSING_PIPELINE = [
    ("1_find", "Scan Downloads/ for .md chat exports"),
    ("2_store", "Store original chat in bcl_chat_store.db"),
    ("3_stage1", "Run BclChatCompressor.Run('compress') -> Stage 1 tokens"),
    ("4_store_stage1", "Store Stage 1 output in bcl_chat_store.db"),
    ("5_stage2", "AI semantic pass -> problems, unresolved, decisions, lessons"),
    ("6_store_stage2", "Store Stage 2 output + individual items in bcl_chat_store.db"),
    ("7_query", "Query unresolved items -> todo list for next session"),
]

# ═════════════════════════════════════════════════════════════
# BCL CHAT STORE — Full Schema SQL (from bcl_chat_store.py)
# ═════════════════════════════════════════════════════════════

BCL_CHAT_STORE_SCHEMA = """
CREATE TABLE IF NOT EXISTS original_chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_path TEXT NOT NULL,
    source_name TEXT NOT NULL,
    md5_hash TEXT NOT NULL,
    line_count INTEGER NOT NULL,
    file_size INTEGER NOT NULL,
    date_ingested TEXT NOT NULL,
    content TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bcl_stage1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    token_count INTEGER NOT NULL,
    compression_ratio REAL NOT NULL,
    output_lines INTEGER NOT NULL,
    output_text TEXT NOT NULL,
    stats_json TEXT,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id)
);

CREATE TABLE IF NOT EXISTS bcl_stage2 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    stage1_id INTEGER NOT NULL,
    problems_count INTEGER DEFAULT 0,
    unresolved_count INTEGER DEFAULT 0,
    decisions_count INTEGER DEFAULT 0,
    successes_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    lessons_count INTEGER DEFAULT 0,
    output_text TEXT NOT NULL,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id),
    FOREIGN KEY (stage1_id) REFERENCES bcl_stage1(id)
);

CREATE TABLE IF NOT EXISTS chat_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    stage2_id INTEGER NOT NULL,
    item_type TEXT NOT NULL,
    line_number INTEGER,
    content TEXT NOT NULL,
    status TEXT DEFAULT 'open',
    keyword TEXT,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id),
    FOREIGN KEY (stage2_id) REFERENCES bcl_stage2(id)
);

CREATE INDEX IF NOT EXISTS idx_original_chats_md5 ON original_chats(md5_hash);
CREATE INDEX IF NOT EXISTS idx_bcl_stage1_chat ON bcl_stage1(chat_id);
CREATE INDEX IF NOT EXISTS idx_bcl_stage2_chat ON bcl_stage2(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_items_type ON chat_items(item_type);
CREATE INDEX IF NOT EXISTS idx_chat_items_status ON chat_items(status);
"""
