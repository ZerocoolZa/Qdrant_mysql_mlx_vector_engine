# [@GHOST]{[@file<Config.py>][@domain<chat_mover>][@role<config>][@auth<cascade>][@date<2026-06-22>][@ver<1.0.0>]}
# [@VBSTYLE]{[@auth<system>][@role<chat_mover_config>][@return<none>][@orch<none>][@no<decorators|print|hardcoded_paths|abc|inheritance>]}

# AI GUIDE:
#   This is the ONE file for all pipeline settings.
#   All values live in SQLite config table — key/value/description.
#   App boots cold: creates config DB from CONFIG_SEED if missing.
#   Env vars override SQLite values at runtime.
#   Schema SQL embedded — app creates destination tables from it.
#   No JSON. No hardcoded paths. Everything configurable.

import os
import json
import sqlite3

# ─── BASE DIR ──────────────────────────────────────────────────────────────

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.expanduser("~/.config/chat_mover")
os.makedirs(CONFIG_DIR, exist_ok=True)
CONFIG_DB_PATH = os.path.join(CONFIG_DIR, "chat_mover_config.db")

# ─── VERSIONS ──────────────────────────────────────────────────────────────

PIPELINE_VERSION = "1.0.0"
CONFIG_VERSION = "1.0.0"

# ─── CONFIG SEED SQL (embedded — no external .sql file) ────────────────────
# Same pattern as Cascade_toolStack/config_seed.sql but embedded here.
# App boots cold: creates config table + seeds all values from this string.

CONFIG_SEED_SQL = """
-- [@GHOST]{[@file<Config.py>][@domain<chat_mover>][@role<config_seed>][@auth<cascade>][@date<2026-06-22>][@ver<1.0.0>]}

CREATE TABLE IF NOT EXISTS config (
    key         TEXT PRIMARY KEY,
    value       TEXT,
    description TEXT
);

INSERT OR IGNORE INTO config VALUES
('mysql_host',              'localhost',                          'MySQL server hostname'),
('mysql_port',              '3306',                               'MySQL port'),
('mysql_user',              'root',                               'MySQL username'),
('mysql_pass',              '',                                   'MySQL password (empty = no password)'),
('mysql_charset',           'utf8mb4',                            'MySQL charset'),
('mysql_autocommit',        '0',                                  'MySQL autocommit (0=False, 1=True)'),
('mysql_timeout',           '10',                                 'MySQL connection timeout seconds'),
('dest_db',                 'Chat_History',                       'Destination MySQL database name'),
('source_tables',           '[]',                                 'Source tables JSON array'),
('qdrant_host',             'localhost',                          'Qdrant server hostname'),
('qdrant_port',             '6333',                               'Qdrant server port'),
('qdrant_collection',       'chat_messages',                      'Qdrant collection name'),
('embed_model',             'all-MiniLM-L6-v2',                   'Sentence transformer model name'),
('embed_dimensions',        '384',                                'Embedding vector dimensions'),
('embed_max_tokens',        '256',                                'Max tokens per message for embedding'),
('batch_size',              '500',                                'Default batch size for imports'),
('batch_size_min',          '50',                                 'Minimum batch size after reduction'),
('max_rows_per_table',      '50000',                              'Max rows to read per source table'),
('log_file',                '',                                   'Log file path (empty = BASE_DIR/pipeline.log)'),
('log_max_bytes',           '10485760',                           'Max log file size in bytes'),
('log_backup_count',        '5',                                  'Number of rotated log backups'),
('lock_file',               '',                                   'Pipeline lock file path (empty = BASE_DIR/.pipeline.lock)'),
('disk_folders',            '[]',                                 'Disk folders to scan (JSON array)'),
('skip_filenames',          '[]',                                 'Filenames to skip (JSON array)'),
('skip_paths',              '[]',                                 'Path segments to skip (JSON array)'),
('sqlite_sources',          '[]',                                 'SQLite source DBs + table/column mapping (JSON array)'),
('bcl_compress_enabled',    '1',                                  'Enable BCL compression of chat history files (0=off, 1=on)'),
('bcl_compress_min_lines',  '500',                                'Minimum chat file lines to trigger BCL compression'),
('bcl_compress_output_dir', '',                                    'Output directory for BCL compressed files (empty = same dir as source)'),
('bcl_read_order',          'bottom_up',                          'How to read chat history files: bottom_up (latest first) or top_down'),
('bcl_extract_errors',      '1',                                  'Extract [@ERROR] tokens during BCL compression (0=off, 1=on)'),
('bcl_extract_decisions',   '1',                                  'Extract [@DECISION] tokens during BCL compression (0=off, 1=on)'),
('bcl_extract_user_prefs',  '1',                                  'Extract [@USER_PREF] tokens from user messages (0=off, 1=on)'),
('bcl_extract_success',     '1',                                  'Extract [@SUCCESS] tokens for approaches that worked (0=off, 1=on)'),
('bcl_extract_failed',      '1',                                  'Extract [@FAILED] tokens for approaches that did not work (0=off, 1=on)'),
('bcl_extract_problems',    '1',                                  'Extract [@PROBLEM] and [@SOLUTION] token pairs (0=off, 1=on)'),
('bcl_extract_root_cause',  '1',                                  'Extract [@ROOT_CAUSE] tokens for diagnosed root causes (0=off, 1=on)'),
('bcl_extract_qa',          '1',                                  'Extract [@QUESTION] and [@ANSWER] token pairs from user/assistant dialogue (0=off, 1=on)'),
('bcl_extract_lessons',     '1',                                  'Extract [@LESSON] tokens for cumulative lessons learned (0=off, 1=on)'),
('bcl_extract_dialogue',    '1',                                  'Extract [@USER_SAYS] and [@AI_SAYS] dialogue tokens (0=off, 1=on)'),
('bcl_chronological',       '1',                                  'Output BCL tokens in chronological order with inline lessons under problems (0=grouped, 1=chronological)'),
('bcl_inline_lessons',      '1',                                  'Place [@LESSON] directly below the [@PROBLEM] it relates to (0=separate section, 1=inline)'),
('bcl_cross_reference',     '1',                                  'Verify BCL claims against actual files with grep/run_command (0=off, 1=on)');
"""

# ─── ENV VAR OVERRIDE MAP ──────────────────────────────────────────────────
# Env var name → config key

ENV_OVERRIDES = {
    "CHAT_MOVER_MYSQL_HOST":    "mysql_host",
    "CHAT_MOVER_MYSQL_PORT":    "mysql_port",
    "CHAT_MOVER_MYSQL_USER":    "mysql_user",
    "MYSQL_PASSWORD":           "mysql_pass",
    "CHAT_MOVER_DEST_DB":       "dest_db",
    "CHAT_MOVER_QDRANT_HOST":   "qdrant_host",
    "CHAT_MOVER_QDRANT_PORT":   "qdrant_port",
    "BCL_COMPRESS_ENABLED":     "bcl_compress_enabled",
    "BCL_READ_ORDER":           "bcl_read_order",
    "BCL_COMPRESS_MIN_LINES":   "bcl_compress_min_lines",
    "BCL_COMPRESS_OUTPUT_DIR":  "bcl_compress_output_dir",
}

# ─── EMBEDDED SCHEMA SQL (MySQL destination) ───────────────────────────────

SCHEMA_SQL = """
CREATE DATABASE IF NOT EXISTS {db}
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE {db};

CREATE TABLE IF NOT EXISTS sessions (
  row_id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  session_name     VARCHAR(300) NOT NULL,
  source_db        VARCHAR(100),
  source_table     VARCHAR(100),
  source_format    VARCHAR(10),
  source_created_at TIMESTAMP NULL,
  source_modified_at TIMESTAMP NULL,
  message_count    INT DEFAULT 0,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status           VARCHAR(50) DEFAULT 'imported',
  content_hash     VARCHAR(64),
  metadata         JSON NULL,
  INDEX idx_session_name (session_name),
  INDEX idx_session_status (status),
  INDEX idx_session_dates (source_modified_at)
);

CREATE TABLE IF NOT EXISTS messages (
  row_id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  session_id       BIGINT NOT NULL,
  role             VARCHAR(20) NOT NULL,
  content          LONGTEXT,
  sequence         INT NOT NULL,
  source_row_id    INT,
  embedded         BOOLEAN DEFAULT FALSE,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES sessions(row_id) ON DELETE CASCADE,
  INDEX idx_message_session (session_id),
  INDEX idx_message_embedded (embedded),
  INDEX idx_message_seq (session_id, sequence)
);

CREATE TABLE IF NOT EXISTS prompts (
  row_id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  session_id       BIGINT NOT NULL,
  prompt_text      TEXT NOT NULL,
  prompt_type      VARCHAR(50),
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES sessions(row_id) ON DELETE CASCADE,
  INDEX idx_prompt_session (session_id)
);

CREATE TABLE IF NOT EXISTS pipeline_state (
  id               INT PRIMARY KEY DEFAULT 1,
  current_step     VARCHAR(20),
  last_processed_id INT DEFAULT 0,
  batch_number     INT DEFAULT 0,
  started_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  status           VARCHAR(50) DEFAULT 'running'
);

CREATE TABLE IF NOT EXISTS error_knowledge (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  step             VARCHAR(20),
  error_type       VARCHAR(100),
  error_message    TEXT,
  conditions       JSON,
  fix_attempted    JSON,
  successful_fix   VARCHAR(100),
  success_count    INT DEFAULT 0,
  failure_count    INT DEFAULT 0,
  confidence       FLOAT DEFAULT 0.5,
  occurrence_count INT DEFAULT 1,
  first_seen       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_seen        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  auto_resolved    BOOLEAN DEFAULT FALSE,
  prevention_added BOOLEAN DEFAULT FALSE
);
"""

# ─── ABOUT / HELP ──────────────────────────────────────────────────────────

ABOUT = """Chat Mover — Chat-to-Database Pipeline v{ver}

Moves chat conversations from MySQL, Disk, or SQLite sources into a
unified Chat_History MySQL database with optional Qdrant embeddings.

Pipeline: Source -> Classify -> Filter -> Parse -> Import -> Embed -> Verify
""".format(ver=PIPELINE_VERSION)

HELP = """Usage:
  python3 chat_mover.py --test              # 10 rows, no writes
  python3 chat_mover.py --dry-run           # Full read, no writes
  python3 chat_mover.py --source mysql      # Real import from MySQL
  python3 chat_mover.py --source disk --folder /path/to/chats
  python3 chat_mover.py --source mysql --embed   # Import + Qdrant embeddings
  python3 chat_mover.py --limit 100         # Cap rows per table

Config: SQLite DB at chat_mover_config.db
  All values stored as key/value/description triples.
  Edit with: sqlite3 chat_mover_config.db "UPDATE config SET value='...' WHERE key='...'"
  Env overrides: CHAT_MOVER_MYSQL_HOST, CHAT_MOVER_DEST_DB, MYSQL_PASSWORD, etc.
"""


# ─── FILE INDEX ────────────────────────────────────────────────────────────
# Full index of all files in this folder. MUST be updated when files change.
# No exceptions — every file in chat_mover/ must be listed here.

FILE_INDEX = [
    {
        "file": "Config.py",
        "purpose": "(no docstring)",
        "classes": ["ChatMoverConfig"],
        "methods": ["ChatMoverConfig.__init__", "ChatMoverConfig._load", "ChatMoverConfig._get", "ChatMoverConfig._get_int", "ChatMoverConfig._get_bool", "ChatMoverConfig._get_json", "ChatMoverConfig.MYSQL_HOST", "ChatMoverConfig.MYSQL_PORT", "ChatMoverConfig.MYSQL_USER", "ChatMoverConfig.MYSQL_PASSWORD", "ChatMoverConfig.MYSQL_CHARSET", "ChatMoverConfig.MYSQL_AUTOCOMMIT", "ChatMoverConfig.MYSQL_CONNECTION_TIMEOUT", "ChatMoverConfig.DESTINATION_DB", "ChatMoverConfig.SOURCE_TABLES", "ChatMoverConfig.QDRANT_HOST", "ChatMoverConfig.QDRANT_PORT", "ChatMoverConfig.QDRANT_COLLECTION", "ChatMoverConfig.EMBED_MODEL", "ChatMoverConfig.EMBED_DIMENSIONS", "ChatMoverConfig.EMBED_MAX_TOKENS", "ChatMoverConfig.BATCH_SIZE", "ChatMoverConfig.BATCH_SIZE_MIN", "ChatMoverConfig.MAX_ROWS_PER_TABLE", "ChatMoverConfig.LOG_FILE", "ChatMoverConfig.LOG_MAX_BYTES", "ChatMoverConfig.LOG_BACKUP_COUNT", "ChatMoverConfig.LOCK_FILE", "ChatMoverConfig.DISK_FOLDERS", "ChatMoverConfig.SKIP_FILENAMES", "ChatMoverConfig.SKIP_PATHS", "ChatMoverConfig.SQLITE_SOURCES", "ChatMoverConfig.GetMysqlConfig", "ChatMoverConfig.GetQdrantUrl", "ChatMoverConfig.GetSchemaSql", "ChatMoverConfig.GetAbout", "ChatMoverConfig.GetHelp", "ChatMoverConfig.GetAllConfig", "ChatMoverConfig.GetFileIndex", "ChatMoverConfig.GetFileList"],
        "functions": ["MYSQL_HOST", "MYSQL_PORT", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_CHARSET", "MYSQL_AUTOCOMMIT", "MYSQL_CONNECTION_TIMEOUT", "DESTINATION_DB", "SOURCE_TABLES", "QDRANT_HOST", "QDRANT_PORT", "QDRANT_COLLECTION", "EMBED_MODEL", "EMBED_DIMENSIONS", "EMBED_MAX_TOKENS", "BATCH_SIZE", "BATCH_SIZE_MIN", "MAX_ROWS_PER_TABLE", "LOG_FILE", "LOG_MAX_BYTES", "LOG_BACKUP_COUNT", "LOCK_FILE", "DISK_FOLDERS", "SKIP_FILENAMES", "SKIP_PATHS", "SQLITE_SOURCES", "GetMysqlConfig", "GetQdrantUrl", "GetSchemaSql", "GetAbout", "GetHelp", "GetAllConfig", "GetFileIndex", "GetFileList"],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 2,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["ghost_header", "vbstyle_header", "tuple3_return", "state_dict", "run_dispatch", "no_decorators", "no_self_underscore"],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T21:51:14.760533",
        "modified": "2026-06-22T21:51:14.760533",
        "size": 19686,
        "lines": 483,
    },
    {
        "file": "Config_chat_mover.py",
        "purpose": "Config for chat_mover domain.",
        "classes": [],
        "methods": [],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 6,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": True,
        "bcl_headers_found": ["GHOST", "VBSTYLE"],
        "created": "2026-06-22T20:45:48.868030",
        "modified": "2026-06-22T20:45:48.868030",
        "size": 4727,
        "lines": 110,
    },
    {
        "file": "chat_mover.py",
        "purpose": "Chat Mover \u2014 Chat-to-Database Pipeline",
        "classes": ["MySQLConn", "StepFilter"],
        "methods": ["MySQLConn.__init__", "MySQLConn.connect", "MySQLConn.reconnect", "MySQLConn.cursor", "MySQLConn.commit", "MySQLConn.rollback", "MySQLConn.close", "MySQLConn.test", "StepFilter.__init__", "StepFilter.filter"],
        "functions": ["setup_logging", "create_schema", "classify_content", "classify_md", "classify_json", "should_skip_filename", "should_skip_path", "read_mysql_sources", "read_disk_sources", "read_sqlite_sources", "parse_md_chat", "parse_json_chat", "parse_chat", "extract_session_name", "extract_prompts", "compute_content_hash", "validate_session", "import_session", "qdrant_health_check", "ensure_qdrant_collection", "embed_messages", "embed_batch", "verify_import", "save_pipeline_state", "get_pipeline_state", "acquire_lock", "release_lock", "generate_validation_report", "run_pipeline", "main", "connect", "reconnect", "cursor", "commit", "rollback", "close", "test", "filter"],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 4,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["ghost_header", "vbstyle_header", "tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T21:49:54.012146",
        "modified": "2026-06-22T21:49:54.012146",
        "size": 67807,
        "lines": 1778,
    },
    {
        "file": "import_devin_transcripts.py",
        "purpose": "Import Devin CLI raw transcripts into Chat_History MySQL.",
        "classes": [],
        "methods": [],
        "functions": ["parse_transcript", "import_session", "main"],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 3,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["ghost_header", "vbstyle_header", "tuple3_return", "state_dict", "run_dispatch", "no_print"],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T22:04:48.170654",
        "modified": "2026-06-22T22:04:48.170654",
        "size": 11182,
        "lines": 339,
    },
    {
        "file": "vscode.py",
        "purpose": "(no docstring)",
        "classes": ["EditorTabs", "FileExplorer", "AIPanel", "Terminal", "IDEWindow"],
        "methods": ["EditorTabs.__init__", "FileExplorer.__init__", "AIPanel.__init__", "Terminal.__init__", "IDEWindow.__init__"],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 4,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["ghost_header", "vbstyle_header", "tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T16:39:12.664433",
        "modified": "2026-06-22T16:39:12.664433",
        "size": 9592,
        "lines": 302,
    },
    {
        "file": "README.md",
        "purpose": "Chat Mover \u2014 Chat-to-Database Pipeline",
        "classes": [],
        "methods": [],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 0,
        "vbstyle_rules_total": 0,
        "vbstyle_failed": [],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T16:20:57.975067",
        "modified": "2026-06-22T16:20:57.975067",
        "size": 2337,
        "lines": 70,
    },
    {
        "file": "Unifying Graph Codebases.md",
        "purpose": "Cascade Chat Conversation",
        "classes": [],
        "methods": [],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 0,
        "vbstyle_rules_total": 0,
        "vbstyle_failed": [],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-23T15:00:25.323261",
        "modified": "2026-06-23T15:00:12.079025",
        "size": 300165,
        "lines": 6613,
    },
    {
        "file": "pipeline.log",
        "purpose": "[2026-06-22 16:32:36] [INFO] [init] Chat Mover v1.0.0 starting",
        "classes": [],
        "methods": [],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 0,
        "vbstyle_rules_total": 0,
        "vbstyle_failed": [],
        "has_bcl": False,
        "bcl_headers_found": [],
        "created": "2026-06-22T21:51:19.224531",
        "modified": "2026-06-22T21:51:19.224531",
        "size": 31120,
        "lines": 414,
    },
    {
        "file": "Config_devin_sync.py",
        "purpose": "Configuration constants for Devin session SQLite-to-MySQL sync",
        "classes": ["DevinSyncConfig"],
        "methods": ["DevinSyncConfig.__init__", "DevinSyncConfig.Run", "DevinSyncConfig.read_state", "DevinSyncConfig.set_config", "DevinSyncConfig._p", "DevinSyncConfig.GetDevinPaths", "DevinSyncConfig.GetMysqlConfig"],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 6,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": True,
        "bcl_headers_found": ["GHOST", "VBSTYLE", "CLASSES", "METHODS", "DOMAIN"],
        "created": "2026-06-29T00:00:00",
        "modified": "2026-06-29T00:00:00",
        "size": 0,
        "lines": 123,
    },
    {
        "file": "DevinProcessManager.py",
        "purpose": "Manage Devin CLI process lifecycle so sessions.db can be read without lock",
        "classes": ["DevinProcessManager"],
        "methods": ["DevinProcessManager.__init__", "DevinProcessManager.Run", "DevinProcessManager.Find", "DevinProcessManager.Close", "DevinProcessManager.read_state", "DevinProcessManager.set_config", "DevinProcessManager._p", "DevinProcessManager._MatchDevinProcess"],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 6,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": True,
        "bcl_headers_found": ["GHOST", "VBSTYLE", "CLASSES", "METHODS", "DOMAIN"],
        "created": "2026-06-29T00:00:00",
        "modified": "2026-06-29T00:00:00",
        "size": 0,
        "lines": 181,
    },
    {
        "file": "DevinSessionSync.py",
        "purpose": "Sync Devin CLI sessions.db + summaries + transcripts into MySQL devin database",
        "classes": ["DevinSessionSync"],
        "methods": ["DevinSessionSync.__init__", "DevinSessionSync.Run", "DevinSessionSync.Sync", "DevinSessionSync.Status", "DevinSessionSync._ConnectMysql", "DevinSessionSync._ConnectSqlite", "DevinSessionSync._Close", "DevinSessionSync._TsToDt", "DevinSessionSync._ParseChatMessage", "DevinSessionSync._SyncSessions", "DevinSessionSync._SyncMessages", "DevinSessionSync._SyncToolCalls", "DevinSessionSync._SyncRenderedCommits", "DevinSessionSync._SyncTranscripts", "DevinSessionSync._SyncSummaries", "DevinSessionSync._SyncChatTurns", "DevinSessionSync._UpsertTurn", "DevinSessionSync._ExtractFilesFromToolCalls", "DevinSessionSync._ExtractFilePathsFromToolMsg", "DevinSessionSync._LogImport", "DevinSessionSync.read_state", "DevinSessionSync.set_config", "DevinSessionSync._p"],
        "functions": [],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 6,
        "vbstyle_rules_total": 9,
        "vbstyle_failed": ["tuple3_return", "state_dict", "run_dispatch"],
        "has_bcl": True,
        "bcl_headers_found": ["GHOST", "VBSTYLE", "CLASSES", "METHODS", "DOMAIN"],
        "created": "2026-06-29T00:00:00",
        "modified": "2026-06-29T00:00:00",
        "size": 0,
        "lines": 694,
    },
    {
        "file": "main_devin_sync.py",
        "purpose": "CLI entry point for Devin session sync lifecycle",
        "classes": [],
        "methods": [],
        "functions": ["main"],
        "vbstyle_compliant": False,
        "vbstyle_rules_passed": 0,
        "vbstyle_rules_total": 0,
        "vbstyle_failed": [],
        "has_bcl": True,
        "bcl_headers_found": ["GHOST", "VBSTYLE", "CLASSES", "METHODS", "DOMAIN"],
        "created": "2026-06-29T00:00:00",
        "modified": "2026-06-29T00:00:00",
        "size": 0,
        "lines": 85,
    },
]


# ─── CONFIG CLASS ──────────────────────────────────────────────────────────

class ChatMoverConfig:
    """Single source of truth for Chat Mover pipeline configuration.

    Loads all values from SQLite config table on init.
    Env vars override SQLite values.
    Schema SQL embedded — app boots cold.
    """

    PIPELINE_VERSION = PIPELINE_VERSION
    SCHEMA_SQL = SCHEMA_SQL
    ABOUT = ABOUT
    HELP = HELP
    FILE_INDEX = FILE_INDEX

    def __init__(self):
        self._db_path = CONFIG_DB_PATH
        self._values = {}
        self._load()

    def _load(self):
        """Load config from SQLite, apply env overrides."""
        conn = sqlite3.connect(self._db_path)
        cur = conn.cursor()

        cur.executescript(CONFIG_SEED_SQL)
        conn.commit()

        cur.execute("SELECT key, value FROM config")
        for key, value in cur.fetchall():
            self._values[key] = value

        cur.close()
        conn.close()

        for env_name, config_key in ENV_OVERRIDES.items():
            env_val = os.environ.get(env_name)
            if env_val is not None:
                self._values[config_key] = env_val

    def _get(self, key, default=None):
        return self._values.get(key, default)

    def _get_int(self, key, default=0):
        val = self._get(key)
        try:
            return int(val) if val is not None else default
        except (ValueError, TypeError):
            return default

    def _get_bool(self, key, default=False):
        val = self._get(key)
        if val is None:
            return default
        return val in ("1", "true", "True", "yes", "Yes")

    def _get_json(self, key, default=None):
        val = self._get(key)
        if val is None:
            return default if default is not None else []
        try:
            return json.loads(val)
        except (json.JSONDecodeError, TypeError):
            return default if default is not None else []

    # ─── Properties (API surface) ───────────────────────────────────────────
    def MYSQL_HOST(self):
        return self._get("mysql_host", "localhost")
    def MYSQL_PORT(self):
        return self._get_int("mysql_port", 3306)
    def MYSQL_USER(self):
        return self._get("mysql_user", "root")
    def MYSQL_PASSWORD(self):
        return self._get("mysql_pass", "")
    def MYSQL_CHARSET(self):
        return self._get("mysql_charset", "utf8mb4")
    def MYSQL_AUTOCOMMIT(self):
        return self._get_bool("mysql_autocommit", False)
    def MYSQL_CONNECTION_TIMEOUT(self):
        return self._get_int("mysql_timeout", 10)
    def DESTINATION_DB(self):
        return self._get("dest_db", "Chat_History")
    def SOURCE_TABLES(self):
        return self._get_json("source_tables", [])
    def QDRANT_HOST(self):
        return self._get("qdrant_host", "localhost")
    def QDRANT_PORT(self):
        return self._get_int("qdrant_port", 6333)
    def QDRANT_COLLECTION(self):
        return self._get("qdrant_collection", "chat_messages")
    def EMBED_MODEL(self):
        return self._get("embed_model", "all-MiniLM-L6-v2")
    def EMBED_DIMENSIONS(self):
        return self._get_int("embed_dimensions", 384)
    def EMBED_MAX_TOKENS(self):
        return self._get_int("embed_max_tokens", 256)
    def BATCH_SIZE(self):
        return self._get_int("batch_size", 500)
    def BATCH_SIZE_MIN(self):
        return self._get_int("batch_size_min", 50)
    def MAX_ROWS_PER_TABLE(self):
        return self._get_int("max_rows_per_table", 50000)
    def LOG_FILE(self):
        val = self._get("log_file", "")
        return val if val else os.path.join(BASE_DIR, "pipeline.log")
    def LOG_MAX_BYTES(self):
        return self._get_int("log_max_bytes", 10 * 1024 * 1024)
    def LOG_BACKUP_COUNT(self):
        return self._get_int("log_backup_count", 5)
    def LOCK_FILE(self):
        val = self._get("lock_file", "")
        return val if val else os.path.join(BASE_DIR, ".pipeline.lock")
    def DISK_FOLDERS(self):
        return self._get_json("disk_folders", [])
    def SKIP_FILENAMES(self):
        return set(self._get_json("skip_filenames", []))
    def SKIP_PATHS(self):
        return set(self._get_json("skip_paths", []))
    def SQLITE_SOURCES(self):
        return self._get_json("sqlite_sources", [])

    # ─── BCL Compression Settings ──────────────────────────────────────────
    def BCL_COMPRESS_ENABLED(self):
        return self._get_bool("bcl_compress_enabled", True)
    def BCL_COMPRESS_MIN_LINES(self):
        return self._get_int("bcl_compress_min_lines", 500)
    def BCL_COMPRESS_OUTPUT_DIR(self):
        val = self._get("bcl_compress_output_dir", "")
        return val if val else ""
    def BCL_READ_ORDER(self):
        return self._get("bcl_read_order", "bottom_up")
    def BCL_EXTRACT_ERRORS(self):
        return self._get_bool("bcl_extract_errors", True)
    def BCL_EXTRACT_DECISIONS(self):
        return self._get_bool("bcl_extract_decisions", True)
    def BCL_EXTRACT_USER_PREFS(self):
        return self._get_bool("bcl_extract_user_prefs", True)
    def BCL_EXTRACT_SUCCESS(self):
        return self._get_bool("bcl_extract_success", True)
    def BCL_EXTRACT_FAILED(self):
        return self._get_bool("bcl_extract_failed", True)
    def BCL_EXTRACT_PROBLEMS(self):
        return self._get_bool("bcl_extract_problems", True)
    def BCL_EXTRACT_ROOT_CAUSE(self):
        return self._get_bool("bcl_extract_root_cause", True)
    def BCL_EXTRACT_QA(self):
        return self._get_bool("bcl_extract_qa", True)
    def BCL_EXTRACT_LESSONS(self):
        return self._get_bool("bcl_extract_lessons", True)
    def BCL_EXTRACT_DIALOGUE(self):
        return self._get_bool("bcl_extract_dialogue", True)
    def BCL_CHRONOLOGICAL(self):
        return self._get_bool("bcl_chronological", True)
    def BCL_INLINE_LESSONS(self):
        return self._get_bool("bcl_inline_lessons", True)
    def BCL_CROSS_REFERENCE(self):
        return self._get_bool("bcl_cross_reference", True)

    # ─── Getter Methods ─────────────────────────────────────────────────────

    def GetMysqlConfig(self):
        return {
            "host": self.MYSQL_HOST(),
            "port": self.MYSQL_PORT(),
            "user": self.MYSQL_USER(),
            "password": self.MYSQL_PASSWORD(),
            "charset": self.MYSQL_CHARSET(),
            "autocommit": self.MYSQL_AUTOCOMMIT(),
            "connection_timeout": self.MYSQL_CONNECTION_TIMEOUT(),
        }

    def GetQdrantUrl(self):
        return f"http://{self.QDRANT_HOST}:{self.QDRANT_PORT}"

    def GetSchemaSql(self):
        return self.SCHEMA_SQL.format(db=self.DESTINATION_DB)

    def GetAbout(self):
        return self.ABOUT

    def GetHelp(self):
        return self.HELP

    def GetAllConfig(self):
        """Return all config key/value/description triples for inspection."""
        conn = sqlite3.connect(self._db_path)
        cur = conn.cursor()
        cur.execute("SELECT key, value, description FROM config ORDER BY key")
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return rows

    def GetFileIndex(self):
        """Return full file index for this folder — all files, classes, methods, dates."""
        return self.FILE_INDEX

    def GetFileList(self):
        """Return just the list of filenames in this folder."""
        return [entry["file"] for entry in self.FILE_INDEX]


# ─── UI THEME CLASSES (clipboard v3/v4 pattern) ────────────────────────────
# Color/Font/Style classes for CodeGPS Garmin GUI — live-switchable themes.

class Color:
    BG          = "#0d1117"
    BG_ALT      = "#161b22"
    BG_DARK     = "#010409"
    BORDER      = "#30363d"
    BORDER_DIM  = "#21262d"
    TEXT        = "#e6edf3"
    TEXT_MUTED  = "#8b949e"
    TEXT_DIM    = "#484f58"
    ACCENT      = "#58a6ff"
    ACCENT_2    = "#e94560"
    GREEN       = "#3fb950"
    RED         = "#f85149"
    YELLOW      = "#d29922"
    BLUE        = "#58a6ff"
    GRAY        = "#6e7681"
    NODE_BG     = "#161b22"
    GRID        = "#161b22"
    WATER       = "#0C2340"
    PARK        = "#0D2818"
    ROAD        = "#3B4D63"
    ROAD_CASING = "#0D1117"
    ROBOT       = "#38BDF8"
    ROBOT_CRASH = "#f85149"
    ROBOT_OK    = "#3fb950"


class Font:
    SYSTEM = "font-family: Menlo, SF Mono, Courier New, monospace;"


class Style:
    TOP_BAR    = f"background: {Color.BG_ALT}; border-bottom: 0.5px solid {Color.BORDER};"
    SEL_BAR    = f"background: {Color.BG_DARK}; border-bottom: 0.5px solid {Color.BORDER_DIM};"
    BTN        = (f"QPushButton {{ background: {Color.BORDER_DIM}; color: {Color.TEXT_MUTED};"
                  f" border: 0.5px solid {Color.BORDER}; border-radius: 6px;"
                  f" padding: 4px 12px; font-size: 10px; {Font.SYSTEM} }}"
                  f" QPushButton:hover {{ background: {Color.BORDER}; color: {Color.ACCENT}; }}")
    BTN_ACCENT = (f"QPushButton {{ background: {Color.BORDER_DIM}; color: {Color.ACCENT};"
                  f" border: 0.5px solid {Color.ACCENT}; border-radius: 6px;"
                  f" padding: 3px 10px; font-size: 9px; font-weight: bold; {Font.SYSTEM} }}"
                  f" QPushButton:hover {{ background: {Color.ACCENT}; color: {Color.BG_DARK}; }}")
    BTN_DANGER = (f"QPushButton {{ background: {Color.BORDER_DIM}; color: {Color.RED};"
                  f" border: 0.5px solid {Color.RED}; border-radius: 6px;"
                  f" padding: 4px 12px; font-size: 10px; {Font.SYSTEM} }}"
                  f" QPushButton:hover {{ background: {Color.RED}; color: #fff; }}")
    TEXT_EDIT  = (f"QTextEdit {{ border: 0.5px solid {Color.BORDER}; background: {Color.BG};"
                  f" color: {Color.TEXT}; {Font.SYSTEM} font-size: 10px; }}"
                  f" QScrollBar:vertical {{ background: {Color.BG}; width: 6px; border-radius: 3px; }}"
                  f" QScrollBar::handle:vertical {{ background: {Color.BORDER}; border-radius: 3px; min-height: 20px; }}")
    TABS       = (f"QTabWidget::pane {{ border: 0.5px solid {Color.BORDER}; background: {Color.BG}; }}"
                  f" QTabBar::tab {{ background: {Color.BG_ALT}; color: {Color.TEXT_MUTED};"
                  f" padding: 6px 16px; border: none; font-size: 10px; font-weight: bold; {Font.SYSTEM} }}"
                  f" QTabBar::tab:selected {{ background: {Color.BORDER_DIM}; color: {Color.ACCENT}; }}")
    STATUS     = f"font-size: 10px; color: {Color.TEXT_DIM}; {Font.SYSTEM}"
    TELEMETRY  = (f"background: transparent; color: {Color.ACCENT};"
                  f" font-size: 9px; font-weight: bold; {Font.SYSTEM} padding: 0px 4px;")
    COMBO      = (f"QComboBox {{ background: {Color.BORDER_DIM}; color: {Color.TEXT_MUTED};"
                  f" border: 0.5px solid {Color.BORDER}; border-radius: 4px;"
                  f" padding: 3px 8px; font-size: 10px; {Font.SYSTEM} }}")


class Theme:
    """Live-switchable theme palettes — call apply() to switch without restart."""

    THEMES = {
        "midnight": {
            "bg": "#0d1117", "bg_alt": "#161b22", "border": "#30363d",
            "text": "#e6edf3", "muted": "#8b949e", "accent": "#58a6ff",
        },
        "forest": {
            "bg": "#0D1117", "bg_alt": "#0D2818", "border": "#1a3a2a",
            "text": "#e6edf3", "muted": "#8b949e", "accent": "#3fb950",
        },
        "sunset": {
            "bg": "#1a0a0a", "bg_alt": "#2a1010", "border": "#3a2020",
            "text": "#f0e0e0", "muted": "#a08080", "accent": "#e94560",
        },
        "ocean": {
            "bg": "#0a0a14", "bg_alt": "#0D1B2A", "border": "#1a2a3a",
            "text": "#e0e0f0", "muted": "#8090a0", "accent": "#38BDF8",
        },
    }

    @classmethod
    def get(cls, name):
        return cls.THEMES.get(name, cls.THEMES["midnight"])

    @classmethod
    def names(cls):
        return list(cls.THEMES.keys())

    @classmethod
    def apply(cls, widget, name):
        t = cls.get(name)
        widget.setStyleSheet(f"""
            QMainWindow {{ background-color: {t['bg']}; }}
            QLabel {{ color: {t['text']}; font-size: 12px; }}
            QTabWidget::pane {{ border: 0.5px solid {t['border']}; background: {t['bg']}; }}
            QTabBar::tab {{ background: {t['bg_alt']}; color: {t['muted']};
                padding: 6px 16px; border: none; font-family: Menlo; font-size: 10px; font-weight: bold; }}
            QTabBar::tab:selected {{ background: {t['bg_alt']}; color: {t['accent']}; }}
            QTextEdit {{ background: {t['bg']}; color: {t['text']};
                border: 0.5px solid {t['border']}; font-family: Menlo; font-size: 10px; }}
            QPushButton {{ background: {t['bg_alt']}; color: {t['muted']};
                border: 0.5px solid {t['border']}; padding: 5px 14px; border-radius: 6px;
                font-family: Menlo; font-size: 10px; }}
            QPushButton:hover {{ background: {t['border']}; color: {t['accent']}; }}
            QTableWidget {{ background: {t['bg']}; color: {t['text']};
                border: 0.5px solid {t['border']}; font-family: Menlo; font-size: 10px;
                gridline-color: {t['bg_alt']}; }}
            QHeaderView::section {{ background: {t['bg_alt']}; color: {t['muted']};
                border: none; padding: 3px; font-family: Menlo; font-weight: bold; }}
            QStatusBar {{ background: {t['bg']}; color: {t['muted']};
                font-family: Menlo; font-size: 10px; }}
            QComboBox {{ background: {t['bg_alt']}; color: {t['muted']};
                border: 0.5px solid {t['border']}; padding: 3px 8px;
                font-family: Menlo; font-size: 10px; border-radius: 4px; }}
            QCheckBox {{ color: {t['muted']}; font-family: Menlo; font-size: 10px; }}
            QMenuBar {{ background: {t['bg']}; color: {t['muted']}; }}
            QMenuBar::item:selected {{ background: {t['bg_alt']}; color: {t['accent']}; }}
            QMenu {{ background: {t['bg_alt']}; color: {t['text']};
                border: 0.5px solid {t['border']}; }}
            QMenu::item:selected {{ background: {t['border']}; color: {t['accent']}; }}
        """)


# ─── SINGLETON ─────────────────────────────────────────────────────────────

cfg = ChatMoverConfig()
