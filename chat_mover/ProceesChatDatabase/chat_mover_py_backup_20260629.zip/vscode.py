import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QDockWidget, QListWidget, QTextEdit,
    QTabWidget, QVBoxLayout, QToolBar,
    QStatusBar, QLabel, QMenuBar, QMenu,
    QPushButton, QHBoxLayout, QToolButton
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtWidgets import QStyle


# -------------------------
# Central Editor (Tabs)
# -------------------------
class EditorTabs(QTabWidget):
    def __init__(self):
        super().__init__()

        self.setTabsClosable(True)
        self.setMovable(True)

        for i in range(3):
            editor = QTextEdit()
            editor.setPlaceholderText(f"File_{i}.py ... AI editable buffer")
            self.addTab(editor, f"file_{i}.py")


# -------------------------
# File Explorer
# -------------------------
class FileExplorer(QListWidget):
    def __init__(self):
        super().__init__()
        self.addItems([
            "main.py",
            "engine.py",
            "ui.py",
            "memory.db",
            "config.json",
            "ai_core.py"
        ])


# -------------------------
# AI Panel (Right Dock)
# -------------------------
class AIPanel(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        self.chat = QTextEdit()
        self.chat.setPlaceholderText("AI reasoning / chat output...")

        self.input = QTextEdit()
        self.input.setFixedHeight(80)
        self.input.setPlaceholderText("Ask AI...")

        self.send = QPushButton("Send AI")

        layout.addWidget(QLabel("AI Panel"))
        layout.addWidget(self.chat)
        layout.addWidget(self.input)
        layout.addWidget(self.send)

        self.setLayout(layout)


# -------------------------
# Terminal Panel (Bottom)
# -------------------------
class Terminal(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        self.output = QTextEdit()
        self.output.setPlaceholderText("Terminal output / logs / runtime...")

        layout.addWidget(QLabel("Terminal"))
        layout.addWidget(self.output)

        self.setLayout(layout)


# -------------------------
# Main Window (IDE Shell)
# -------------------------
class IDEWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("AI IDE Mock (PyQt6)")
        self.resize(1300, 800)

        # ---- Central Editor
        self.editor = EditorTabs()
        self.setCentralWidget(self.editor)

        # ---- Left Dock (File Explorer)
        self.left_dock = QDockWidget("Explorer", self)
        self.left_dock.setWidget(FileExplorer())
        self.left_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.left_dock)

        # ---- Right Dock (AI Panel)
        self.right_dock = QDockWidget("AI", self)
        self.right_dock.setWidget(AIPanel())
        self.right_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.right_dock)

        # ---- Bottom Dock (Terminal)
        self.bottom_dock = QDockWidget("Terminal", self)
        self.bottom_dock.setWidget(Terminal())
        self.bottom_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.bottom_dock)

        # ---- Menu Bar
        menu = self.menuBar()

        file_menu = menu.addMenu("File")
        edit_menu = menu.addMenu("Edit")
        ai_menu = menu.addMenu("AI")

        file_menu.addAction("New File")
        file_menu.addAction("Save")
        file_menu.addAction("Open")

        ai_menu.addAction("Run AI Analysis")
        ai_menu.addAction("Generate Code")

        # ---- Left Activity Bar (VS Code style icon strip)
        activity_bar = QToolBar("Activity Bar")
        activity_bar.setMovable(False)
        self.addToolBar(Qt.ToolBarArea.LeftToolBarArea, activity_bar)
        activity_bar.setIconSize(QSize(24, 24))
        activity_bar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
        activity_bar.setStyleSheet("""
            QToolBar {
                background-color: #333333;
                border: none;
                spacing: 4px;
                padding: 4px;
            }
            QToolButton {
                color: #858585;
                background: transparent;
                border: none;
                padding: 6px;
                margin: 2px;
            }
            QToolButton:hover {
                color: #ffffff;
                background: #2d2d2d;
            }
            QToolButton:checked {
                color: #ffffff;
                border-left: 2px solid #007acc;
            }
        """)

        s = self.style()

        explorer_btn = QToolButton(activity_bar)
        explorer_btn.setCheckable(True)
        explorer_btn.setChecked(True)
        explorer_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_DirIcon))
        explorer_btn.setToolTip("Explorer")
        explorer_btn.clicked.connect(lambda: self.left_dock.setVisible(not self.left_dock.isVisible()))
        activity_bar.addWidget(explorer_btn)

        search_btn = QToolButton(activity_bar)
        search_btn.setCheckable(True)
        search_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_FileDialogListView))
        search_btn.setToolTip("Search")
        activity_bar.addWidget(search_btn)

        git_btn = QToolButton(activity_bar)
        git_btn.setCheckable(True)
        git_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_ArrowBack))
        git_btn.setToolTip("Source Control")
        activity_bar.addWidget(git_btn)

        debug_btn = QToolButton(activity_bar)
        debug_btn.setCheckable(True)
        debug_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_DialogCancelButton))
        debug_btn.setToolTip("Debug")
        activity_bar.addWidget(debug_btn)

        ai_btn = QToolButton(activity_bar)
        ai_btn.setCheckable(True)
        ai_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_BrowserReload))
        ai_btn.setToolTip("AI Panel")
        ai_btn.clicked.connect(lambda: self.right_dock.setVisible(not self.right_dock.isVisible()))
        activity_bar.addWidget(ai_btn)

        terminal_btn = QToolButton(activity_bar)
        terminal_btn.setCheckable(True)
        terminal_btn.setIcon(s.standardIcon(QStyle.StandardPixmap.SP_CommandLink))
        terminal_btn.setToolTip("Terminal")
        terminal_btn.clicked.connect(lambda: self.bottom_dock.setVisible(not self.bottom_dock.isVisible()))
        activity_bar.addWidget(terminal_btn)

        # ---- Top Toolbar (icon-based, VS Code style)
        toolbar = QToolBar("Main Toolbar")
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)
        toolbar.setIconSize(QSize(18, 18))
        toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)

        style = self.style()

        new_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_FileIcon), "New")
        new_action.setToolTip("New File (Ctrl+N)")

        open_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon), "Open")
        open_action.setToolTip("Open Folder (Ctrl+O)")

        save_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_DialogSaveButton), "Save")
        save_action.setToolTip("Save File (Ctrl+S)")

        toolbar.addSeparator()

        run_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_MediaPlay), "Run")
        run_action.setToolTip("Run Code (F5)")

        debug_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_DialogCancelButton), "Debug")
        debug_action.setToolTip("Debug (F6)")

        toolbar.addSeparator()

        ai_action = toolbar.addAction(style.standardIcon(QStyle.StandardPixmap.SP_BrowserReload), "AI")
        ai_action.setToolTip("AI Execute (Ctrl+Shift+A)")

        # ---- Status Bar
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("AI IDE Ready")

        # ---- Styling (VS Code-like dark theme)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e1e;
            }

            QDockWidget {
                color: white;
                font-weight: bold;
            }

            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                font-family: Menlo, Monaco, 'Courier New', monospace;
                font-size: 12px;
            }

            QListWidget {
                background-color: #252526;
                color: white;
                border: none;
            }

            QTabWidget::pane {
                border: 1px solid #333;
            }

            QTabBar::tab {
                background: #2d2d2d;
                color: white;
                padding: 6px;
            }

            QTabBar::tab:selected {
                background: #007acc;
            }

            QMenuBar {
                background-color: #2d2d30;
                color: white;
            }

            QMenuBar::item:selected {
                background: #3e3e42;
            }

            QDockWidget {
                background-color: #252526;
            }
        """)


# -------------------------
# Run
# -------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = IDEWindow()
    win.show()
    sys.exit(app.exec())