#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_pipeline.py"
# date="2026-06-28" author="Cascade" session_id="bcl-chat-compression"
# context="Consolidated BCL chat pipeline: Stage 1 code extraction + SQLite storage + Stage 2 AI prompt builder + BCL state serialization + pipeline loader. Merges bcl_chat_compressor.py, bcl_chat_store.py, bcl_chat_ai_prompt.py, bcl_state.py, Config_chat_mover.py."}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="bcl_pipeline.py" domain="ChatMover" authority="BclPipeline"}
#[@SUMMARY]{summary="Consolidated BCL chat pipeline module. Exports: BclChatCompressor (Stage 1), BclChatStore (SQLite), BclChatAiPrompt (Stage 2), BCLState (serialization), BclPipelineLoader (dispatch). All constants from Config_chat_mover.py inlined."}
#[@CLASS]{class="BclChatCompressor" domain="ChatMover" authority="single"}
#[@CLASS]{class="BclChatStore" domain="ChatMover" authority="single"}
#[@CLASS]{class="BclChatAiPrompt" domain="ChatMover" authority="single"}
#[@CLASS]{class="BCLState" domain="ChatMover" authority="single"}
#[@CLASS]{class="BclPipelineLoader" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}

"""
bcl_pipeline.py — Consolidated BCL chat pipeline.

Merges 5 modules into one importable file:
  - Config_chat_mover.py  -> constants (DB_DIR, DB_PATH, SCHEMA_SQL, etc.)
  - bcl_chat_compressor.py -> BclChatCompressor (Stage 1 code extraction)
  - bcl_chat_store.py      -> BclChatStore (SQLite storage)
  - bcl_chat_ai_prompt.py  -> BclChatAiPrompt (Stage 2 AI prompt builder)
  - bcl_state.py           -> BCLState (BCL serialization)
  - BclPipelineLoader (NEW) -> dispatch tying all stages together.

All methods return Tuple3: (1, data, None) or (0, None, (code, desc, 0)).
No print() in library code.
"""

import os
import re
import sys
import sqlite3
import hashlib
from datetime import datetime

# --- BCL core lexer/parser (kept as external import from core/Dom_Bcl/) ---
BCL_CORE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "core", "Dom_Bcl")
if BCL_CORE_DIR not in sys.path:
    sys.path.insert(0, BCL_CORE_DIR)

from bcl_lexer import BCLTokenizer
from bcl_parser import BCLParser, BCLNode


# ============================================================
# --- Constants (from Config_chat_mover.py) ---
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

BCL_CHAT_DB_DIR = os.path.join(BASE_DIR, "ProceesChatDatabase")
BCL_CHAT_DB_PATH = os.path.join(BCL_CHAT_DB_DIR, "bcl_chat_store.db")

# Aliases used by BclChatStore
DB_DIR = BCL_CHAT_DB_DIR
DB_PATH = BCL_CHAT_DB_PATH

BCL_CHAT_STORE_CONFIG = {
    "db_path": BCL_CHAT_DB_PATH,
    "db_dir": BCL_CHAT_DB_DIR,
    "schema_tables": [
        "original_chats",
        "bcl_stage1",
        "bcl_stage2",
        "chat_items",
    ],
    "stage1_min_lines": 500,
    "stage1_extractors": [
        "errors", "files", "commands", "frustration",
        "dialogue", "questions", "code_blocks", "topic_boundaries",
    ],
    "stage2_extractors": [
        "problems", "unresolved", "decisions",
        "successes", "failed", "lessons",
    ],
    "chat_sources_dir": os.path.expanduser("~/Downloads"),
    "compression_module": "bcl_pipeline",
    "stage2_module": "bcl_pipeline",
    "store_module": "bcl_pipeline",
}

MYSQL_CONFIG = {
    "user": "root",
    "host": "localhost",
    "port": 3306,
    "database": "vb_shared",
}

CHAT_PROCESSING_PIPELINE = [
    ("1_find", "Scan Downloads/ for .md chat exports"),
    ("2_store", "Store original chat in bcl_chat_store.db"),
    ("3_stage1", "Run BclChatCompressor.Run('compress') -> Stage 1 tokens"),
    ("4_store_stage1", "Store Stage 1 output in bcl_chat_store.db"),
    ("5_stage2", "AI semantic pass -> problems, unresolved, decisions, lessons"),
    ("6_store_stage2", "Store Stage 2 output + individual items in bcl_chat_store.db"),
    ("7_query", "Query unresolved items -> todo list for next session"),
]

BCL_CHAT_STORE_SCHEMA = """
CREATE TABLE IF NOT EXISTS original_chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_path TEXT NOT NULL,
    source_name TEXT NOT NULL,
    md5_hash TEXT NOT NULL,
    line_count INTEGER NOT NULL,
    file_size INTEGER NOT NULL,
    date_ingested TEXT NOT NULL,
    content TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bcl_stage1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    token_count INTEGER NOT NULL,
    compression_ratio REAL NOT NULL,
    output_lines INTEGER NOT NULL,
    output_text TEXT NOT NULL,
    stats_json TEXT,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id)
);

CREATE TABLE IF NOT EXISTS bcl_stage2 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    stage1_id INTEGER NOT NULL,
    problems_count INTEGER DEFAULT 0,
    unresolved_count INTEGER DEFAULT 0,
    decisions_count INTEGER DEFAULT 0,
    successes_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    lessons_count INTEGER DEFAULT 0,
    output_text TEXT NOT NULL,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id),
    FOREIGN KEY (stage1_id) REFERENCES bcl_stage1(id)
);

CREATE TABLE IF NOT EXISTS chat_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    stage2_id INTEGER NOT NULL,
    item_type TEXT NOT NULL,
    line_number INTEGER,
    content TEXT NOT NULL,
    status TEXT DEFAULT 'open',
    keyword TEXT,
    date_created TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES original_chats(id),
    FOREIGN KEY (stage2_id) REFERENCES bcl_stage2(id)
);

CREATE INDEX IF NOT EXISTS idx_original_chats_md5 ON original_chats(md5_hash);
CREATE INDEX IF NOT EXISTS idx_bcl_stage1_chat ON bcl_stage1(chat_id);
CREATE INDEX IF NOT EXISTS idx_bcl_stage2_chat ON bcl_stage2(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_items_type ON chat_items(item_type);
CREATE INDEX IF NOT EXISTS idx_chat_items_status ON chat_items(status);
"""

# Alias used by BclChatStore
SCHEMA_SQL = BCL_CHAT_STORE_SCHEMA


# ============================================================
# --- Class BclChatCompressor (Stage 1) ---
# Source: bcl_chat_compressor.py
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_chat_compressor.py"
# date="2026-06-28" author="Cascade" session_id="bcl-chat-compression"
# context="Stage 1: Code-based BCL extraction from chat history .md files"}
# ============================================================

FRUSTRATION_KEYWORDS = [
    "stuck", "frozen", "hang", "hung", "crash", "broke", "broken",
    "weird", "wrong", "why", "shit", "fuck", "damn", "hell",
    "not working", "doesn't work", "isn't working", "failed",
    "error", "bug", "issue", "problem", "annoying",
]

ERROR_PATTERNS = [
    (r"(\w*Error): (.+)", "python_error"),
    (r"Traceback \(most recent call last\):", "python_traceback"),
    (r"FAILED", "failed_marker"),
    (r"blocked", "blocked_marker"),
    (r"Permission denied", "permission_error"),
    (r"Command not found", "not_found_error"),
    (r"No such file or directory", "file_not_found"),
    (r"Segmentation fault", "segfault"),
]

FILE_PATH_PATTERNS = [
    r"(/[\w/\-]+\.py)",
    r"(/[\w/\-]+\.c)",
    r"(/[\w/\-]+\.md)",
    r"(/[\w/\-]+\.sh)",
    r"(/[\w/\-]+\.json)",
    r"(/[\w/\-]+\.sql)",
    r"(/[\w/\-]+\.yaml)",
    r"(/[\w/\-]+\.yml)",
]

USER_INPUT_HEADERS = [
    r"^### User Input",
    r"^### User",
    r"^## User",
    r"^User:",
    r"^> \*\*User",
]

AI_RESPONSE_HEADERS = [
    r"^### Planner Response",
    r"^### Assistant",
    r"^## Assistant",
    r"^AI:",
    r"^> \*\*Assistant",
]

COMMAND_ACCEPTED = r"\*User accepted command\*"
COMMAND_REJECTED = r"\*User rejected command\*"
COMMAND_PATTERN = r"```(?:bash|shell|sh)?\n(.*?)```"


class BclChatCompressor:
    """Stage 1: Code-based BCL extraction from chat .md files."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "min_lines": 500,
                "output_dir": "",
                "read_order": "bottom_up",
                "chronological": True,
                "inline_lessons": True,
                "extract_errors": True,
                "extract_files": True,
                "extract_commands": True,
                "extract_frustration": True,
                "extract_dialogue": True,
                "extract_questions": True,
                "cross_reference": True,
            },
            "source_path": None,
            "source_lines": [],
            "source_line_count": 0,
            "messages": [],
            "tokens": [],
            "stats": {},
            "output": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "compress":
            return self.Compress(params)
        elif command == "parse_structure":
            return self.ParseStructure(params)
        elif command == "extract_errors":
            return self.ExtractErrors(params)
        elif command == "extract_files":
            return self.ExtractFiles(params)
        elif command == "extract_commands":
            return self.ExtractCommands(params)
        elif command == "extract_frustration":
            return self.ExtractFrustration(params)
        elif command == "extract_code_blocks":
            return self.ExtractCodeBlocks(params)
        elif command == "extract_questions":
            return self.ExtractQuestions(params)
        elif command == "detect_topic_boundaries":
            return self.DetectTopicBoundaries(params)
        elif command == "format_output":
            return self.FormatOutput(params)
        elif command == "write_output":
            return self.WriteOutput(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Compress(self, params):
        input_path = self._p(params, "input_path")
        output_path = self._p(params, "output_path")
        dry_run = self._p(params, "dry_run", False)
        if not input_path:
            return (0, None, ("MISSING_PARAM", "input_path required", 0))

        rv = self._load_file(input_path)
        if rv[0] != 1:
            return rv

        if self.state["source_line_count"] < self.state["config"]["min_lines"]:
            return (0, None, ("TOO_SHORT",
                "File has %d lines, min is %d" % (
                    self.state["source_line_count"],
                    self.state["config"]["min_lines"]), 0))

        rv = self.ParseStructure(params)
        if rv[0] != 1:
            return rv

        self.state["tokens"] = []

        if self.state["config"]["extract_errors"]:
            self.ExtractErrors(params)
        if self.state["config"]["extract_files"]:
            self.ExtractFiles(params)
        if self.state["config"]["extract_commands"]:
            self.ExtractCommands(params)
        if self.state["config"]["extract_frustration"]:
            self.ExtractFrustration(params)
        if self.state["config"]["extract_dialogue"]:
            self.ExtractDialogue(params)
        if self.state["config"]["extract_questions"]:
            self.ExtractQuestions(params)

        self.DetectTopicBoundaries(params)

        self._compute_stats()

        rv = self.FormatOutput(params)
        if rv[0] != 1:
            return rv

        if dry_run:
            return (1, {
                "tokens": self.state["tokens"],
                "stats": self.state["stats"],
                "output": self.state["output"],
                "dry_run": True,
            }, None)

        if output_path:
            return self.WriteOutput({"output_path": output_path})
        return (1, {
            "tokens": self.state["tokens"],
            "stats": self.state["stats"],
            "output": self.state["output"],
        }, None)

    def _load_file(self, path):
        if not os.path.isfile(path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + path, 0))
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))
        self.state["source_path"] = path
        self.state["source_lines"] = content.splitlines()
        self.state["source_line_count"] = len(self.state["source_lines"])
        return (1, True, None)

    def ParseStructure(self, params):
        lines = self.state["source_lines"]
        messages = []
        current_role = None
        current_lines = []
        current_start = 0

        user_patterns = [re.compile(p, re.IGNORECASE) for p in USER_INPUT_HEADERS]
        ai_patterns = [re.compile(p, re.IGNORECASE) for p in AI_RESPONSE_HEADERS]

        for idx, line in enumerate(lines):
            is_user = any(p.match(line) for p in user_patterns)
            is_ai = any(p.match(line) for p in ai_patterns)

            if is_user or is_ai:
                if current_role is not None:
                    messages.append({
                        "role": current_role,
                        "lines": current_lines,
                        "start_line": current_start + 1,
                        "end_line": idx,
                        "text": "\n".join(current_lines),
                    })
                current_role = "user" if is_user else "ai"
                current_lines = []
                current_start = idx
            else:
                current_lines.append(line)

        if current_role is not None:
            messages.append({
                "role": current_role,
                "lines": current_lines,
                "start_line": current_start + 1,
                "end_line": len(lines),
                "text": "\n".join(current_lines),
            })

        self.state["messages"] = messages
        return (1, {"message_count": len(messages)}, None)

    def ExtractErrors(self, params):
        lines = self.state["source_lines"]
        errors = []
        for idx, line in enumerate(lines):
            for pattern, etype in ERROR_PATTERNS:
                m = re.search(pattern, line)
                if m:
                    error_text = m.group(0) if m.groups() else line.strip()
                    errors.append({
                        "type": "ERROR",
                        "line": idx + 1,
                        "error_type": etype,
                        "text": error_text[:200],
                    })
                    break
        self._add_tokens(errors)
        return (1, {"count": len(errors)}, None)

    def ExtractFiles(self, params):
        lines = self.state["source_lines"]
        seen = set()
        files = []
        for idx, line in enumerate(lines):
            for pattern in FILE_PATH_PATTERNS:
                for m in re.finditer(pattern, line):
                    path = m.group(1)
                    if path not in seen:
                        seen.add(path)
                        files.append({
                            "type": "FILE",
                            "line": idx + 1,
                            "path": path,
                        })
        self._add_tokens(files)
        return (1, {"count": len(files)}, None)

    def ExtractCommands(self, params):
        lines = self.state["source_lines"]
        commands = []
        for idx, line in enumerate(lines):
            if re.match(COMMAND_ACCEPTED, line.strip()):
                commands.append({
                    "type": "USER_APPROVED",
                    "line": idx + 1,
                })
            elif re.match(COMMAND_REJECTED, line.strip()):
                commands.append({
                    "type": "USER_REJECTED",
                    "line": idx + 1,
                })
        content = "\n".join(lines)
        for m in re.finditer(COMMAND_PATTERN, content, re.DOTALL):
            cmd = m.group(1).strip()
            if len(cmd) > 5:
                commands.append({
                    "type": "COMMAND_RAN",
                    "text": cmd[:200],
                })
        self._add_tokens(commands)
        return (1, {"count": len(commands)}, None)

    def ExtractFrustration(self, params):
        messages = self.state["messages"]
        signals = []
        for msg in messages:
            if msg["role"] != "user":
                continue
            text_lower = msg["text"].lower()
            for keyword in FRUSTRATION_KEYWORDS:
                if keyword in text_lower:
                    signals.append({
                        "type": "FRUSTRATION_SIGNAL",
                        "line": msg["start_line"],
                        "keyword": keyword,
                    })
                    break
        self._add_tokens(signals)
        return (1, {"count": len(signals)}, None)

    def ExtractCodeBlocks(self, params):
        lines = self.state["source_lines"]
        blocks = []
        in_block = False
        block_start = 0
        block_lang = ""
        block_lines = []
        for idx, line in enumerate(lines):
            if line.strip().startswith("```"):
                if in_block:
                    blocks.append({
                        "type": "CODE_BLOCK",
                        "start_line": block_start + 1,
                        "end_line": idx + 1,
                        "lang": block_lang,
                        "line_count": len(block_lines),
                    })
                    in_block = False
                    block_lines = []
                else:
                    in_block = True
                    block_start = idx
                    block_lang = line.strip()[3:].strip()
            elif in_block:
                block_lines.append(line)
        self._add_tokens(blocks)
        return (1, {"count": len(blocks)}, None)

    def ExtractDialogue(self, params):
        messages = self.state["messages"]
        dialogue = []
        for msg in messages:
            text = msg["text"].strip()
            if not text:
                continue
            first_line = text.split("\n")[0].strip()
            if msg["role"] == "user":
                dialogue.append({
                    "type": "USER_SAYS",
                    "line": msg["start_line"],
                    "text": first_line[:200],
                })
            else:
                dialogue.append({
                    "type": "AI_SAYS",
                    "line": msg["start_line"],
                    "text": first_line[:200],
                })
        self._add_tokens(dialogue)
        return (1, {"count": len(dialogue)}, None)

    def ExtractQuestions(self, params):
        messages = self.state["messages"]
        questions = []
        for msg in messages:
            if msg["role"] != "user":
                continue
            for line in msg["text"].split("\n"):
                line = line.strip()
                if "?" in line and len(line) > 10:
                    questions.append({
                        "type": "QUESTION",
                        "line": msg["start_line"],
                        "text": line[:200],
                    })
        self._add_tokens(questions)
        return (1, {"count": len(questions)}, None)

    def DetectTopicBoundaries(self, params):
        lines = self.state["source_lines"]
        topics = []
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("#") and not stripped.startswith("#[@"):
                heading = stripped.lstrip("#").strip()
                if heading and len(heading) > 3:
                    topics.append({
                        "type": "TOPIC",
                        "line": idx + 1,
                        "text": heading[:200],
                    })
        self._add_tokens(topics)
        return (1, {"count": len(topics)}, None)

    def _add_tokens(self, tokens):
        self.state["tokens"].extend(tokens)

    def _compute_stats(self):
        token_counts = {}
        for token in self.state["tokens"]:
            ttype = token["type"]
            token_counts[ttype] = token_counts.get(ttype, 0) + 1
        self.state["stats"] = {
            "source_lines": self.state["source_line_count"],
            "token_count": len(self.state["tokens"]),
            "token_types": token_counts,
            "message_count": len(self.state["messages"]),
        }

    def FormatOutput(self, params):
        source_path = self.state["source_path"] or "unknown"
        source_name = os.path.basename(source_path)
        source_lines = self.state["source_line_count"]
        stats = self.state["stats"]
        token_counts = stats.get("token_types", {})

        source_hash = hashlib.md5(open(source_path, "rb").read()).hexdigest()[:12] if os.path.isfile(source_path) else "auto"

        lines = []
        lines.append("#[@FILE]      %s path=%s" % (
            self._output_filename(source_name), source_path))
        lines.append("#[@FILEID]    md5=%s date=%s source=%s(%d_lines)" % (
            source_hash, datetime.now().strftime("%Y-%m-%d"), source_name, source_lines))
        lines.append("#[@SUMMARY]   BCL Stage 1 compression (code extraction). %d lines -> %d tokens." % (
            source_lines, stats.get("token_count", 0)))
        lines.append("#[@METHOD]    parse_structure -> regex_extraction -> dict_matching -> format_output")
        lines.append("#[@TOKENS]    Stage 1 only — AI semantic pass needed for [@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON] [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF]")
        lines.append("")
        lines.append("#[@CHAT]      source=%s lines=%d" % (source_name, source_lines))
        lines.append("#[@CHATSOURCE]{path=\"%s\";lines=%d;md5=%s;date=\"%s\"}" % (
            source_path, source_lines, source_hash, datetime.now().strftime("%Y-%m-%d")))
        lines.append("#[@CHATFULLIDEARS]{source=\"%s\";compressed_tokens=%d;compression_ratio=%.0f:1;stage=\"1_code_only\";stage2_needed=\"[@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON] [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF] [@MOOD] [@INTENT]\"}" % (
            source_name, stats.get("token_count", 0),
            source_lines / max(stats.get("token_count", 1), 1)))
        lines.append("")

        sorted_tokens = sorted(self.state["tokens"], key=lambda t: t.get("line", 0))

        current_line = 0
        for token in sorted_tokens:
            ttype = token["type"]
            tline = token.get("line", 0)
            if tline != current_line:
                lines.append("")
                current_line = tline

            if ttype == "USER_SAYS":
                lines.append("#[@USER_SAYS] L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "AI_SAYS":
                lines.append("#[@AI_SAYS]   L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "ERROR":
                lines.append("#[@ERROR]     L%d [%s] %s" % (tline, token.get("error_type", ""), token.get("text", "")))
            elif ttype == "FILE":
                lines.append("#[@FILE]      L%d %s" % (tline, token.get("path", "")))
            elif ttype == "COMMAND_RAN":
                lines.append("#[@COMMAND_RAN] %s" % token.get("text", ""))
            elif ttype == "USER_APPROVED":
                lines.append("#[@USER_APPROVED] L%d" % tline)
            elif ttype == "USER_REJECTED":
                lines.append("#[@USER_REJECTED] L%d" % tline)
            elif ttype == "FRUSTRATION_SIGNAL":
                lines.append("#[@FRUSTRATION_SIGNAL] L%d keyword=%s" % (tline, token.get("keyword", "")))
            elif ttype == "QUESTION":
                lines.append("#[@QUESTION]  L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "TOPIC":
                lines.append("#[@TOPIC]     L%d: %s" % (tline, token.get("text", "")))
            elif ttype == "CODE_BLOCK":
                lines.append("#[@CODE_BLOCK] L%d-%d lang=%s lines=%d" % (
                    tline, token.get("end_line", tline), token.get("lang", ""), token.get("line_count", 0)))

        lines.append("")
        lines.append("# ============================================================")
        lines.append("# STAGE 1 STATS (code extraction only)")
        lines.append("# ============================================================")
        lines.append("#[@STATS]     source_lines=%d -> tokens=%d" % (
            source_lines, stats.get("token_count", 0)))
        for ttype, count in sorted(token_counts.items()):
            lines.append("#[@STATS]     %s=%d" % (ttype, count))
        lines.append("#[@STATS]     messages=%d" % stats.get("message_count", 0))
        lines.append("")
        lines.append("# ============================================================")
        lines.append("# STAGE 2 NEEDED — AI must extract:")
        lines.append("# ============================================================")
        lines.append("#[@NEEDED]    [@PROBLEM] [@SOLUTION] [@ROOT_CAUSE] [@LESSON]")
        lines.append("#[@NEEDED]    [@SUCCESS] [@FAILED] [@DECISION] [@USER_PREF]")
        lines.append("#[@NEEDED]    [@MOOD] [@INTENT] [@AI_CORRECT] [@AI_WRONG]")
        lines.append("#[@NEEDED]    Pair problems with solutions, inline lessons under problems")
        lines.append("#[@NEEDED]    Output in chronological order with cause chain")

        self.state["output"] = "\n".join(lines)
        return (1, {"output_length": len(lines)}, None)

    def _output_filename(self, source_name):
        base, _ = os.path.splitext(source_name)
        return base + "_BCL.md"

    def WriteOutput(self, params):
        output_path = self._p(params, "output_path")
        if not output_path:
            source_path = self.state["source_path"]
            if source_path:
                base, _ = os.path.splitext(source_path)
                output_path = base + "_BCL.md"
            else:
                return (0, None, ("MISSING_PARAM", "output_path required", 0))

        output_dir = self.state["config"].get("output_dir", "")
        if output_dir:
            output_path = os.path.join(output_dir, os.path.basename(output_path))

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(self.state["output"])
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))
        return (1, {"output_path": output_path, "lines": len(self.state["output"].splitlines())}, None)


# ============================================================
# --- Class BclChatStore (uses constants above) ---
# Source: bcl_chat_store.py
#[@GHOST]{[@file<bcl_chat_store.py>][@domain<chat_mover>][@role<storage>][@auth<cascade>][@date<2026-06-28>][@ver<1.0>]}
# ============================================================


class BclChatStore:
    """SQLite storage for original chat + BCL compressed versions."""

    def __init__(self, mem=None, db=None, param=None):
        self.mem = mem
        self.db = db
        self.param = param if isinstance(param, dict) else {}
        self.state = {
            "config": self.param.get("config", {}),
            "db_path": self.param.get("db_path", DB_PATH),
            "conn": None,
            "cur": None,
        }

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def open(self, params=None):
        try:
            db_path = self._p(params, "db_path", self.state["db_path"])
            db_dir = os.path.dirname(db_path)
            if db_dir and not os.path.exists(db_dir):
                os.makedirs(db_dir)
            self.state["conn"] = sqlite3.connect(db_path)
            self.state["cur"] = self.state["conn"].cursor()
            self.state["conn"].executescript(SCHEMA_SQL)
            self.state["conn"].commit()
            return (1, {"connected": True, "db_path": db_path}, None)
        except Exception as e:
            return (0, None, ("OPEN_ERROR", str(e), 0))

    def close(self, params=None):
        try:
            if self.state["conn"]:
                self.state["conn"].commit()
                self.state["conn"].close()
                self.state["conn"] = None
                self.state["cur"] = None
            return (1, {"closed": True}, None)
        except Exception as e:
            return (0, None, ("CLOSE_ERROR", str(e), 0))

    def store_chat(self, params):
        """Store original chat file content."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            source_path = self._p(params, "source_path", "")
            content = self._p(params, "content", "")
            if not source_path or not content:
                return (0, None, ("MISSING_PARAM", "source_path and content required", 0))

            source_name = os.path.basename(source_path)
            md5_hash = hashlib.md5(content.encode("utf-8")).hexdigest()[:12]
            line_count = len(content.splitlines())
            file_size = len(content.encode("utf-8"))
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            cur.execute(
                "SELECT id FROM original_chats WHERE md5_hash = ?",
                (md5_hash,)
            )
            existing = cur.fetchone()
            if existing:
                return (1, {"chat_id": existing[0], "already_exists": True}, None)

            cur.execute(
                "INSERT INTO original_chats (source_path, source_name, md5_hash, line_count, file_size, date_ingested, content) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (source_path, source_name, md5_hash, line_count, file_size, date_now, content)
            )
            chat_id = cur.lastrowid
            self.state["conn"].commit()
            return (1, {"chat_id": chat_id, "md5": md5_hash, "lines": line_count}, None)
        except Exception as e:
            return (0, None, ("STORE_CHAT_ERROR", str(e), 0))

    def store_stage1(self, params):
        """Store Stage 1 BCL compression output."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            chat_id = self._p(params, "chat_id")
            output_text = self._p(params, "output_text", "")
            token_count = self._p(params, "token_count", 0)
            compression_ratio = self._p(params, "compression_ratio", 0.0)
            output_lines = self._p(params, "output_lines", 0)
            stats_json = self._p(params, "stats_json", "")
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            if not chat_id:
                return (0, None, ("MISSING_PARAM", "chat_id required", 0))

            cur.execute(
                "INSERT INTO bcl_stage1 (chat_id, token_count, compression_ratio, output_lines, output_text, stats_json, date_created) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (chat_id, token_count, compression_ratio, output_lines, output_text, stats_json, date_now)
            )
            stage1_id = cur.lastrowid
            self.state["conn"].commit()
            return (1, {"stage1_id": stage1_id}, None)
        except Exception as e:
            return (0, None, ("STORE_STAGE1_ERROR", str(e), 0))

    def store_stage2(self, params):
        """Store Stage 2 AI semantic pass output + individual items."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            chat_id = self._p(params, "chat_id")
            stage1_id = self._p(params, "stage1_id")
            output_text = self._p(params, "output_text", "")
            items = self._p(params, "items", [])
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            if not chat_id or not stage1_id:
                return (0, None, ("MISSING_PARAM", "chat_id and stage1_id required", 0))

            counts = {}
            for item in items:
                itype = item.get("type", "unknown")
                counts[itype] = counts.get(itype, 0) + 1

            cur.execute(
                "INSERT INTO bcl_stage2 (chat_id, stage1_id, problems_count, unresolved_count, decisions_count, successes_count, failed_count, lessons_count, output_text, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    chat_id, stage1_id,
                    counts.get("PROBLEM", 0),
                    counts.get("UNRESOLVED", 0),
                    counts.get("DECISION", 0),
                    counts.get("SUCCESS", 0),
                    counts.get("FAILED", 0),
                    counts.get("LESSON", 0),
                    output_text, date_now
                )
            )
            stage2_id = cur.lastrowid

            for item in items:
                cur.execute(
                    "INSERT INTO chat_items (chat_id, stage2_id, item_type, line_number, content, status, keyword, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        chat_id, stage2_id,
                        item.get("type", "unknown"),
                        item.get("line", 0),
                        item.get("content", ""),
                        item.get("status", "open"),
                        item.get("keyword", ""),
                        date_now
                    )
                )

            self.state["conn"].commit()
            return (1, {"stage2_id": stage2_id, "items_stored": len(items)}, None)
        except Exception as e:
            return (0, None, ("STORE_STAGE2_ERROR", str(e), 0))

    def list_chats(self, params=None):
        """List all stored chats with their stage counts."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            cur.execute("""
                SELECT c.id, c.source_name, c.line_count, c.date_ingested,
                       s1.token_count, s1.output_lines,
                       s2.problems_count, s2.unresolved_count, s2.decisions_count
                FROM original_chats c
                LEFT JOIN bcl_stage1 s1 ON s1.chat_id = c.id
                LEFT JOIN bcl_stage2 s2 ON s2.chat_id = c.id
                ORDER BY c.date_ingested DESC
            """)
            rows = cur.fetchall()
            chats = []
            for row in rows:
                chats.append({
                    "chat_id": row[0],
                    "source_name": row[1],
                    "line_count": row[2],
                    "date_ingested": row[3],
                    "stage1_tokens": row[4],
                    "stage1_lines": row[5],
                    "stage2_problems": row[6],
                    "stage2_unresolved": row[7],
                    "stage2_decisions": row[8],
                })
            return (1, {"chats": chats, "count": len(chats)}, None)
        except Exception as e:
            return (0, None, ("LIST_CHATS_ERROR", str(e), 0))

    def get_unresolved(self, params=None):
        """Get all unresolved items across all chats."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            cur.execute("""
                SELECT ci.id, ci.chat_id, ci.line_number, ci.content, ci.status, ci.keyword,
                       oc.source_name
                FROM chat_items ci
                JOIN original_chats oc ON oc.id = ci.chat_id
                WHERE ci.item_type = 'UNRESOLVED'
                ORDER BY ci.line_number DESC
            """)
            rows = cur.fetchall()
            items = []
            for row in rows:
                items.append({
                    "item_id": row[0],
                    "chat_id": row[1],
                    "line": row[2],
                    "content": row[3],
                    "status": row[4],
                    "keyword": row[5],
                    "source": row[6],
                })
            return (1, {"items": items, "count": len(items)}, None)
        except Exception as e:
            return (0, None, ("GET_UNRESOLVED_ERROR", str(e), 0))

    def resolve_item(self, params):
        """Mark a chat item as resolved."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            item_id = self._p(params, "item_id")
            if not item_id:
                return (0, None, ("MISSING_PARAM", "item_id required", 0))
            cur.execute("UPDATE chat_items SET status = 'resolved' WHERE id = ?", (item_id,))
            self.state["conn"].commit()
            return (1, {"item_id": item_id, "status": "resolved"}, None)
        except Exception as e:
            return (0, None, ("RESOLVE_ERROR", str(e), 0))

    def get_stats(self, params=None):
        """Get database statistics."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            stats = {}
            cur.execute("SELECT COUNT(*) FROM original_chats")
            stats["chats"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM bcl_stage1")
            stats["stage1_outputs"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM bcl_stage2")
            stats["stage2_outputs"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items")
            stats["total_items"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items WHERE status = 'open'")
            stats["open_items"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items WHERE status = 'resolved'")
            stats["resolved_items"] = cur.fetchone()[0]
            cur.execute("SELECT item_type, COUNT(*) FROM chat_items GROUP BY item_type")
            for row in cur.fetchall():
                stats["items_" + row[0].lower()] = row[1]
            return (1, stats, None)
        except Exception as e:
            return (0, None, ("STATS_ERROR", str(e), 0))

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        try:
            if isinstance(params, dict):
                for key, value in params.items():
                    self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("CONFIG_ERROR", str(e), 0))

    def Run(self, command, params=None):
        params = params or {}
        dispatch = {
            "open": self.open,
            "close": self.close,
            "store_chat": self.store_chat,
            "store_stage1": self.store_stage1,
            "store_stage2": self.store_stage2,
            "list_chats": self.list_chats,
            "get_unresolved": self.get_unresolved,
            "resolve_item": self.resolve_item,
            "get_stats": self.get_stats,
            "read_state": self.read_state,
            "set_config": self.set_config,
        }
        handler = dispatch.get(command)
        if handler:
            return handler(params)
        return (0, None, ("UNKNOWN_COMMAND", command, 0))


# ============================================================
# --- Class BclChatAiPrompt (Stage 2) ---
# Source: bcl_chat_ai_prompt.py
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_chat_ai_prompt.py"
# date="2026-06-28" author="Cascade" session_id="bcl-chat-compression"
# context="Stage 2: AI prompt builder for semantic BCL extraction from preliminary tokens"}
# ============================================================

PROMPT_TEMPLATE = """You are a BCL (Bracketed Concept Language) chat compression engine. Your job is to read the preliminary tokens extracted by Stage 1 (code) and the raw chat source, then extract SEMANTIC tokens that code cannot extract.

## Preliminary Tokens (from Stage 1 — code extraction)

{preliminary_tokens}

## Instructions

Read the preliminary tokens above and the raw chat source. Extract the following semantic tokens IN CHRONOLOGICAL ORDER:

### Tokens to Extract

1. [@PROBLEM] — What went wrong. Each problem should be a single sentence.
2. [@SOLUTION] — How it was fixed. Directly below the problem it solves.
3. [@ROOT_CAUSE] — Why it happened. The underlying cause, not the symptom.
4. [@SUCCESS] — Approaches that worked. Proven paths to repeat.
5. [@FAILED] — Approaches that didn't work. Dead ends to avoid.
6. [@LESSON] — Cumulative takeaway. Place DIRECTLY BELOW the [@PROBLEM] it relates to.
7. [@DECISION] — Key decision points where a choice was made.
8. [@USER_PREF] — User preferences extracted from their messages.
9. [@MOOD] — User mood inferred from word choice, punctuation, tone.
10. [@INTENT] — What the user actually wanted (not what they literally said).
11. [@AI_CORRECT] — When the AI did the right thing.
12. [@AI_WRONG] — When the AI did the wrong thing or misunderstood.

### Output Format

Output as a chronological timeline (T1, T2, T3...) with inline lessons:

```
# --- T1: Shell Config (lines 1-200) ---
#[@USER_SAYS] "fix this issue"
#[@AI_SAYS]   "shell is already zsh, suppress warning"
#[@PROBLEM]   macOS bash deprecation warning every terminal open
#[@SOLUTION]  add BASH_SILENCE_DEPRECATION_WARNING=1
#[@SUCCESS]   warning suppressed
#[@LESSON]    check actual state before fixing
```

### Rules

- Each problem MUST have its lesson directly below it (inline lessons)
- Problems and solutions must be paired (problem first, solution below)
- Root causes go below the problem, above the solution
- Output in chronological order (by line number in source chat)
- Keep each token to one line, max 200 chars
- Include [@USER_SAYS] and [@AI_SAYS] from Stage 1 as context anchors
- At the end, include a cumulative LESSONS LEARNED section
- At the end, include COMPRESSION STATS

### Source Chat Reference

The raw chat source is at: {source_path}
Read it if you need more context than the preliminary tokens provide.
"""


class BclChatAiPrompt:
    """Stage 2: Builds AI prompt for semantic BCL extraction."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "chronological": True,
                "inline_lessons": True,
                "max_preliminary_lines": 500,
            },
            "preliminary_path": None,
            "source_path": None,
            "preliminary_content": "",
            "prompt": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "build_prompt":
            return self.BuildPrompt(params)
        elif command == "parse_preliminary":
            return self.ParsePreliminary(params)
        elif command == "format_prompt":
            return self.FormatPrompt(params)
        elif command == "write_prompt":
            return self.WritePrompt(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def BuildPrompt(self, params):
        preliminary_path = self._p(params, "preliminary_path")
        source_path = self._p(params, "source_path")
        output_path = self._p(params, "output_path")
        if not preliminary_path:
            return (0, None, ("MISSING_PARAM", "preliminary_path required", 0))

        rv = self.ParsePreliminary({"preliminary_path": preliminary_path})
        if rv[0] != 1:
            return rv

        self.state["source_path"] = source_path or ""

        rv = self.FormatPrompt(params)
        if rv[0] != 1:
            return rv

        if output_path:
            return self.WritePrompt({"output_path": output_path})
        return (1, {"prompt": self.state["prompt"], "length": len(self.state["prompt"])}, None)

    def ParsePreliminary(self, params):
        path = self._p(params, "preliminary_path")
        if not path:
            return (0, None, ("MISSING_PARAM", "preliminary_path required", 0))
        if not os.path.isfile(path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + path, 0))
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        max_lines = self.state["config"]["max_preliminary_lines"]
        lines = content.splitlines()
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines.append("# ... (truncated, %d total lines)" % len(content.splitlines()))
        self.state["preliminary_path"] = path
        self.state["preliminary_content"] = "\n".join(lines)
        return (1, {"lines": len(lines)}, None)

    def FormatPrompt(self, params):
        prompt = PROMPT_TEMPLATE.format(
            preliminary_tokens=self.state["preliminary_content"],
            source_path=self.state["source_path"] or "(not provided)",
        )
        self.state["prompt"] = prompt
        return (1, {"length": len(prompt)}, None)

    def WritePrompt(self, params):
        output_path = self._p(params, "output_path")
        if not output_path:
            base = self.state["preliminary_path"]
            if base:
                base_no_ext, _ = os.path.splitext(base)
                output_path = base_no_ext + "_AI_PROMPT.md"
            else:
                return (0, None, ("MISSING_PARAM", "output_path required", 0))
        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(self.state["prompt"])
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))
        return (1, {"output_path": output_path, "length": len(self.state["prompt"])}, None)


# ============================================================
# --- Class BCLState ---
# Source: bcl_state.py
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_state.py"
# date="2026-06-28" author="Cascade" session_id="pipeline-bcl"
# context="BCL state serialization: convert Python dicts/lists to BCL text and back. Replaces JSON for pipeline_maker.py"}
# ============================================================


class BCLState:
    """Serialize Python dicts to BCL containers, deserialize BCL text to Python dicts."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {},
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "serialize":
            return self.Serialize(params)
        elif command == "deserialize":
            return self.Deserialize(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Serialize(self, params):
        data = self._p(params, "data")
        name = self._p(params, "name", "Root")
        if data is None:
            return (0, None, ("MISSING_PARAM", "data required", 0))
        text = self.SerializeValue(name, data, 0)
        return (1, text, None)

    def SerializeValue(self, name, value, indent):
        pad = "    " * indent
        lines = ["[@%s]{" % name]
        if isinstance(value, dict):
            for key, val in value.items():
                if isinstance(val, dict):
                    lines.append(self.SerializeValue(key, val, indent + 1))
                elif isinstance(val, list):
                    if len(val) == 1 and isinstance(val[0], (str, int, float, bool)):
                        lines.append('%s    ("__list__";"%s")' % (pad, key))
                    if all(isinstance(v, (str, int, float, bool)) for v in val):
                        parts = []
                        for v in val:
                            if isinstance(v, bool):
                                parts.append('"true"' if v else '"false"')
                            elif isinstance(v, (int, float)):
                                parts.append(str(v))
                            else:
                                escaped = str(v).replace('"', '\\"').replace("\n", "\\n")
                                parts.append('"%s"' % escaped)
                        lines.append("%s    (\"%s\";%s)" % (pad, key, ";".join(parts)))
                    elif all(isinstance(v, dict) for v in val):
                        for i, item in enumerate(val):
                            lines.append(self.SerializeValue("%s_%d" % (key, i), item, indent + 1))
                    else:
                        parts = []
                        for v in val:
                            if isinstance(v, bool):
                                parts.append('"true"' if v else '"false"')
                            elif isinstance(v, (int, float)):
                                parts.append(str(v))
                            else:
                                escaped = str(v).replace('"', '\\"').replace("\n", "\\n")
                                parts.append('"%s"' % escaped)
                        lines.append("%s    (\"%s\";%s)" % (pad, key, ";".join(parts)))
                elif isinstance(val, bool):
                    lines.append('%s    ("%s";"%s")' % (pad, key, "true" if val else "false"))
                elif isinstance(val, (int, float)):
                    lines.append('%s    ("%s";%s)' % (pad, key, str(val)))
                elif isinstance(val, str):
                    escaped = val.replace('"', '\\"').replace("\n", "\\n")
                    lines.append('%s    ("%s";"%s")' % (pad, key, escaped))
                elif val is None:
                    lines.append('%s    ("%s";"")' % (pad, key))
        lines.append("%s}" % pad)
        return "\n".join(lines)

    def Deserialize(self, params):
        text = self._p(params, "text")
        if text is None:
            return (0, None, ("MISSING_PARAM", "text required", 0))
        tokenizer = BCLTokenizer()
        tok_rv = tokenizer.Run("tokenize", {"text": text})
        if tok_rv[0] != 1:
            return (0, None, ("TOKENIZE_ERROR", str(tok_rv[2]), 0))
        tokens = tok_rv[1]["tokens"]
        parser = BCLParser()
        parse_rv = parser.Run("parse", {"tokens": tokens})
        if parse_rv[0] != 1:
            return (0, None, ("PARSE_ERROR", str(parse_rv[2]), 0))
        root = parse_rv[1]["root"]
        children = root.state["children"]
        if not children:
            return (0, None, ("EMPTY_BCL", "No containers found in text", 0))
        result = self.DeserializeNode(children[0])
        return (1, result, None)

    def DeserializeNode(self, node):
        result = {}
        list_keys = set()
        for t in node.state["tuples"]:
            if not t:
                continue
            key = t[0]
            if key == "__list__":
                list_keys.add(t[1])
                continue
            if len(t) == 2:
                result[key] = t[1]
            elif len(t) >= 3:
                values = t[1:]
                if all(isinstance(v, (int, float)) for v in values):
                    result[key] = values[0]
                else:
                    result[key] = list(values)
        for lk in list_keys:
            if lk in result and not isinstance(result[lk], list):
                result[lk] = [result[lk]]
        for child in node.state["children"]:
            child_name = child.state["name"]
            if "_" in child_name and child_name.split("_")[-1].isdigit():
                base_key = "_".join(child_name.split("_")[:-1])
                if base_key not in result:
                    result[base_key] = []
                result[base_key].append(self.DeserializeNode(child))
            else:
                result[child_name] = self.DeserializeNode(child)
        return result


def dict_to_bcl(data, name="Root"):
    """Convenience function: dict to BCL text."""
    state = BCLState()
    rv = state.Serialize({"data": data, "name": name})
    return rv[1] if rv[0] == 1 else ""


def bcl_to_dict(text):
    """Convenience function: BCL text to dict."""
    state = BCLState()
    rv = state.Deserialize({"text": text})
    return rv[1] if rv[0] == 1 else {}


def list_to_bcl(items, name="List"):
    """Convenience function: list to BCL container."""
    state = BCLState()
    data = {name: items}
    rv = state.Serialize({"data": data, "name": name})
    return rv[1] if rv[0] == 1 else ""


def bcl_to_list(text):
    """Convenience function: BCL text to list (extracts first tuple values)."""
    d = bcl_to_dict(text)
    if not d:
        return []
    for key, val in d.items():
        if isinstance(val, list):
            return val
    return []


# ============================================================
# --- Class BclPipelineLoader (NEW) ---
# Ties all stages together: store -> compress (Stage 1) -> build AI prompt (Stage 2)
# ============================================================


class BclPipelineLoader:
    """Dispatch loader tying all BCL chat pipeline stages together."""

    def __init__(self, mem=None, db=None, param=None):
        self.mem = mem
        self.db = db
        self.param = param if isinstance(param, dict) else {}
        self.state = {
            "config": self.param.get("config", {
                "db_path": DB_PATH,
                "min_lines": 500,
                "output_dir": "",
            }),
            "compressor": None,
            "store": None,
            "prompt_builder": None,
            "bcl_state": None,
            "last_result": None,
            "memunit": mem,
            "db_manager": db,
        }

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def Run(self, command, params=None):
        params = params or {}
        if command == "ingest":
            return self.Ingest(params)
        elif command == "compress":
            return self.Compress(params)
        elif command == "store":
            return self.Store(params)
        elif command == "stats":
            return self.Stats(params)
        elif command == "unresolved":
            return self.Unresolved(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def Ingest(self, params):
        """Full pipeline: store original -> compress (Stage 1) -> build AI prompt (Stage 2) -> return prompt."""
        input_path = self._p(params, "input_path")
        output_path = self._p(params, "output_path")
        if not input_path:
            return (0, None, ("MISSING_PARAM", "input_path required", 0))

        # Stage 0: store original chat
        store_rv = self.Store({"chat_path": input_path})
        chat_id = None
        if store_rv[0] == 1:
            chat_id = store_rv[1].get("chat_id")

        # Stage 1: compress
        compress_params = {"input_path": input_path}
        if output_path:
            compress_params["output_path"] = output_path
        compress_rv = self.Compress(compress_params)
        if compress_rv[0] != 1:
            return compress_rv

        stage1_data = compress_rv[1]
        stage1_output = stage1_data.get("output", "")
        stage1_output_path = stage1_data.get("output_path")

        # Store Stage 1 output if we have a chat_id and a store connection
        if chat_id and self.state["store"]:
            store_obj = self.state["store"]
            stats = stage1_data.get("stats", {})
            token_count = stats.get("token_count", 0)
            source_lines = stats.get("source_lines", 1)
            ratio = source_lines / max(token_count, 1)
            output_lines = len(stage1_output.splitlines())
            store_obj.Run("store_stage1", {
                "chat_id": chat_id,
                "output_text": stage1_output,
                "token_count": token_count,
                "compression_ratio": ratio,
                "output_lines": output_lines,
                "stats_json": "",
            })

        # Stage 2: build AI prompt (returns prompt for external AI)
        prompt_rv = None
        if stage1_output_path and os.path.isfile(stage1_output_path):
            prompt_builder = BclChatAiPrompt()
            self.state["prompt_builder"] = prompt_builder
            prompt_rv = prompt_builder.Run("build_prompt", {
                "preliminary_path": stage1_output_path,
                "source_path": input_path,
            })
        elif stage1_output:
            # Write preliminary to temp file so prompt builder can read it
            tmp_path = output_path + "_BCL.md" if output_path else input_path + "_BCL.md"
            try:
                with open(tmp_path, "w", encoding="utf-8") as f:
                    f.write(stage1_output)
                prompt_builder = BclChatAiPrompt()
                self.state["prompt_builder"] = prompt_builder
                prompt_rv = prompt_builder.Run("build_prompt", {
                    "preliminary_path": tmp_path,
                    "source_path": input_path,
                })
            except Exception as exc:
                prompt_rv = (0, None, ("PROMPT_BUILD_ERROR", str(exc), 0))

        prompt_text = ""
        if prompt_rv and prompt_rv[0] == 1:
            prompt_text = prompt_rv[1].get("prompt", "")

        result = {
            "chat_id": chat_id,
            "stage1": stage1_data,
            "stage1_output_path": stage1_output_path,
            "stage2_prompt": prompt_text,
            "stage2_prompt_length": len(prompt_text),
        }
        self.state["last_result"] = result
        return (1, result, None)

    def Compress(self, params):
        """Stage 1 only: BclChatCompressor."""
        input_path = self._p(params, "input_path")
        if not input_path:
            return (0, None, ("MISSING_PARAM", "input_path required", 0))
        compressor = BclChatCompressor(param={
            "min_lines": self.state["config"].get("min_lines", 500),
            "output_dir": self.state["config"].get("output_dir", ""),
        })
        self.state["compressor"] = compressor
        rv = compressor.Run("compress", params)
        return rv

    def Store(self, params):
        """Store original chat file."""
        chat_path = self._p(params, "chat_path")
        if not chat_path:
            return (0, None, ("MISSING_PARAM", "chat_path required", 0))
        if not os.path.isfile(chat_path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + chat_path, 0))
        try:
            with open(chat_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        store = BclChatStore(param={"db_path": self.state["config"].get("db_path", DB_PATH)})
        self.state["store"] = store
        open_rv = store.Run("open", {})
        if open_rv[0] != 1:
            return open_rv
        store_rv = store.Run("store_chat", {
            "source_path": chat_path,
            "content": content,
        })
        return store_rv

    def Stats(self, params):
        """Query BclChatStore for DB stats."""
        store = BclChatStore(param={"db_path": self.state["config"].get("db_path", DB_PATH)})
        self.state["store"] = store
        open_rv = store.Run("open", {})
        if open_rv[0] != 1:
            return open_rv
        return store.Run("get_stats", {})

    def Unresolved(self, params):
        """Query BclChatStore for unresolved items."""
        store = BclChatStore(param={"db_path": self.state["config"].get("db_path", DB_PATH)})
        self.state["store"] = store
        open_rv = store.Run("open", {})
        if open_rv[0] != 1:
            return open_rv
        return store.Run("get_unresolved", {})
