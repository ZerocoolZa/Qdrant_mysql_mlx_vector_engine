#!/usr/bin/env python3
"""
Devin Chat GUI — PyQt6 chat interface for talking to Devin CLI.

Spawns `devin -p` in print mode, continues the same session with -c.
User messages on the right (blue), Devin responses on the left (dark gray).
Exports each turn to /tmp/devin_gui_export.json for persistence.
"""

import sys
import subprocess
import json
from datetime import datetime

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QTextCursor, QKeyEvent
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QScrollArea,
    QFrame, QSplitter
)

DEVIN_CMD = "devin"
EXPORT_PATH = "/tmp/devin_gui_export.json"


class DevinWorker(QThread):
    """Run devin -p in a background thread so the GUI doesn't freeze."""
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, message, continue_session=True):
        super().__init__()
        self.message = message
        self.continue_session = continue_session

    def run(self):
        cmd = [DEVIN_CMD, "-p", self.message, "--export", EXPORT_PATH]
        if self.continue_session:
            cmd.insert(2, "-c")
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode == 0:
                self.finished.emit(result.stdout.strip())
            else:
                err = result.stderr.strip() if result.stderr else "Unknown error"
                self.error.emit(f"Exit {result.returncode}: {err}")
        except subprocess.TimeoutExpired:
            self.error.emit("Devin timed out (300s)")
        except Exception as e:
            self.error.emit(str(e))


class ChatBubble(QFrame):
    """A single chat message bubble."""

    def __init__(self, text, is_user=False, parent=None):
        super().__init__(parent)
        self.is_user = is_user

        if is_user:
            bg = "#2563eb"
            fg = "#ffffff"
            align = Qt.AlignmentFlag.AlignRight
        else:
            bg = "#1e293b"
            fg = "#e2e8f0"
            align = Qt.AlignmentFlag.AlignLeft

        self.setStyleSheet(f"""
            QFrame {{
                background-color: {bg};
                border-radius: 12px;
                padding: 10px 14px;
                max-width: 600px;
            }}
        """)

        label = QLabel(text)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.RichText)
        label.setStyleSheet(f"color: {fg}; font-size: 14px; background: transparent;")
        label.setAlignment(align)

        time_label = QLabel(datetime.now().strftime("%H:%M"))
        time_label.setStyleSheet("color: #64748b; font-size: 10px; background: transparent;")
        time_label.setAlignment(align)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 4)
        layout.setSpacing(2)
        layout.addWidget(label)
        layout.addWidget(time_label)


class InputBox(QLineEdit):
    """Line edit that sends on Enter, newline on Shift+Enter."""
    submitted = pyqtSignal(str)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key.Key_Return and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            text = self.text().strip()
            if text:
                self.submitted.emit(text)
                self.clear()
            return
        super().keyPressEvent(event)


class DevinChatGUI(QMainWindow):
    """Main chat window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Devin Chat")
        self.resize(800, 700)
        self.setStyleSheet("""
            QMainWindow { background-color: #0f172a; }
            QLabel { color: #e2e8f0; }
        """)

        self.first_message = True
        self.worker = None
        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        layout = QVBoxLayout(central)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        # Header
        header = QLabel("Devin Chat")
        header.setStyleSheet("color: #38bdf8; font-size: 18px; font-weight: bold; padding: 4px;")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)

        # Chat history scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea {
                background-color: #0f172a;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)

        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setContentsMargins(8, 8, 8, 8)
        self.chat_layout.setSpacing(10)
        self.chat_layout.addStretch()

        scroll.setWidget(self.chat_container)
        layout.addWidget(scroll, stretch=1)

        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #64748b; font-size: 11px; padding: 2px;")
        layout.addWidget(self.status_label)

        # Input row
        input_row = QHBoxLayout()
        input_row.setSpacing(8)

        self.input_box = InputBox()
        self.input_box.setPlaceholderText("Type a message to Devin... (Enter to send)")
        self.input_box.setStyleSheet("""
            QLineEdit {
                background-color: #1e293b;
                color: #e2e8f0;
                border: 1px solid #334155;
                border-radius: 8px;
                padding: 10px 14px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #38bdf8;
            }
        """)
        self.input_box.submitted.connect(self._on_send)
        input_row.addWidget(self.input_box, stretch=1)

        self.send_btn = QPushButton("Send")
        self.send_btn.setStyleSheet("""
            QPushButton {
                background-color: #2563eb;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #1d4ed8; }
            QPushButton:disabled { background-color: #1e293b; color: #64748b; }
        """)
        self.send_btn.clicked.connect(self._on_send_click)
        input_row.addWidget(self.send_btn)

        layout.addLayout(input_row)

    def _add_bubble(self, text, is_user=False):
        bubble = ChatBubble(text, is_user)
        wrapper = QHBoxLayout()
        wrapper.setContentsMargins(0, 0, 0, 0)
        if is_user:
            wrapper.addStretch()
            wrapper.addWidget(bubble)
        else:
            wrapper.addWidget(bubble)
            wrapper.addStretch()

        # Insert before the stretch at the end
        self.chat_layout.insertLayout(self.chat_layout.count() - 1, wrapper)

        # Scroll to bottom
        QTimer_singleShot(self, 0, lambda: self._scroll_to_bottom())

    def _scroll_to_bottom(self):
        scroll = self.centralWidget().layout().itemAt(1).widget()
        bar = scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _on_send_click(self):
        text = self.input_box.text().strip()
        if text:
            self._on_send(text)

    def _on_send(self, text):
        if self.worker and self.worker.isRunning():
            return

        # Show user message
        self._add_bubble(text, is_user=True)

        # Disable input
        self.input_box.setEnabled(False)
        self.send_btn.setEnabled(False)
        self.status_label.setText("Devin is thinking...")
        self.status_label.setStyleSheet("color: #f59e0b; font-size: 11px; padding: 2px;")

        # Start worker
        self.worker = DevinWorker(text, continue_session=not self.first_message)
        self.worker.finished.connect(self._on_response)
        self.worker.error.connect(self._on_error)
        self.worker.start()
        self.first_message = False

    def _on_response(self, response):
        # Clean up response — strip ANSI codes
        import re
        clean = re.sub(r'\x1b\[[0-9;]*m', '', response)
        # Convert markdown-ish to HTML-ish (basic)
        clean = clean.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        clean = clean.replace('\n', '<br>')

        self._add_bubble(clean, is_user=False)

        self.input_box.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.input_box.setFocus()
        self.status_label.setText("Ready")
        self.status_label.setStyleSheet("color: #64748b; font-size: 11px; padding: 2px;")

    def _on_error(self, error_msg):
        self._add_bubble(f"Error: {error_msg}", is_user=False)

        self.input_box.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.input_box.setFocus()
        self.status_label.setText("Error")
        self.status_label.setStyleSheet("color: #ef4444; font-size: 11px; padding: 2px;")


def QTimer_singleShot(parent, ms, callback):
    """Helper to scroll to bottom after layout updates."""
    from PyQt6.QtCore import QTimer
    QTimer.singleShot(ms, callback)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Devin Chat GUI")

    # Dark palette fallback
    from PyQt6.QtGui import QPalette, QColor
    pal = app.palette()
    pal.setColor(QPalette.ColorRole.Window, QColor("#0f172a"))
    pal.setColor(QPalette.ColorRole.Base, QColor("#0f172a"))
    app.setPalette(pal)

    gui = DevinChatGUI()
    gui.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
