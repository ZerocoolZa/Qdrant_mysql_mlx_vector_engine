#!/usr/bin/env python3
"""
CodeGPS — Visual Garmin interface for the Repair Graph.

A PyQt6 GUI that shows:
  - Left panel: Violation types as "destinations" with status icons
  - Center: Route map showing saved repair routes (success/fail)
  - Right panel: Trip history log
  - Bottom: Selected route details + navigation steps

Like a GPS:
  - Green = resolved destination
  - Red = failed route
  - Yellow = in progress
  - Gray = not started
"""
import os
import sys
import sqlite3
from collections import defaultdict

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QListWidget, QListWidgetItem, QLabel, QTextEdit, QPushButton,
    QSplitter, QFrame, QHeaderView, QTableWidget, QTableWidgetItem,
    QStatusBar
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QBrush, QPolygonF
from PyQt6.QtCore import QPointF


DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")


STYLESHEET = """
QMainWindow {
    background-color: #1a1a2e;
    color: #e0e0e0;
}
QLabel {
    color: #e0e0e0;
    font-size: 13px;
}
QListWidget {
    background-color: #16213e;
    color: #e0e0e0;
    border: 1px solid #0f3460;
    border-radius: 4px;
    font-size: 12px;
}
QListWidget::item:selected {
    background-color: #0f3460;
}
QTextEdit {
    background-color: #16213e;
    color: #a0e0a0;
    border: 1px solid #0f3460;
    border-radius: 4px;
    font-family: 'Menlo', 'Courier New', monospace;
    font-size: 11px;
}
QTableWidget {
    background-color: #16213e;
    color: #e0e0e0;
    border: 1px solid #0f3460;
    border-radius: 4px;
    font-size: 11px;
    gridline-color: #0f3460;
}
QHeaderView::section {
    background-color: #0f3460;
    color: #e0e0e0;
    border: none;
    padding: 4px;
    font-weight: bold;
}
QPushButton {
    background-color: #0f3460;
    color: #e0e0e0;
    border: none;
    padding: 6px 16px;
    border-radius: 4px;
    font-size: 12px;
}
QPushButton:hover {
    background-color: #1a4a7a;
}
QStatusBar {
    background-color: #0f3460;
    color: #a0a0a0;
    font-size: 11px;
}
QFrame#header {
    background-color: #0f3460;
    border: none;
    border-radius: 4px;
}
QLabel#title {
    font-size: 18px;
    font-weight: bold;
    color: #e94560;
    padding: 8px;
}
QLabel#subtitle {
    font-size: 12px;
    color: #a0a0a0;
    padding: 4px 8px;
}
"""


class RouteMapWidget(QWidget):
    """Center widget — draws the repair route map like a GPS screen."""

    def __init__(self):
        super().__init__()
        self.setMinimumSize(400, 300)
        self.routes = []
        self.selected = None

    def set_routes(self, routes):
        self.routes = routes
        self.update()

    def set_selected(self, idx):
        self.selected = idx
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        painter.fillRect(self.rect(), QColor("#16213e"))

        if not self.routes:
            painter.setPen(QColor("#a0a0a0"))
            painter.setFont(QFont("Menlo", 11))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                           "No routes yet\nRun repair_graph.py to populate")
            return

        painter.setPen(QColor("#e94560"))
        painter.setFont(QFont("Menlo", 14, QFont.Weight.Bold))
        painter.drawText(20, 30, "REPAIR ROUTE MAP")

        painter.setFont(QFont("Menlo", 10))
        painter.setPen(QColor("#a0a0a0"))
        painter.drawText(20, 50, f"{len(self.routes)} routes | green=OK red=FAIL")

        y = 80
        row_h = 60
        for i, route in enumerate(self.routes):
            is_selected = (self.selected == i)
            vtype = route.get("violation_type", "?")
            name = route.get("route_name", "?")
            success = route.get("success_count", 0)
            fail = route.get("fail_count", 0)
            conf = route.get("confidence", 0.5)

            if success > 0 and fail == 0:
                color = QColor("#00e676")
                status = "RESOLVED"
            elif fail > 0 and success == 0:
                color = QColor("#ff5252")
                status = "FAILED"
            elif success > 0 and fail > 0:
                color = QColor("#ffd740")
                status = "PARTIAL"
            else:
                color = QColor("#90a4ae")
                status = "UNKNOWN"

            if is_selected:
                painter.fillRect(10, y - 5, w - 20, row_h - 10, QColor("#0f3460"))

            painter.setPen(QPen(color, 3))
            painter.drawEllipse(25, y + 15, 20, 20)

            painter.setPen(color)
            painter.setFont(QFont("Menlo", 9, QFont.Weight.Bold))
            painter.drawText(55, y + 12, status)

            painter.setPen(QColor("#e0e0e0"))
            painter.setFont(QFont("Menlo", 10))
            painter.drawText(55, y + 28, vtype)

            painter.setPen(QColor("#a0a0a0"))
            painter.setFont(QFont("Menlo", 9))
            painter.drawText(55, y + 42, name[:40])

            painter.setPen(color)
            painter.setFont(QFont("Menlo", 9))
            conf_text = f"conf={conf:.1f} OK:{success} FAIL:{fail}"
            painter.drawText(w - 150, y + 28, conf_text)

            if i < len(self.routes) - 1:
                painter.setPen(QPen(QColor("#0f3460"), 2))
                painter.drawLine(35, y + 35, 35, y + row_h - 5)

            y += row_h
            if y > h - 20:
                break

        painter.end()


class CodeGPSWindow(QMainWindow):
    """Main CodeGPS window — the Garmin for code repair."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("CodeGPS — Repair Navigation System")
        self.setMinimumSize(1200, 750)
        self.db_path = DB_PATH

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(4)
        layout.setContentsMargins(4, 4, 4, 4)

        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(50)
        hlayout = QHBoxLayout(header)
        title = QLabel("CodeGPS")
        title.setObjectName("title")
        subtitle = QLabel("Repair Navigation System — your code Garmin")
        subtitle.setObjectName("subtitle")
        hlayout.addWidget(title)
        hlayout.addWidget(subtitle)
        hlayout.addStretch()
        layout.addWidget(header)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        left_widget = self.build_left_panel()
        splitter.addWidget(left_widget)

        self.route_map = RouteMapWidget()
        splitter.addWidget(self.route_map)

        right_widget = self.build_right_panel()
        splitter.addWidget(right_widget)

        splitter.setSizes([300, 450, 350])
        layout.addWidget(splitter, stretch=1)

        bottom = self.build_bottom_panel()
        layout.addWidget(bottom)

        self.statusBar().showMessage("CodeGPS ready — click a violation to navigate")

        self.load_data()

    def build_left_panel(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)

        label = QLabel("DESTINATIONS (Violation Types)")
        label.setStyleSheet("font-weight: bold; color: #e94560; padding: 4px;")
        layout.addWidget(label)

        self.violation_list = QListWidget()
        self.violation_list.itemClicked.connect(self.on_violation_selected)
        layout.addWidget(self.violation_list)

        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_data)
        btn_layout.addWidget(refresh_btn)

        stats_btn = QPushButton("Stats")
        stats_btn.clicked.connect(self.show_stats)
        btn_layout.addWidget(stats_btn)

        layout.addLayout(btn_layout)
        return widget

    def build_right_panel(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)

        label = QLabel("TRIP HISTORY (Repair Log)")
        label.setStyleSheet("font-weight: bold; color: #e94560; padding: 4px;")
        layout.addWidget(label)

        self.history_table = QTableWidget(0, 5)
        self.history_table.setHorizontalHeaderLabels(
            ["Time", "Type", "Action", "Result", "Tool"]
        )
        header = self.history_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.history_table)

        detail_label = QLabel("ROUTE DETAILS")
        detail_label.setStyleSheet("font-weight: bold; color: #e94560; padding: 4px;")
        layout.addWidget(detail_label)

        self.detail_text = QTextEdit()
        self.detail_text.setReadOnly(True)
        self.detail_text.setMaximumHeight(180)
        layout.addWidget(self.detail_text)

        return widget

    def build_bottom_panel(self):
        widget = QWidget()
        widget.setFixedHeight(120)
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)

        plan_label = QLabel("PLAN CHANGES")
        plan_label.setStyleSheet("font-weight: bold; color: #e94560; padding: 4px;")
        layout.addWidget(plan_label)

        self.plan_table = QTableWidget(0, 6)
        self.plan_table.setHorizontalHeaderLabels(
            ["ID", "Order", "Type", "Risk", "Description", "Fix"]
        )
        header = self.plan_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.plan_table, stretch=1)

        return widget

    def get_conn(self):
        return sqlite3.connect(self.db_path)

    def load_data(self):
        self.load_violations()
        self.load_routes()
        self.load_history()
        self.load_plan()

    def load_violations(self):
        self.violation_list.clear()
        try:
            conn = self.get_conn()
            cur = conn.cursor()
            cur.execute("""
                SELECT violation_type, COUNT(*) as cnt, severity
                FROM violations
                GROUP BY violation_type, severity
                ORDER BY cnt DESC
            """)
            rows = cur.fetchall()
            conn.close()

            icons = {
                "error": ("XX", "#ff5252"),
                "warning": ("!!", "#ffd740"),
            }

            for vtype, cnt, sev in rows:
                icon_text, color = icons.get(sev, ("??", "#90a4ae"))
                item = QListWidgetItem(f"  [{icon_text}]  {vtype}  ({cnt})")
                item.setData(Qt.ItemDataRole.UserRole, vtype)
                item.setForeground(QColor(color))
                self.violation_list.addItem(item)

        except Exception as e:
            self.statusBar().showMessage(f"Error loading violations: {e}")

    def load_routes(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()
            cur.execute("""
                SELECT violation_type, route_name, success_count, fail_count, confidence
                FROM repair_routes ORDER BY success_count DESC, confidence DESC
            """)
            rows = cur.fetchall()
            conn.close()

            routes = []
            for vtype, name, success, fail, conf in rows:
                routes.append({
                    "violation_type": vtype,
                    "route_name": name,
                    "success_count": success,
                    "fail_count": fail,
                    "confidence": conf,
                })

            self.route_map.set_routes(routes)

        except Exception as e:
            self.statusBar().showMessage(f"Error loading routes: {e}")

    def load_history(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()
            cur.execute("""
                SELECT created_at, violation_type, action, result, tool, note
                FROM repair_log ORDER BY created_at DESC LIMIT 50
            """)
            rows = cur.fetchall()
            conn.close()

            self.history_table.setRowCount(len(rows))
            for i, (ts, vtype, action, result, tool, note) in enumerate(rows):
                self.history_table.setItem(i, 0, QTableWidgetItem(ts or ""))
                self.history_table.setItem(i, 1, QTableWidgetItem(vtype or ""))
                self.history_table.setItem(i, 2, QTableWidgetItem(action or ""))
                self.history_table.setItem(i, 3, QTableWidgetItem(result or ""))
                self.history_table.setItem(i, 4, QTableWidgetItem(tool or ""))

                if result == "resolved":
                    self.history_table.item(i, 3).setForeground(QColor("#00e676"))
                elif result == "failed":
                    self.history_table.item(i, 3).setForeground(QColor("#ff5252"))
                elif result == "reverted":
                    self.history_table.item(i, 3).setForeground(QColor("#ffd740"))

        except Exception as e:
            self.statusBar().showMessage(f"Error loading history: {e}")

    def load_plan(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()
            cur.execute("""
                SELECT change_id, execution_order, violation_type, risk,
                       change_description, estimated_fix
                FROM plan_changes ORDER BY execution_order
            """)
            rows = cur.fetchall()
            conn.close()

            self.plan_table.setRowCount(len(rows))
            for i, (cid, order, vtype, risk, desc, fix) in enumerate(rows):
                self.plan_table.setItem(i, 0, QTableWidgetItem(cid or ""))
                self.plan_table.setItem(i, 1, QTableWidgetItem(str(order)))
                self.plan_table.setItem(i, 2, QTableWidgetItem(vtype or ""))
                self.plan_table.setItem(i, 3, QTableWidgetItem(risk or ""))
                self.plan_table.setItem(i, 4, QTableWidgetItem(desc or ""))
                self.plan_table.setItem(i, 5, QTableWidgetItem(fix or ""))

                risk_colors = {"low": "#00e676", "medium": "#ffd740", "high": "#ff5252"}
                if risk in risk_colors:
                    self.plan_table.item(i, 3).setForeground(QColor(risk_colors[risk]))

        except Exception as e:
            self.statusBar().showMessage(f"Error loading plan: {e}")

    def on_violation_selected(self, item):
        vtype = item.data(Qt.ItemDataRole.UserRole)
        if not vtype:
            return

        self.statusBar().showMessage(f"Navigating: {vtype}")

        try:
            conn = self.get_conn()
            cur = conn.cursor()

            cur.execute("""
                SELECT route_name, success_count, fail_count, confidence, steps
                FROM repair_routes WHERE violation_type = ?
                ORDER BY success_count DESC
            """, (vtype,))
            routes = cur.fetchall()

            cur.execute("""
                SELECT action, result, tool, note, created_at
                FROM repair_log WHERE violation_type = ?
                ORDER BY created_at DESC LIMIT 20
            """, (vtype,))
            history = cur.fetchall()

            cur.execute("""
                SELECT change_id, execution_order, risk, change_description,
                       impact, estimated_fix, dependencies
                FROM plan_changes WHERE violation_type = ?
                ORDER BY execution_order
            """, (vtype,))
            plans = cur.fetchall()

            conn.close()

            lines = []
            lines.append(f"NAVIGATE: {vtype}")
            lines.append("=" * 50)

            if routes:
                lines.append(f"\nSAVED ROUTES ({len(routes)}):")
                for name, success, fail, conf, steps in routes:
                    status = "OK" if success > 0 and fail == 0 else "FAIL" if fail > 0 and success == 0 else "PARTIAL"
                    lines.append(f"  [{status}] {name}")
                    lines.append(f"        OK:{success}  FAIL:{fail}  conf={conf:.1f}")
            else:
                lines.append("\n  No saved routes yet.")

            if history:
                lines.append(f"\nTRIP HISTORY ({len(history)}):")
                for action, result, tool, note, ts in history:
                    lines.append(f"  {ts}  {action} -> {result} [{tool}]")
                    if note:
                        lines.append(f"    note: {note}")
            else:
                lines.append("\n  No history yet.")

            if plans:
                lines.append(f"\nPLAN CHANGES ({len(plans)}):")
                for cid, order, risk, desc, impact, fix, deps in plans:
                    lines.append(f"  {cid}  order={order}  risk={risk}")
                    lines.append(f"    {desc}")
                    lines.append(f"    impact: {impact}")
                    lines.append(f"    fix: {fix}")
                    lines.append(f"    deps: {deps}")
            else:
                lines.append("\n  No plan changes for this type.")

            self.detail_text.setPlainText("\n".join(lines))

            for i, route in enumerate(self.route_map.routes):
                if route.get("violation_type") == vtype:
                    self.route_map.set_selected(i)
                    break

        except Exception as e:
            self.detail_text.setPlainText(f"Error: {e}")

    def show_stats(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()

            cur.execute("SELECT COUNT(*) FROM repair_nodes")
            nodes = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM repair_routes")
            routes = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM repair_log")
            log = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM violations")
            violations = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM plan_changes")
            plans = cur.fetchone()[0]

            cur.execute("""
                SELECT violation_type, COUNT(*) FROM violations
                GROUP BY violation_type ORDER BY COUNT(*) DESC
            """)
            by_type = cur.fetchall()

            cur.execute("""
                SELECT violation_type, route_name, success_count, fail_count, confidence
                FROM repair_routes ORDER BY success_count DESC
            """)
            route_rows = cur.fetchall()

            conn.close()

            lines = []
            lines.append("CODEGPS DASHBOARD")
            lines.append("=" * 50)
            lines.append(f"  Violations:  {violations}")
            lines.append(f"  Plan changes: {plans}")
            lines.append(f"  Repair nodes: {nodes}")
            lines.append(f"  Saved routes: {routes}")
            lines.append(f"  Log entries:  {log}")
            lines.append("")
            lines.append("VIOLATIONS BY TYPE:")
            for vtype, cnt in by_type:
                lines.append(f"  {vtype:25s}: {cnt}")
            lines.append("")
            lines.append("SAVED ROUTES:")
            for vtype, name, success, fail, conf in route_rows:
                status = "OK" if success > 0 and fail == 0 else "FAIL" if fail > 0 else "?"
                lines.append(f"  [{status}] {vtype:25s} -> {name:30s}  conf={conf:.1f}")

            self.detail_text.setPlainText("\n".join(lines))
            self.statusBar().showMessage("Stats displayed in detail panel")

        except Exception as e:
            self.statusBar().showMessage(f"Error: {e}")


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLESHEET)
    window = CodeGPSWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
