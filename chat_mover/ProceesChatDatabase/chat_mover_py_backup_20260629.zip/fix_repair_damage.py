#!/usr/bin/env python3
"""Fix the broken self.state["X"]YYYY pattern left by RuleEnforcer regex bug.
Reverts to self._XYYYY (original form), then we'll do a proper replacement later.
"""
import re
import subprocess

files_to_fix = [
    "Config.py",
    "CascadeIngester.py",
    "MySQLIngester.py",
    "ChatExportTracker.py",
    "validate.py",
]

for fname in files_to_fix:
    try:
        with open(fname, "r") as f:
            content = f.read()
    except FileNotFoundError:
        continue

    # The bug: self.state["d"]b_path should be self._db_path
    # Pattern: self.state["X"]YYYY -> self._XYYYY
    fixed = re.sub(
        r'self\.state\["([a-z])"\]([a-z_]+)',
        lambda m: "self._" + m.group(1) + m.group(2),
        content
    )

    if fixed != content:
        with open(fname, "w") as f:
            f.write(fixed)
        print(f"  {fname}: reverted broken self.state replacements")
    else:
        print(f"  {fname}: no broken patterns found")

# Verify compilation
print("\nCompilation check:")
for fname in files_to_fix:
    result = subprocess.run(
        ["python3", "-m", "py_compile", fname],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"  {fname}: OK")
    else:
        print(f"  {fname}: FAIL - {result.stderr.strip()}")
