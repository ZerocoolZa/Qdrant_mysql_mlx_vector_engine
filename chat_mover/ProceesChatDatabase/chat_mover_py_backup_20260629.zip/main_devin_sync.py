#!/usr/bin/env python3

"""
#[@GHOST]{("file_path=/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/main_devin_sync.py";"identity=main_devin_sync";"purpose=CLI entry point for Devin session sync lifecycle: close Devin, sync SQLite to MySQL, report status";"date=2026-06-29";"version=1.0";"author=Devin";"chat_link=")}
#[@VBSTYLE]{("auth=Devin";"role=domain_entry_point";"return=none";"orch=none";"no=no_decorators|no_tabs|no_self_underscore";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("none")}
#[@METHODS]{("main")}
#[@DOMAIN]{("entry_point")}
"""

import argparse
import sys

from Config_devin_sync import DevinSyncConfig
from DevinProcessManager import DevinProcessManager
from DevinSessionSync import DevinSessionSync


def main():
    parser = argparse.ArgumentParser(description="Devin Session Sync — close Devin, sync sessions.db to MySQL.")
    parser.add_argument("--dry-run", action="store_true", help="Parse and connect, do not write to MySQL")
    parser.add_argument("--status", action="store_true", help="Show MySQL devin DB counts and exit")
    parser.add_argument("--find-devin", action="store_true", help="List running Devin processes and exit")
    parser.add_argument("--close-devin", action="store_true", help="Close running Devin processes before sync")
    parser.add_argument("--force", action="store_true", help="Required with --close-devin to actually kill processes")
    args = parser.parse_args()

    if args.find_devin:
        pm = DevinProcessManager()
        ok, data, err = pm.Run("find", {})
        if not ok:
            print(f"ERROR: {err}")
            sys.exit(1)
        print(f"Found {data['count']} Devin process(es):")
        for p in data["found"]:
            print(f"  pid={p['pid']} cmd={p['cmdline'][:120]}")
        sys.exit(0)

    if args.status:
        sync = DevinSessionSync()
        ok, data, err = sync.Run("status", {})
        if not ok:
            print(f"ERROR: {err}")
            sys.exit(1)
        print(f"Status for database: {data['database']}")
        for table, count in data["counts"].items():
            print(f"  {table}: {count}")
        print(f"  user_messages: {data['user_messages']}")
        print(f"  assistant_messages: {data['assistant_messages']}")
        print(f"  tool_messages: {data['tool_messages']}")
        sys.exit(0)

    if args.close_devin:
        pm = DevinProcessManager()
        ok, data, err = pm.Run("close", {"force": args.force, "dry_run": args.dry_run})
        if not ok:
            print(f"ERROR: {err}")
            sys.exit(1)
        print(f"Close result: closed={len(data['closed'])}, skipped={len(data['skipped'])}")
        for p in data["closed"]:
            print(f"  CLOSED pid={p['pid']} signal={p['signal']}")
        for p in data["skipped"]:
            print(f"  SKIPPED pid={p['pid']} reason={p['reason']}")
        if not args.force and not args.dry_run:
            print("Use --force to actually terminate processes.")
            sys.exit(0)

    sync = DevinSessionSync()
    ok, data, err = sync.Run("sync", {"dry_run": args.dry_run})
    if not ok:
        print(f"SYNC ERROR: {err}")
        sys.exit(1)

    print(f"Sync complete (dry_run={args.dry_run}):")
    for name, result in data.items():
        if isinstance(result, dict):
            inserted = result.get("inserted", 0)
            total = result.get("total", result.get("total_sessions", 0))
            error = result.get("error")
            print(f"  {name}: inserted={inserted}, total={total}, error={error}")
        else:
            print(f"  {name}: {result}")


if __name__ == "__main__":
    main()
