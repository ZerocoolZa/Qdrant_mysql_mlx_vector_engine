#!/usr/bin/env python3
"""
CodeGPS Map — Visual Garmin for code repair.

A Tkinter canvas-based map with switchable views:
  1. REPAIR MAP  — violations as destinations, routes as roads, results as colors
  2. PLAN MAP    — planned changes as a journey with execution order
  3. ERROR MAP   — where errors cluster by file and type

Like a Garmin GPS:
  - Green roads = known good routes (successful fixes)
  - Red roads = failed routes (don't go there)
  - Yellow roads = partial / unknown
  - Red destinations = errors (must fix)
  - Yellow destinations = warnings (should fix)
  - Green destinations = resolved (done)

Click a node to see details. Switch tabs to switch maps.
Export to SVG via the Wizard Engine.
"""
import tkinter as tk
from tkinter import ttk
import sqlite3
import os
import math
import json
import subprocess
from datetime import datetime
from collections import defaultdict

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
ENGINE_BIN = "/Users/wws/Qdrant_mysql_mlx_vector_engine/svg_engine/c/wizard_engine"
SVG_OUTPUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "codegps_svg")

# Colors (matching Dom_Graph_Gui.py theme)
BG = "#0d1117"
PANEL = "#161b22"
CARD = "#21262d"
TEXT = "#e6edf3"
ACCENT = "#f85149"
GREEN = "#3fb950"
YELLOW = "#d29922"
RED = "#f85149"
BLUE = "#58a6ff"
PURPLE = "#bc8cff"
ORANGE = "#db6d28"
GRAY = "#484f58"
DARK = "#010409"
WHITE = "#ffffff"


class CodeGPSMap:
    def __init__(self, root):
        self.root = root
        self.root.title("CodeGPS — Repair Navigation Map")
        self.root.geometry("1400x900")
        self.root.configure(bg=BG)

        self.db_path = DB_PATH
        self.nodes = {}
        self.edges = []
        self.selected_node = None
        self.hover_node = None

        self.build_header()
        self.build_tabs()
        self.build_status()
        self.load_data()
        self.draw_all()

    def build_header(self):
        header = tk.Frame(self.root, bg=DARK, height=45)
        header.pack(fill="x", padx=5, pady=3)

        tk.Label(header, text="CodeGPS", font=("Courier", 18, "bold"),
                 fg=ACCENT, bg=DARK).pack(side="left", padx=10)
        tk.Label(header, text="Repair Navigation Map — your code Garmin",
                 font=("Courier", 11), fg=TEXT, bg=DARK).pack(side="left", padx=15)
        tk.Label(header, text=datetime.now().strftime("%Y-%m-%d %H:%M"),
                 font=("Courier", 9), fg=GRAY, bg=DARK).pack(side="right", padx=10)

        btn_frame = tk.Frame(header, bg=DARK)
        btn_frame.pack(side="right", padx=10)
        tk.Button(btn_frame, text="Refresh", command=self.refresh,
                  font=("Courier", 9), bg=CARD, fg=TEXT, relief="flat",
                  padx=10).pack(side="left", padx=2)
        tk.Button(btn_frame, text="Export SVG", command=self.export_svg,
                  font=("Courier", 9), bg=CARD, fg=TEXT, relief="flat",
                  padx=10).pack(side="left", padx=2)

    def build_tabs(self):
        style = ttk.Style()
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=TEXT,
                        padding=[15, 8], font=("Courier", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", CARD)],
                  foreground=[("selected", ACCENT)])

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=5, pady=3)

        # Tab 1: Repair Map
        self.repair_tab = tk.Frame(notebook, bg=BG)
        notebook.add(self.repair_tab, text="  1. REPAIR MAP  ")
        self.build_repair_tab()

        # Tab 2: Plan Map
        self.plan_tab = tk.Frame(notebook, bg=BG)
        notebook.add(self.plan_tab, text="  2. PLAN MAP  ")
        self.build_plan_tab()

        # Tab 3: Error Map
        self.error_tab = tk.Frame(notebook, bg=BG)
        notebook.add(self.error_tab, text="  3. ERROR MAP  ")
        self.build_error_tab()

        # Tab 4: Trip History
        self.history_tab = tk.Frame(notebook, bg=BG)
        notebook.add(self.history_tab, text="  4. TRIP HISTORY  ")
        self.build_history_tab()

        self.notebook = notebook

    def build_repair_tab(self):
        frame = tk.Frame(self.repair_tab, bg=BG)
        frame.pack(fill="both", expand=True)

        canvas = tk.Canvas(frame, bg=BG, highlightthickness=0)
        scroll_y = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scroll_x = ttk.Scrollbar(frame, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.pack(side="right", fill="y")
        scroll_x.pack(side="bottom", fill="x")
        canvas.pack(side="left", fill="both", expand=True)

        self.repair_canvas = canvas
        canvas.bind("<Button-1>", self.on_repair_click)
        canvas.bind("<Motion>", self.on_repair_motion)
        canvas.bind("<Configure>", lambda e: self.draw_repair_map())

        # Detail panel
        detail = tk.Frame(self.repair_tab, bg=PANEL, height=150)
        detail.pack(fill="x", padx=5, pady=3)
        self.repair_detail = tk.Text(detail, bg=PANEL, fg=TEXT, font=("Courier", 10),
                                     wrap="word", relief="flat", height=8)
        self.repair_detail.pack(fill="both", expand=True, padx=5, pady=5)

    def build_plan_tab(self):
        frame = tk.Frame(self.plan_tab, bg=BG)
        frame.pack(fill="both", expand=True)

        canvas = tk.Canvas(frame, bg=BG, highlightthickness=0)
        scroll_y = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scroll_x = ttk.Scrollbar(frame, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.pack(side="right", fill="y")
        scroll_x.pack(side="bottom", fill="x")
        canvas.pack(side="left", fill="both", expand=True)

        self.plan_canvas = canvas
        canvas.bind("<Configure>", lambda e: self.draw_plan_map())

        detail = tk.Frame(self.plan_tab, bg=PANEL, height=150)
        detail.pack(fill="x", padx=5, pady=3)
        self.plan_detail = tk.Text(detail, bg=PANEL, fg=TEXT, font=("Courier", 10),
                                   wrap="word", relief="flat", height=8)
        self.plan_detail.pack(fill="both", expand=True, padx=5, pady=5)

    def build_error_tab(self):
        frame = tk.Frame(self.error_tab, bg=BG)
        frame.pack(fill="both", expand=True)

        canvas = tk.Canvas(frame, bg=BG, highlightthickness=0)
        scroll_y = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scroll_x = ttk.Scrollbar(frame, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.pack(side="right", fill="y")
        scroll_x.pack(side="bottom", fill="x")
        canvas.pack(side="left", fill="both", expand=True)

        self.error_canvas = canvas
        canvas.bind("<Configure>", lambda e: self.draw_error_map())

    def build_history_tab(self):
        frame = tk.Frame(self.history_tab, bg=BG)
        frame.pack(fill="both", expand=True)

        cols = ("Time", "Type", "Action", "Result", "Tool", "Note")
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=20)
        for col in cols:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        tree.column("Action", width=200)
        tree.column("Note", width=300)
        tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.history_tree = tree

    def build_status(self):
        self.status = tk.Label(self.root, text="CodeGPS ready", font=("Courier", 9),
                               fg=GRAY, bg=DARK, anchor="w")
        self.status.pack(fill="x", padx=5, pady=2)

    def get_conn(self):
        return sqlite3.connect(self.db_path)

    def load_data(self):
        try:
            conn = self.get_conn()
            cur = conn.cursor()

            # Violations grouped by type
            cur.execute("""
                SELECT violation_type, severity, COUNT(*) as cnt
                FROM violations GROUP BY violation_type, severity ORDER BY cnt DESC
            """)
            self.violations = cur.fetchall()

            # Repair routes
            cur.execute("""
                SELECT violation_type, route_name, success_count, fail_count, confidence
                FROM repair_routes ORDER BY success_count DESC
            """)
            self.routes = cur.fetchall()

            # Repair log
            cur.execute("""
                SELECT created_at, violation_type, action, result, tool, note
                FROM repair_log ORDER BY created_at DESC
            """)
            self.log_entries = cur.fetchall()

            # Plan changes
            cur.execute("""
                SELECT change_id, execution_order, violation_type, risk,
                       change_description, impact, estimated_fix, dependencies
                FROM plan_changes ORDER BY execution_order
            """)
            self.plans = cur.fetchall()

            # Violations by file
            cur.execute("""
                SELECT file_path, violation_type, severity, COUNT(*) as cnt
                FROM violations GROUP BY file_path, violation_type ORDER BY file_path
            """)
            self.violations_by_file = cur.fetchall()

            conn.close()
            self.status.config(text=f"Loaded: {len(self.violations)} violation types, "
                                    f"{len(self.routes)} routes, {len(self.plans)} plan changes")
        except Exception as e:
            self.status.config(text=f"Error loading data: {e}")
            self.violations = []
            self.routes = []
            self.log_entries = []
            self.plans = []
            self.violations_by_file = []

    def draw_all(self):
        self.draw_repair_map()
        self.draw_plan_map()
        self.draw_error_map()
        self.draw_history()

    def refresh(self):
        self.load_data()
        self.draw_all()
        self.status.config(text="Refreshed")

    # ═══════════════════════════════════════════════════════════════
    # REPAIR MAP — the main GPS view
    # ═══════════════════════════════════════════════════════════════
    def draw_repair_map(self):
        c = self.repair_canvas
        c.delete("all")

        w = c.winfo_width()
        h = c.winfo_height()
        if w < 100:
            w = 1300
        if h < 100:
            h = 700

        # Title
        c.create_text(w // 2, 25, text="REPAIR MAP", font=("Courier", 20, "bold"), fill=ACCENT)
        c.create_text(w // 2, 48, text="Destinations = violations  |  Roads = fix routes  |  Green=OK  Red=FAIL  Yellow=partial",
                      font=("Courier", 10), fill=GRAY)

        if not self.violations:
            c.create_text(w // 2, h // 2, text="No violations found", font=("Courier", 14), fill=GRAY)
            return

        # Layout: START on left, destinations in center, results on right
        start_x = 80
        center_x = w // 2
        end_x = w - 120

        # Draw START node (where you are now)
        self.draw_gps_node(c, start_x, h // 2, "YOU\nARE\nHERE", BLUE, 40, "start")

        # Draw destination nodes (violation types)
        n = len(self.violations)
        spacing = min(100, (h - 120) // max(n, 1))

        route_map = {r[0]: r for r in self.routes}

        for i, (vtype, sev, cnt) in enumerate(self.violations):
            y = 90 + i * spacing

            # Color by severity
            if sev == "error":
                dest_color = RED
            else:
                dest_color = YELLOW

            # Check if there's a known route
            route = route_map.get(vtype)
            if route:
                _, name, success, fail, conf = route
                if success > 0 and fail == 0:
                    road_color = GREEN
                    result_text = "RESOLVED"
                    result_color = GREEN
                elif fail > 0 and success == 0:
                    road_color = RED
                    result_text = "FAILED"
                    result_color = RED
                elif success > 0 and fail > 0:
                    road_color = YELLOW
                    result_text = "PARTIAL"
                    result_color = YELLOW
                else:
                    road_color = GRAY
                    result_text = "UNKNOWN"
                    result_color = GRAY
            else:
                road_color = GRAY
                result_text = "NO ROUTE"
                result_color = GRAY
                name = ""
                conf = 0

            # Draw road from START to destination
            self.draw_road(c, start_x + 40, h // 2, center_x - 50, y, road_color, dashed=(road_color == GRAY))

            # Draw destination node
            label = f"{vtype}\n({cnt})"
            node_id = f"dest_{i}"
            self.draw_gps_node(c, center_x, y, label, dest_color, 35, node_id)
            self.nodes[node_id] = {
                "type": "violation",
                "vtype": vtype,
                "severity": sev,
                "count": cnt,
                "route": name,
                "result": result_text,
                "confidence": conf,
            }

            # Draw road from destination to result
            self.draw_road(c, center_x + 50, y, end_x - 40, y, road_color, dashed=(road_color == GRAY))

            # Draw result node
            self.draw_gps_node(c, end_x, y, result_text, result_color, 30, f"result_{i}")

            # Route label on the road
            if name:
                mid_x = (center_x + end_x) // 2
                c.create_text(mid_x, y - 12, text=name[:30], font=("Courier", 8), fill=road_color)
                c.create_text(mid_x, y + 10, text=f"conf={conf:.1f}", font=("Courier", 7), fill=GRAY)

        # Legend
        self.draw_legend(c, 20, h - 80)

    def draw_gps_node(self, canvas, x, y, text, color, radius, node_id=""):
        canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                          outline=color, width=2, fill=DARK, tags=node_id)
        lines = text.split("\n")
        for i, line in enumerate(lines):
            ly = y - (len(lines) - 1) * 7 + i * 14
            canvas.create_text(x, ly, text=line, font=("Courier", 8, "bold"),
                              fill=color, tags=node_id)

    def draw_road(self, canvas, x1, y1, x2, y2, color, dashed=False):
        if dashed:
            canvas.create_line(x1, y1, x2, y2, fill=color, width=1, dash=(4, 4))
        else:
            canvas.create_line(x1, y1, x2, y2, fill=color, width=2)

        # Arrow head
        angle = math.atan2(y2 - y1, x2 - x1)
        ax = x2 - 8 * math.cos(angle)
        ay = y2 - 8 * math.sin(angle)
        canvas.create_polygon(
            x2, y2,
            ax - 4 * math.cos(angle + math.pi / 2), ay - 4 * math.sin(angle + math.pi / 2),
            ax + 4 * math.cos(angle + math.pi / 2), ay + 4 * math.sin(angle + math.pi / 2),
            fill=color, outline=color
        )

    def draw_legend(self, canvas, x, y):
        canvas.create_rectangle(x, y, x + 280, y + 65, outline=GRAY, fill=DARK)
        canvas.create_text(x + 10, y + 12, text="LEGEND", font=("Courier", 9, "bold"), fill=TEXT)
        items = [
            (GREEN, "Green road = known good route"),
            (RED, "Red road = failed route (avoid)"),
            (YELLOW, "Yellow road = partial / unknown"),
            (GRAY, "Dashed = no route yet found"),
        ]
        for i, (color, label) in enumerate(items):
            ly = y + 25 + i * 10
            canvas.create_line(x + 10, ly, x + 30, ly, fill=color, width=2)
            canvas.create_text(x + 35, ly, text=label, font=("Courier", 8), fill=TEXT, anchor="w")

    def on_repair_click(self, event):
        c = self.repair_canvas
        items = c.find_overlapping(event.x - 5, event.y - 5, event.x + 5, event.y + 5)
        for item in items:
            tags = c.gettags(item)
            for tag in tags:
                if tag in self.nodes:
                    info = self.nodes[tag]
                    self.show_node_detail(info)
                    return

    def on_repair_motion(self, event):
        c = self.repair_canvas
        items = c.find_overlapping(event.x - 5, event.y - 5, event.x + 5, event.y + 5)
        found = None
        for item in items:
            tags = c.gettags(item)
            for tag in tags:
                if tag in self.nodes:
                    found = tag
                    break
        if found != self.hover_node:
            self.hover_node = found
            if found:
                info = self.nodes[found]
                self.status.config(text=f"Node: {info.get('vtype', '?')} — {info.get('result', '?')}")
            else:
                self.status.config(text="CodeGPS ready")

    def show_node_detail(self, info):
        lines = []
        lines.append(f"DESTINATION: {info.get('vtype', '?')}")
        lines.append(f"  Severity:  {info.get('severity', '?')}")
        lines.append(f"  Count:     {info.get('count', '?')}")
        lines.append(f"  Route:     {info.get('route', 'none')}")
        lines.append(f"  Result:    {info.get('result', '?')}")
        lines.append(f"  Confidence: {info.get('confidence', 0):.1f}")
        self.repair_detail.delete("1.0", tk.END)
        self.repair_detail.insert("1.0", "\n".join(lines))

    # ═══════════════════════════════════════════════════════════════
    # PLAN MAP — execution order as a journey
    # ═══════════════════════════════════════════════════════════════
    def draw_plan_map(self):
        c = self.plan_canvas
        c.delete("all")

        w = c.winfo_width()
        h = c.plan_canvas.winfo_height() if hasattr(c, 'plan_canvas') else c.winfo_height()
        if w < 100:
            w = 1300
        if h < 100:
            h = 700

        c.create_text(w // 2, 25, text="PLAN MAP", font=("Courier", 20, "bold"), fill=ACCENT)
        c.create_text(w // 2, 48, text="Execution journey — follow the road from start to finish",
                      font=("Courier", 10), fill=GRAY)

        if not self.plans:
            c.create_text(w // 2, h // 2, text="No plan changes found", font=("Courier", 14), fill=GRAY)
            return

        risk_colors = {"low": GREEN, "medium": YELLOW, "high": RED}

        # Draw as a winding road from left to right
        n = len(self.plans)
        margin = 100
        road_w = w - 2 * margin
        step = road_w // max(n, 1)

        # Draw the main road
        c.create_line(margin, h // 2, margin + road_w, h // 2, fill=GRAY, width=3, dash=(3, 3))

        for i, (cid, order, vtype, risk, desc, impact, fix, deps) in enumerate(self.plans):
            x = margin + i * step + step // 2
            y = h // 2

            color = risk_colors.get(risk, GRAY)

            # Alternate above and below the road
            offset = 80 if i % 2 == 0 else -80
            node_y = y + offset

            # Connector
            c.create_line(x, y, x, node_y, fill=color, width=2)

            # Node
            self.draw_gps_node(c, x, node_y, f"{cid}\n{vtype[:12]}", color, 30, f"plan_{i}")

            # Description
            desc_y = node_y + (50 if offset > 0 else -50)
            short_desc = desc[:50] if desc else ""
            c.create_text(x, desc_y, text=short_desc, font=("Courier", 8), fill=TEXT,
                         anchor="n" if offset > 0 else "s", width=200)

            # Risk label
            risk_y = node_y + (offset > 0 and -35 or 35)
            c.create_text(x, risk_y, text=f"[{risk.upper()}]", font=("Courier", 8, "bold"),
                         fill=color, anchor="s" if offset > 0 else "n")

            # Fix hint
            if fix:
                fix_short = fix[:60]
                fix_y = desc_y + (15 if offset > 0 else -15)
                c.create_text(x, fix_y, text=fix_short, font=("Courier", 7), fill=GRAY,
                             anchor="n" if offset > 0 else "s", width=200)

        # Start and End markers
        self.draw_gps_node(c, margin - 20, h // 2, "START", BLUE, 25)
        self.draw_gps_node(c, margin + road_w + 20, h // 2, "DONE", GREEN, 25)

    # ═══════════════════════════════════════════════════════════════
    # ERROR MAP — violations clustered by file
    # ═══════════════════════════════════════════════════════════════
    def draw_error_map(self):
        c = self.error_canvas
        c.delete("all")

        w = c.winfo_width()
        h = c.winfo_height()
        if w < 100:
            w = 1300
        if h < 100:
            h = 700

        c.create_text(w // 2, 25, text="ERROR MAP", font=("Courier", 20, "bold"), fill=ACCENT)
        c.create_text(w // 2, 48, text="Where errors cluster by file — red=error, yellow=warning",
                      font=("Courier", 10), fill=GRAY)

        if not self.violations_by_file:
            c.create_text(w // 2, h // 2, text="No violations by file", font=("Courier", 14), fill=GRAY)
            return

        # Group by file
        file_groups = defaultdict(list)
        for fpath, vtype, sev, cnt in self.violations_by_file:
            fname = os.path.basename(fpath) if fpath else "unknown"
            file_groups[fname].append((vtype, sev, cnt))

        files = sorted(file_groups.keys())
        n = len(files)
        cols = min(4, max(1, n))
        rows = math.ceil(n / cols)

        card_w = min(300, (w - 60) // cols)
        card_h = 120
        margin_x = (w - cols * card_w) // (cols + 1)
        margin_y = 80

        for i, fname in enumerate(files):
            col = i % cols
            row = i // cols
            x = margin_x + col * (card_w + margin_x)
            y = margin_y + row * (card_h + 20)

            entries = file_groups[fname]
            total = sum(cnt for _, _, cnt in entries)
            has_error = any(sev == "error" for _, sev, _ in entries)
            border_color = RED if has_error else YELLOW

            # Card
            c.create_rectangle(x, y, x + card_w, y + card_h, outline=border_color, width=2, fill=DARK)

            # File name
            c.create_text(x + card_w // 2, y + 15, text=fname[:30], font=("Courier", 10, "bold"),
                         fill=TEXT)

            # Violation count
            c.create_text(x + card_w // 2, y + 32, text=f"{total} violations", font=("Courier", 9),
                         fill=border_color)

            # List violations
            for j, (vtype, sev, cnt) in enumerate(entries[:5]):
                vy = y + 50 + j * 14
                dot_color = RED if sev == "error" else YELLOW
                c.create_oval(x + 10, vy - 3, x + 16, vy + 3, fill=dot_color, outline=dot_color)
                c.create_text(x + 22, vy, text=f"{vtype} ({cnt})", font=("Courier", 8),
                             fill=TEXT, anchor="w")

            if len(entries) > 5:
                c.create_text(x + card_w // 2, y + card_h - 10,
                             text=f"+{len(entries) - 5} more", font=("Courier", 7), fill=GRAY)

    # ═══════════════════════════════════════════════════════════════
    # TRIP HISTORY
    # ═══════════════════════════════════════════════════════════════
    def draw_history(self):
        tree = self.history_tree
        tree.delete(*tree.get_children())

        for ts, vtype, action, result, tool, note in self.log_entries:
            tree.insert("", "end", values=(ts or "", vtype or "", action or "",
                                           result or "", tool or "", note or ""))

    # ═══════════════════════════════════════════════════════════════
    # SVG EXPORT via Wizard Engine
    # ═══════════════════════════════════════════════════════════════
    def export_svg(self):
        os.makedirs(SVG_OUTPUT, exist_ok=True)

        scene = self.build_repair_scene_json()
        scene_path = os.path.join(SVG_OUTPUT, "repair_map.json")
        svg_path = os.path.join(SVG_OUTPUT, "repair_map.svg")

        with open(scene_path, "w") as f:
            json.dump(scene, f, indent=2)

        try:
            result = subprocess.run(
                [ENGINE_BIN, scene_path, svg_path],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                self.status.config(text=f"SVG exported: {svg_path}")
            else:
                self.status.config(text=f"SVG export failed: {result.stderr[:100]}")
        except Exception as e:
            self.status.config(text=f"SVG export error: {e}")

    def build_repair_scene_json(self):
        width = 1200
        height = 900
        objects = []

        # Start node
        objects.append({
            "id": "start",
            "type": "mcp_node",
            "position": [80, height // 2],
            "rotation": 0, "scale": 1.2, "opacity": 1.0,
            "color": "#58a6ff", "stroke_color": "#58a6ff", "stroke_width": 2,
            "node_label": "START", "node_status": 1, "text": "",
            "motion": {"type": "glow", "speed": 0.3, "amplitude": 0, "radius": 0, "phase": 0,
                       "center": [80, height // 2], "seed": 42}
        })

        route_map = {r[0]: r for r in self.routes}
        n = len(self.violations)
        spacing = min(90, (height - 120) // max(n, 1))

        for i, (vtype, sev, cnt) in enumerate(self.violations):
            y = 90 + i * spacing
            cx = width // 2

            if sev == "error":
                status = 3
                color = "#f85149"
            else:
                status = 2
                color = "#d29922"

            route = route_map.get(vtype)
            if route:
                _, name, success, fail, conf = route
                if success > 0 and fail == 0:
                    road_color = "#3fb950"
                elif fail > 0 and success == 0:
                    road_color = "#f85149"
                else:
                    road_color = "#d29922"
            else:
                road_color = "#484f58"

            # Link from start to destination
            objects.append({
                "id": f"link_in_{i}",
                "type": "rect",
                "position": [(80 + cx) / 2, (height // 2 + y) / 2],
                "rotation": math.degrees(math.atan2(y - height // 2, cx - 80)),
                "scale": 1.0, "opacity": 0.3,
                "color": road_color, "stroke_color": road_color, "stroke_width": 0,
                "width": math.sqrt((cx - 80) ** 2 + (y - height // 2) ** 2),
                "height": 1.5, "text": ""
            })

            # Destination node
            objects.append({
                "id": f"dest_{i}",
                "type": "mcp_node",
                "position": [cx, y],
                "rotation": 0, "scale": 0.8, "opacity": 1.0,
                "color": color, "stroke_color": color, "stroke_width": 2,
                "node_label": vtype[:20], "node_status": status, "text": "",
                "motion": {"type": "pulse", "speed": 0.5, "amplitude": 3.0, "radius": 0,
                           "phase": i * 0.1, "center": [cx, y], "seed": 42}
            })

            # Result node
            end_x = width - 120
            if route:
                _, name, success, fail, conf = route
                if success > 0 and fail == 0:
                    result_status = 1
                    result_color = "#3fb950"
                    result_label = "OK"
                elif fail > 0 and success == 0:
                    result_status = 3
                    result_color = "#f85149"
                    result_label = "FAIL"
                else:
                    result_status = 2
                    result_color = "#d29922"
                    result_label = "?"
            else:
                result_status = 0
                result_color = "#484f58"
                result_label = "—"

            objects.append({
                "id": f"result_{i}",
                "type": "mcp_node",
                "position": [end_x, y],
                "rotation": 0, "scale": 0.5, "opacity": 0.8,
                "color": result_color, "stroke_color": result_color, "stroke_width": 1,
                "node_label": result_label, "node_status": result_status, "text": "",
                "motion": {"type": "pulse", "speed": 0.3, "amplitude": 2.0, "radius": 0,
                           "phase": i * 0.15, "center": [end_x, y], "seed": 42}
            })

            # Link from destination to result
            objects.append({
                "id": f"link_out_{i}",
                "type": "rect",
                "position": [(cx + end_x) / 2, y],
                "rotation": 0,
                "scale": 1.0, "opacity": 0.3,
                "color": road_color, "stroke_color": road_color, "stroke_width": 0,
                "width": end_x - cx, "height": 1.5, "text": ""
            })

        # Background particles
        objects.append({
            "id": "bg_particles",
            "type": "emitter",
            "position": [width / 2, height / 2],
            "rotation": 0, "scale": 1.0, "opacity": 1.0,
            "color": "#7b2ff7", "stroke_color": "#ffffff", "stroke_width": 1,
            "emitter": {
                "type": "dust", "rate": 8, "speed": 15, "speed_var": 10,
                "size": 1.5, "size_var": 0.5, "life": 4.0, "life_var": 1.0,
                "gravity": -5, "drag": 0.98, "area": [400, 300], "max": 80
            },
            "text": ""
        })

        return {
            "name": "CodeGPS Repair Map",
            "width": width,
            "height": height,
            "background": [0.02, 0.02, 0.06],
            "duration": 8.0,
            "fps": 60,
            "objects": objects,
        }


def main():
    root = tk.Tk()
    app = CodeGPSMap(root)
    root.mainloop()


if __name__ == "__main__":
    main()
