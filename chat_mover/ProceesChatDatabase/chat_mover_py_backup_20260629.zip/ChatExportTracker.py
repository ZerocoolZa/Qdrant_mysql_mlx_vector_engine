#!/usr/bin/env python3
"""
ChatExportTracker — Tracks Cascade chat exports from the same conversation.

Problem:
    Cascade exports the same conversation multiple times as it grows.
    Each export gets a different filename based on the dominant topic at export time.
    Content is a superset — each export contains everything the previous had, plus more.
    This makes it look like 4 different conversations when it's actually 1.

Solution:
    Scan a folder for .md chat exports, detect shared-prefix grouping,
    record the export chain, identify the canonical (latest) version,
    flag stale snapshots for cleanup.

VBStyle compliant: Run() dispatch, Tuple3 (ok, data, error), self.state dict,
    no decorators, no print, no hardcoded paths, PascalCase, UPPERCASE constants.
"""

import os
import re
import hashlib
import json
from datetime import datetime

# ═══════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════

VERSION = "1.0"
PREFIX_LINES = 50          # lines to compare for shared-prefix detection
MIN_FILE_SIZE = 1024       # skip files smaller than 1KB (not real chat exports)
CHATTER_MARKER = "# Cascade Chat Conversation"

# ═══════════════════════════════════════════════════════════════
# ChatExportTracker
# ═══════════════════════════════════════════════════════════════

class ChatExportTracker:
    """Tracks chat exports from the same conversation across multiple snapshots."""

    def __init__(self, mem=None, db=None, param=None):
        self.mem = mem
        self.db = db
        self.param = param if isinstance(param, dict) else {}
        self.state = {
            "config": self.param.get("config", {}),
            "catalog": [],
            "results": []
        }

    #[@scan_folder]{[@params<<params>][@return<Tuple3>][@purpose<scan folder for .md chat exports and group by conversation>]}
    def scan_folder(self, params):
        try:
            folder = params.get("folder", ".")
            if not os.path.isdir(folder):
                return (0, None, ("NOT_A_FOLDER", f"not a directory: {folder}", 0))

            md_files = []
            for fname in sorted(os.listdir(folder)):
                if not fname.endswith(".md"):
                    continue
                fpath = os.path.join(folder, fname)
                if not os.path.isfile(fpath):
                    continue
                fsize = os.path.getsize(fpath)
                if fsize < MIN_FILE_SIZE:
                    continue
                with open(fpath, "r", errors="replace") as f:
                    lines = f.readlines()
                if not lines or CHATTER_MARKER not in lines[0] if lines else "":
                    continue

                user_inputs = self._count_user_inputs(lines)
                prefix_hash = self._prefix_hash(lines)
                first_user_input = self._first_user_input(lines)
                last_user_input = self._last_user_input(lines)

                md_files.append({
                    "filename": fname,
                    "path": fpath,
                    "size_bytes": fsize,
                    "line_count": len(lines),
                    "user_input_count": user_inputs,
                    "prefix_hash": prefix_hash,
                    "first_user_input": first_user_input,
                    "last_user_input": last_user_input,
                    "mtime": os.path.getmtime(fpath)
                })

            groups = self._group_by_conversation(md_files)

            self.state["catalog"] = md_files
            self.state["results"] = groups

            return (1, {
                "files_found": len(md_files),
                "conversation_groups": len(groups),
                "groups": groups
            }, None)
        except Exception as e:
            return (0, None, ("SCAN_ERROR", str(e), 0))

    #[@get_canonical]{[@params<<params>][@return<Tuple3>][@purpose<identify the latest/most complete export per conversation>]}
    def get_canonical(self, params):
        try:
            groups = self.state.get("results", [])
            if not groups:
                return (0, None, ("NO_SCAN", "run scan_folder first", 0))

            canonical = []
            for group in groups:
                members = group["members"]
                if not members:
                    continue
                latest = max(members, key=lambda m: m["line_count"])
                stale = [m for m in members if m["filename"] != latest["filename"]]
                canonical.append({
                    "conversation_id": group["conversation_id"],
                    "canonical_file": latest["filename"],
                    "canonical_path": latest["path"],
                    "canonical_lines": latest["line_count"],
                    "stale_files": [m["filename"] for m in stale],
                    "stale_count": len(stale)
                })

            return (1, {"canonical": canonical}, None)
        except Exception as e:
            return (0, None, ("CANONICAL_ERROR", str(e), 0))

    #[@get_export_chain]{[@params<<params>][@return<Tuple3>][@purpose<get ordered export chain for a conversation group>]}
    def get_export_chain(self, params):
        try:
            group_id = params.get("conversation_id", 0)
            groups = self.state.get("results", [])
            if group_id >= len(groups):
                return (0, None, ("INVALID_GROUP", f"group {group_id} does not exist", 0))

            members = sorted(groups[group_id]["members"], key=lambda m: m["line_count"])
            chain = []
            for i, m in enumerate(members):
                entry = {
                    "order": i + 1,
                    "filename": m["filename"],
                    "lines": m["line_count"],
                    "user_inputs": m["user_input_count"],
                    "size_kb": round(m["size_bytes"] / 1024),
                    "last_input": m["last_user_input"][:80] if m["last_user_input"] else "",
                    "mtime": datetime.fromtimestamp(m["mtime"]).isoformat()
                }
                if i > 0:
                    prev = members[i - 1]
                    entry["added_inputs"] = m["user_input_count"] - prev["user_input_count"]
                    entry["added_lines"] = m["line_count"] - prev["line_count"]
                else:
                    entry["added_inputs"] = m["user_input_count"]
                    entry["added_lines"] = m["line_count"]
                chain.append(entry)

            return (1, {"chain": chain}, None)
        except Exception as e:
            return (0, None, ("CHAIN_ERROR", str(e), 0))

    #[@export_report]{[@params<<params>][@return<Tuple3>][@purpose<generate markdown report of all conversation groups>]}
    def export_report(self, params):
        try:
            groups = self.state.get("results", [])
            if not groups:
                return (0, None, ("NO_SCAN", "run scan_folder first", 0))

            lines = []
            lines.append("# Chat Export Tracker Report")
            lines.append("")
            lines.append(f"Generated: {datetime.now().isoformat()}")
            lines.append(f"Conversation groups found: {len(groups)}")
            lines.append("")

            for gi, group in enumerate(groups):
                lines.append(f"## Conversation {gi + 1}")
                lines.append("")
                lines.append(f"- **Shared prefix hash:** `{group['conversation_id']}`")
                lines.append(f"- **Exports:** {len(group['members'])}")
                lines.append(f"- **First user input:** {group['first_input'][:80]}")
                lines.append("")

                r = self.get_export_chain({"conversation_id": gi})
                if not r[0]:
                    continue

                lines.append("| Order | Filename | Lines | User Inputs | Size (KB) | Added Inputs | Last Input |")
                lines.append("|-------|----------|-------|-------------|-----------|--------------|------------|")
                for entry in r[1]["chain"]:
                    lines.append(
                        f"| {entry['order']} | {entry['filename']} | {entry['lines']:,} | "
                        f"{entry['user_inputs']} | {entry['size_kb']} | "
                        f"+{entry['added_inputs']} | {entry['last_input'][:50]} |"
                    )
                lines.append("")

                r2 = self.get_canonical({})
                if r2[0]:
                    for c in r2[1]["canonical"]:
                        if c["conversation_id"] == gi:
                            lines.append(f"**Canonical (keep):** `{c['canonical_file']}` ({c['canonical_lines']:,} lines)")
                            if c["stale_files"]:
                                lines.append(f"**Stale (safe to delete):** {', '.join(c['stale_files'])}")
                            lines.append("")

            report = "\n".join(lines)
            return (1, {"report": report, "lines": len(lines)}, None)
        except Exception as e:
            return (0, None, ("REPORT_ERROR", str(e), 0))

    #[@Run]{[@params<<command, params>][@return<Tuple3>][@purpose<central command dispatch>]}
    def Run(self, command, params=None):
        params = params or {}
        if command == "scan_folder":
            return self.scan_folder(params)
        elif command == "get_canonical":
            return self.get_canonical(params)
        elif command == "get_export_chain":
            return self.get_export_chain(params)
        elif command == "export_report":
            return self.export_report(params)
        elif command == "read_state":
            return (1, self.state.copy(), None)
        else:
            return (0, None, ("UNKNOWN_COMMAND", command, 0))

    # ═══════════════════════════════════════════════════════════
    # INTERNAL HELPERS
    # ═══════════════════════════════════════════════════════════

    def _count_user_inputs(self, lines):
        count = 0
        for line in lines:
            if line.strip() == "### User Input":
                count += 1
        return count

    def _prefix_hash(self, lines):
        prefix = "".join(lines[:PREFIX_LINES])
        return hashlib.md5(prefix.encode("utf-8", errors="replace")).hexdigest()[:12]

    def _first_user_input(self, lines):
        for i, line in enumerate(lines):
            if line.strip() == "### User Input":
                for j in range(i + 1, min(i + 10, len(lines))):
                    text = lines[j].strip()
                    if text and not text.startswith("###"):
                        return text
        return ""

    def _last_user_input(self, lines):
        last = ""
        for i, line in enumerate(lines):
            if line.strip() == "### User Input":
                for j in range(i + 1, min(i + 10, len(lines))):
                    text = lines[j].strip()
                    if text and not text.startswith("###"):
                        last = text
        return last

    def _group_by_conversation(self, files):
        groups = {}
        for f in files:
            key = f["prefix_hash"]
            if key not in groups:
                groups[key] = []
            groups[key].append(f)

        result = []
        for key, members in groups.items():
            members_sorted = sorted(members, key=lambda m: m["line_count"])
            result.append({
                "conversation_id": key,
                "member_count": len(members_sorted),
                "members": members_sorted,
                "first_input": members_sorted[0]["first_user_input"] if members_sorted else "",
                "total_lines": sum(m["line_count"] for m in members_sorted)
            })
        return result


# ═══════════════════════════════════════════════════════════════
# MAIN — demo / CLI
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    tracker = ChatExportTracker()

    folder = os.path.dirname(os.path.abspath(__file__))
    r = tracker.Run("scan_folder", {"folder": folder})
    if not r[0]:
        pass  # TODO: replace with Report
        exit(1)

    data = r[1]
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    print()

    for gi, group in enumerate(data["groups"]):
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        pass  # TODO: replace with Report
        print()

        r2 = tracker.Run("get_export_chain", {"conversation_id": gi})
        if r2[0]:
            for entry in r2[1]["chain"]:
                added = f"+{entry['added_inputs']} inputs, +{entry['added_lines']} lines"
                pass  # TODO: replace with Report
                pass  # TODO: replace with Report
                pass  # TODO: replace with Report
                print()

    r3 = tracker.Run("get_canonical", {})
    if r3[0]:
        pass  # TODO: replace with Report
        for c in r3[1]["canonical"]:
            pass  # TODO: replace with Report
            if c["stale_files"]:
                pass  # TODO: replace with Report
            print()

    r4 = tracker.Run("export_report", {})
    if r4[0]:
        report_path = os.path.join(folder, "chat_export_report.md")
        with open(report_path, "w") as f:
            f.write(r4[1]["report"])
        pass  # TODO: replace with Report