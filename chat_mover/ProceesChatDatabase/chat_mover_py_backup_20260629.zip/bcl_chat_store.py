#!/usr/bin/env python3

#[@GHOST]{[@file<bcl_chat_store.py>][@domain<chat_mover>][@role<storage>][@auth<cascade>][@date<2026-06-28>][@ver<1.0>]}
#[@VBSTYLE]{[@auth<cascade>][@role<storage>][@return<Tuple3>][@orch<none>][@no<decorators|print|hardcoded_paths>]}

"""
BclChatStore: SQLite storage for original chat + BCL compressed versions.

Stores:
  - original_chats: raw .md chat files (full text, md5, line count, source path)
  - bcl_stage1: Stage 1 code extraction (tokens, stats, output text)
  - bcl_stage2: Stage 2 AI semantic pass (problems, unresolved, decisions, lessons)
  - chat_items: individual resolved/unresolved items extracted from chats

Database path: chat_mover/ProceesChatDatabase/bcl_chat_store.db
"""

import os
import sqlite3
import hashlib
from datetime import datetime

from Config_chat_mover import BCL_CHAT_DB_DIR as DB_DIR, BCL_CHAT_DB_PATH as DB_PATH, BCL_CHAT_STORE_SCHEMA as SCHEMA_SQL


class BclChatStore:
    """SQLite storage for original chat + BCL compressed versions."""

    def __init__(self, mem=None, db=None, param=None):
        self.mem = mem
        self.db = db
        self.param = param if isinstance(param, dict) else {}
        self.state = {
            "config": self.param.get("config", {}),
            "db_path": self.param.get("db_path", DB_PATH),
            "conn": None,
            "cur": None,
        }

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def open(self, params=None):
        try:
            db_path = self._p(params, "db_path", self.state["db_path"])
            db_dir = os.path.dirname(db_path)
            if db_dir and not os.path.exists(db_dir):
                os.makedirs(db_dir)
            self.state["conn"] = sqlite3.connect(db_path)
            self.state["cur"] = self.state["conn"].cursor()
            self.state["conn"].executescript(SCHEMA_SQL)
            self.state["conn"].commit()
            return (1, {"connected": True, "db_path": db_path}, None)
        except Exception as e:
            return (0, None, ("OPEN_ERROR", str(e), 0))

    def close(self, params=None):
        try:
            if self.state["conn"]:
                self.state["conn"].commit()
                self.state["conn"].close()
                self.state["conn"] = None
                self.state["cur"] = None
            return (1, {"closed": True}, None)
        except Exception as e:
            return (0, None, ("CLOSE_ERROR", str(e), 0))

    def store_chat(self, params):
        """Store original chat file content."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            source_path = self._p(params, "source_path", "")
            content = self._p(params, "content", "")
            if not source_path or not content:
                return (0, None, ("MISSING_PARAM", "source_path and content required", 0))

            source_name = os.path.basename(source_path)
            md5_hash = hashlib.md5(content.encode("utf-8")).hexdigest()[:12]
            line_count = len(content.splitlines())
            file_size = len(content.encode("utf-8"))
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            cur.execute(
                "SELECT id FROM original_chats WHERE md5_hash = ?",
                (md5_hash,)
            )
            existing = cur.fetchone()
            if existing:
                return (1, {"chat_id": existing[0], "already_exists": True}, None)

            cur.execute(
                "INSERT INTO original_chats (source_path, source_name, md5_hash, line_count, file_size, date_ingested, content) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (source_path, source_name, md5_hash, line_count, file_size, date_now, content)
            )
            chat_id = cur.lastrowid
            self.state["conn"].commit()
            return (1, {"chat_id": chat_id, "md5": md5_hash, "lines": line_count}, None)
        except Exception as e:
            return (0, None, ("STORE_CHAT_ERROR", str(e), 0))

    def store_stage1(self, params):
        """Store Stage 1 BCL compression output."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            chat_id = self._p(params, "chat_id")
            output_text = self._p(params, "output_text", "")
            token_count = self._p(params, "token_count", 0)
            compression_ratio = self._p(params, "compression_ratio", 0.0)
            output_lines = self._p(params, "output_lines", 0)
            stats_json = self._p(params, "stats_json", "")
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            if not chat_id:
                return (0, None, ("MISSING_PARAM", "chat_id required", 0))

            cur.execute(
                "INSERT INTO bcl_stage1 (chat_id, token_count, compression_ratio, output_lines, output_text, stats_json, date_created) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (chat_id, token_count, compression_ratio, output_lines, output_text, stats_json, date_now)
            )
            stage1_id = cur.lastrowid
            self.state["conn"].commit()
            return (1, {"stage1_id": stage1_id}, None)
        except Exception as e:
            return (0, None, ("STORE_STAGE1_ERROR", str(e), 0))

    def store_stage2(self, params):
        """Store Stage 2 AI semantic pass output + individual items."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            chat_id = self._p(params, "chat_id")
            stage1_id = self._p(params, "stage1_id")
            output_text = self._p(params, "output_text", "")
            items = self._p(params, "items", [])
            date_now = datetime.now().strftime("%Y-%m-%d %H:%M")

            if not chat_id or not stage1_id:
                return (0, None, ("MISSING_PARAM", "chat_id and stage1_id required", 0))

            counts = {}
            for item in items:
                itype = item.get("type", "unknown")
                counts[itype] = counts.get(itype, 0) + 1

            cur.execute(
                "INSERT INTO bcl_stage2 (chat_id, stage1_id, problems_count, unresolved_count, decisions_count, successes_count, failed_count, lessons_count, output_text, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    chat_id, stage1_id,
                    counts.get("PROBLEM", 0),
                    counts.get("UNRESOLVED", 0),
                    counts.get("DECISION", 0),
                    counts.get("SUCCESS", 0),
                    counts.get("FAILED", 0),
                    counts.get("LESSON", 0),
                    output_text, date_now
                )
            )
            stage2_id = cur.lastrowid

            for item in items:
                cur.execute(
                    "INSERT INTO chat_items (chat_id, stage2_id, item_type, line_number, content, status, keyword, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        chat_id, stage2_id,
                        item.get("type", "unknown"),
                        item.get("line", 0),
                        item.get("content", ""),
                        item.get("status", "open"),
                        item.get("keyword", ""),
                        date_now
                    )
                )

            self.state["conn"].commit()
            return (1, {"stage2_id": stage2_id, "items_stored": len(items)}, None)
        except Exception as e:
            return (0, None, ("STORE_STAGE2_ERROR", str(e), 0))

    def list_chats(self, params=None):
        """List all stored chats with their stage counts."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            cur.execute("""
                SELECT c.id, c.source_name, c.line_count, c.date_ingested,
                       s1.token_count, s1.output_lines,
                       s2.problems_count, s2.unresolved_count, s2.decisions_count
                FROM original_chats c
                LEFT JOIN bcl_stage1 s1 ON s1.chat_id = c.id
                LEFT JOIN bcl_stage2 s2 ON s2.chat_id = c.id
                ORDER BY c.date_ingested DESC
            """)
            rows = cur.fetchall()
            chats = []
            for row in rows:
                chats.append({
                    "chat_id": row[0],
                    "source_name": row[1],
                    "line_count": row[2],
                    "date_ingested": row[3],
                    "stage1_tokens": row[4],
                    "stage1_lines": row[5],
                    "stage2_problems": row[6],
                    "stage2_unresolved": row[7],
                    "stage2_decisions": row[8],
                })
            return (1, {"chats": chats, "count": len(chats)}, None)
        except Exception as e:
            return (0, None, ("LIST_CHATS_ERROR", str(e), 0))

    def get_unresolved(self, params=None):
        """Get all unresolved items across all chats."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            cur.execute("""
                SELECT ci.id, ci.chat_id, ci.line_number, ci.content, ci.status, ci.keyword,
                       oc.source_name
                FROM chat_items ci
                JOIN original_chats oc ON oc.id = ci.chat_id
                WHERE ci.item_type = 'UNRESOLVED'
                ORDER BY ci.line_number DESC
            """)
            rows = cur.fetchall()
            items = []
            for row in rows:
                items.append({
                    "item_id": row[0],
                    "chat_id": row[1],
                    "line": row[2],
                    "content": row[3],
                    "status": row[4],
                    "keyword": row[5],
                    "source": row[6],
                })
            return (1, {"items": items, "count": len(items)}, None)
        except Exception as e:
            return (0, None, ("GET_UNRESOLVED_ERROR", str(e), 0))

    def resolve_item(self, params):
        """Mark a chat item as resolved."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            item_id = self._p(params, "item_id")
            if not item_id:
                return (0, None, ("MISSING_PARAM", "item_id required", 0))
            cur.execute("UPDATE chat_items SET status = 'resolved' WHERE id = ?", (item_id,))
            self.state["conn"].commit()
            return (1, {"item_id": item_id, "status": "resolved"}, None)
        except Exception as e:
            return (0, None, ("RESOLVE_ERROR", str(e), 0))

    def get_stats(self, params=None):
        """Get database statistics."""
        try:
            cur = self.state["cur"]
            if not cur:
                return (0, None, ("NO_CURSOR", "Database not open", 0))
            stats = {}
            cur.execute("SELECT COUNT(*) FROM original_chats")
            stats["chats"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM bcl_stage1")
            stats["stage1_outputs"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM bcl_stage2")
            stats["stage2_outputs"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items")
            stats["total_items"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items WHERE status = 'open'")
            stats["open_items"] = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM chat_items WHERE status = 'resolved'")
            stats["resolved_items"] = cur.fetchone()[0]
            cur.execute("SELECT item_type, COUNT(*) FROM chat_items GROUP BY item_type")
            for row in cur.fetchall():
                stats["items_" + row[0].lower()] = row[1]
            return (1, stats, None)
        except Exception as e:
            return (0, None, ("STATS_ERROR", str(e), 0))

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        try:
            if isinstance(params, dict):
                for key, value in params.items():
                    self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("CONFIG_ERROR", str(e), 0))

    def Run(self, command, params=None):
        params = params or {}
        dispatch = {
            "open": self.open,
            "close": self.close,
            "store_chat": self.store_chat,
            "store_stage1": self.store_stage1,
            "store_stage2": self.store_stage2,
            "list_chats": self.list_chats,
            "get_unresolved": self.get_unresolved,
            "resolve_item": self.resolve_item,
            "get_stats": self.get_stats,
            "read_state": self.read_state,
            "set_config": self.set_config,
        }
        handler = dispatch.get(command)
        if handler:
            return handler(params)
        return (0, None, ("UNKNOWN_COMMAND", command, 0))


def main():
    import argparse
    parser = argparse.ArgumentParser(description="BclChatStore — Chat + BCL Storage")
    parser.add_argument("--db", default=DB_PATH, help="SQLite DB path")
    parser.add_argument("--stats", action="store_true", help="Show database stats")
    parser.add_argument("--list", action="store_true", help="List all chats")
    parser.add_argument("--unresolved", action="store_true", help="List unresolved items")
    args = parser.parse_args()

    store = BclChatStore(param={"db_path": args.db})
    rv = store.Run("open", {"db_path": args.db})
    if rv[0] != 1:
        return

    if args.stats:
        rv = store.Run("get_stats", {})
        if rv[0]:
            print("=== BCL Chat Store Stats ===")
            for k, v in rv[1].items():
                print(f"  {k}: {v}")

    if args.list:
        rv = store.Run("list_chats", {})
        if rv[0]:
            chats = rv[1]["chats"]
            print(f"=== Stored Chats ({len(chats)}) ===")
            for c in chats:
                print(f"  [{c['chat_id']}] {c['source_name']} ({c['line_count']} lines)")
                if c["stage1_tokens"]:
                    print(f"    Stage1: {c['stage1_tokens']} tokens, {c['stage1_lines']} lines")
                if c["stage2_problems"] is not None:
                    print(f"    Stage2: {c['stage2_problems']} problems, {c['stage2_unresolved']} unresolved, {c['stage2_decisions']} decisions")

    if args.unresolved:
        rv = store.Run("get_unresolved", {})
        if rv[0]:
            items = rv[1]["items"]
            print(f"=== Unresolved Items ({len(items)}) ===")
            for item in items:
                print(f"  [{item['item_id']}] L{item['line']} ({item['source']}) {item['content'][:100]}")

    store.Run("close", {})


if __name__ == "__main__":
    main()
