"""
#[@GHOST]{("file_path=/Users/wws/Downloads/ChatGPTManager/CascadeIngester.py";"identity=CascadeIngester";"purpose=Decrypt Cascade .pb files and ingest conversations into MySQL";"date=2026-06-26";"version=1.0";"author=Devin";"chat_link=mysql://devin/devin_chat_turns?session_id=bottled-tarsier")}
#[@VBSTYLE]{("auth=Devin";"role=domain_cascade_ingest";"return=Tuple3";"orch=none";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete")}
#[@CLASSES]{("CascadeIngester")}
#[@METHODS]{("Run";"Decrypt";"Ingest";"Status";"_Connect";"_Close";"_CreateSchema";"_IngestTrajectory";"_ExtractMessagesFromRound";"_CountWords";"_Slugify";"read_state";"set_config";"_p")}
#[@DOMAIN]{("cascade_ingest")}
"""

import os
import sys
import re
from pathlib import Path
from typing import Any, Dict, Tuple

from Config import (
    DB_HOST, DB_USER, DB_PASSWORD, DB_CHARSET,
    CASCADE_DIR, CASCADE_DECRYPTED_DIR, CASCADE_DB_NAME,
    CASCADE_DECRYPT_TOOL_DIR
)


SCHEMA_SQL = """
CREATE DATABASE IF NOT EXISTS cascade_chats CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
""".strip()

SCHEMA_TABLES = [
    """CREATE TABLE IF NOT EXISTS trajectories (
        id VARCHAR(128) PRIMARY KEY,
        cascade_id VARCHAR(128),
        file_name VARCHAR(255),
        trajectory_type INT,
        source INT,
        step_count INT,
        round_count INT,
        first_prompt TEXT,
        ingested_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS rounds (
        id INT AUTO_INCREMENT PRIMARY KEY,
        trajectory_id VARCHAR(128) NOT NULL,
        round_number INT NOT NULL,
        start_step INT,
        end_step INT,
        step_count INT,
        prompt TEXT,
        prompt_slug VARCHAR(120),
        UNIQUE KEY uniq_round (trajectory_id, round_number),
        INDEX idx_traj (trajectory_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        trajectory_id VARCHAR(128) NOT NULL,
        round_id INT,
        step_index INT NOT NULL,
        role VARCHAR(32) NOT NULL,
        variant_field INT,
        step_type INT,
        content LONGTEXT,
        internal_planning LONGTEXT,
        command TEXT,
        command_output LONGTEXT,
        file_uri TEXT,
        word_count INT DEFAULT 0,
        char_count INT DEFAULT 0,
        INDEX idx_traj (trajectory_id),
        INDEX idx_round (round_id),
        INDEX idx_role (role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
]


class CascadeIngester:
    """Authority for decrypting and ingesting Cascade .pb files into MySQL."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "cascade_dir": CASCADE_DIR,
                "decrypted_dir": CASCADE_DECRYPTED_DIR,
                "decrypt_tool_dir": CASCADE_DECRYPT_TOOL_DIR,
                "db_host": DB_HOST,
                "db_user": DB_USER,
                "db_password": DB_PASSWORD,
                "db_name": CASCADE_DB_NAME,
                "db_charset": DB_CHARSET
            },
            "catalog": [],
            "results": [],
            "memunit": mem,
            "db_manager": db,
            "conn": None,
            "cursor": None
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "decrypt":
            return self.Decrypt(params)
        elif command == "ingest":
            return self.Ingest(params)
        elif command == "decrypt_ingest":
            return self.DecryptIngest(params)
        elif command == "status":
            return self.Status(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        else:
            return (0, None, ("UNKNOWN_COMMAND", f"Unknown command: {command}", 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params):
        snapshot = dict(self.state)
        snapshot["conn"] = "connected" if self.state["conn"] else "disconnected"
        return (1, snapshot, None)

    def set_config(self, params):
        try:
            for key, value in params.items():
                self.state["config"][key] = value
            return (1, dict(self.state["config"]), None)
        except Exception as e:
            return (0, None, ("SET_CONFIG_ERROR", str(e), 0))

    def _CountWords(self, params):
        text = self.state["p"](params, "text", "")
        if not text:
            return (1, 0, None)
        return (1, len(text.split()), None)

    def _Slugify(self, params):
        s = self.state["p"](params, "text", "")
        max_len = self.state["p"](params, "max_len", 60)
        s = (s or "").strip().splitlines()[0] if s else ""
        s = re.sub(r"[\s/\\]+", "-", s)
        s = re.sub(r"[^\w\-]", "", s)
        s = s.strip("-")
        if not s:
            s = "untitled"
        if len(s) > max_len:
            s = s[:max_len].rstrip("-")
        return (1, s, None)

    def _Connect(self, params):
        try:
            import mysql.connector
            cfg = self.state["config"]
            self.state["conn"] = mysql.connector.connect(
                host=cfg["db_host"],
                user=cfg["db_user"],
                password=cfg["db_password"],
                charset=cfg["db_charset"]
            )
            self.state["cursor"] = self.state["conn"].cursor()
            return (1, True, None)
        except Exception as e:
            return (0, None, ("CONNECT_ERROR", str(e), 0))

    def _ConnectDb(self, params):
        try:
            import mysql.connector
            cfg = self.state["config"]
            self.state["conn"] = mysql.connector.connect(
                host=cfg["db_host"],
                user=cfg["db_user"],
                password=cfg["db_password"],
                database=cfg["db_name"],
                charset=cfg["db_charset"]
            )
            self.state["cursor"] = self.state["conn"].cursor(prepared=True)
            return (1, True, None)
        except Exception as e:
            return (0, None, ("CONNECT_DB_ERROR", str(e), 0))

    def _Close(self, params):
        try:
            if self.state["cursor"]:
                self.state["cursor"].close()
                self.state["cursor"] = None
            if self.state["conn"]:
                self.state["conn"].close()
                self.state["conn"] = None
            return (1, True, None)
        except Exception as e:
            return (0, None, ("CLOSE_ERROR", str(e), 0))

    def _CreateSchema(self, params):
        try:
            ok, _, error = self._Connect({})
            if not ok:
                return (0, None, error)
            cursor = self.state["cursor"]
            cursor.execute(SCHEMA_SQL)
            self.state["conn"].commit()
            self._Close({})

            ok, _, error = self._ConnectDb({})
            if not ok:
                return (0, None, error)
            cursor = self.state["cursor"]
            for table_sql in SCHEMA_TABLES:
                cursor.execute(table_sql)
            self.state["conn"].commit()
            self._Close({})
            return (1, True, None)
        except Exception as e:
            return (0, None, ("SCHEMA_ERROR", str(e), 0))

    def Decrypt(self, params):
        try:
            cascade_dir = self.state["p"](params, "cascade_dir", self.state["config"]["cascade_dir"])
            out_dir = self.state["p"](params, "out_dir", self.state["config"]["decrypted_dir"])
            tool_dir = self.state["config"]["decrypt_tool_dir"]

            if tool_dir not in sys.path:
                sys.path.insert(0, tool_dir)

            from decrypt_pb import decrypt_one

            cascade_path = Path(cascade_dir)
            out_path = Path(out_dir)
            out_path.mkdir(parents=True, exist_ok=True)

            results = []
            pb_files = sorted(cascade_path.glob("*.pb"))
            for pb_file in pb_files:
                try:
                    pt = decrypt_one(pb_file)
                    bin_path = out_path / (pb_file.stem + ".bin")
                    bin_path.write_bytes(pt)
                    results.append({
                        "name": pb_file.name,
                        "bin_path": str(bin_path),
                        "size": len(pt)
                    })
                except Exception as e:
                    results.append({
                        "name": pb_file.name,
                        "error": str(e)
                    })

            self.state["results"] = results
            return (1, results, None)
        except Exception as e:
            return (0, None, ("DECRYPT_ERROR", str(e), 0))

    def _ExtractMessagesFromRound(self, params):
        try:
            steps = self.state["p"](params, "steps", [])
            tool_dir = self.state["config"]["decrypt_tool_dir"]

            if tool_dir not in sys.path:
                sys.path.insert(0, tool_dir)

            from export_md import (
                read_string_field,
                VARIANT_USER_INPUT, VARIANT_PLANNER_RESPONSE, VARIANT_RUN_COMMAND,
                VARIANT_CHECKPOINT, VARIANT_FILE_CONTEXT, VARIANT_COMMAND_RESULT,
            )
            from scan_trajectory import parse_checkpoint, iter_fields

            messages = []
            for step_idx, step_dict in steps:
                vf = step_dict["variant_field"]
                data = step_dict["variant_data"] or b""
                step_type = step_dict["type"]

                if vf == VARIANT_USER_INPUT:
                    prompt = read_string_field(data, 2) or ""
                    messages.append({
                        "step_index": step_idx,
                        "role": "user",
                        "variant_field": vf,
                        "step_type": step_type,
                        "content": prompt,
                    })
                elif vf == VARIANT_PLANNER_RESPONSE:
                    user_facing = read_string_field(data, 1) or ""
                    internal = read_string_field(data, 3) or ""
                    messages.append({
                        "step_index": step_idx,
                        "role": "assistant",
                        "variant_field": vf,
                        "step_type": step_type,
                        "content": user_facing,
                        "internal_planning": internal if internal != user_facing else "",
                    })
                elif vf == VARIANT_RUN_COMMAND:
                    cmd = read_string_field(data, 23) or read_string_field(data, 25) or ""
                    output = ""
                    for fno, wt, _, val in iter_fields(data):
                        if fno == 24 and wt == 2:
                            try:
                                output = val.decode("utf-8", errors="replace")
                            except Exception:
                                pass
                            break
                    messages.append({
                        "step_index": step_idx,
                        "role": "tool",
                        "variant_field": vf,
                        "step_type": step_type,
                        "command": cmd,
                        "command_output": output,
                    })
                elif vf == VARIANT_CHECKPOINT:
                    cp = parse_checkpoint(data)
                    messages.append({
                        "step_index": step_idx,
                        "role": "checkpoint",
                        "variant_field": vf,
                        "step_type": step_type,
                        "content": cp.get("user_intent") or "",
                        "internal_planning": cp.get("session_summary") or "",
                    })
                elif vf == VARIANT_FILE_CONTEXT:
                    uri = read_string_field(data, 1) or ""
                    messages.append({
                        "step_index": step_idx,
                        "role": "file_context",
                        "variant_field": vf,
                        "step_type": step_type,
                        "file_uri": uri,
                    })
                elif vf == VARIANT_COMMAND_RESULT:
                    step_ref = read_string_field(data, 1) or ""
                    output = read_string_field(data, 9) or ""
                    messages.append({
                        "step_index": step_idx,
                        "role": "command_result",
                        "variant_field": vf,
                        "step_type": step_type,
                        "content": output,
                        "command": f"result of step #{step_ref}",
                    })
                else:
                    messages.append({
                        "step_index": step_idx,
                        "role": "other",
                        "variant_field": vf,
                        "step_type": step_type,
                        "content": f"[tool: variant_field={vf} type={step_type} {len(data)} bytes]",
                    })

            return (1, messages, None)
        except Exception as e:
            return (0, None, ("EXTRACT_MSG_ERROR", str(e), 0))

    def _IngestTrajectory(self, params):
        try:
            bin_path = self.state["p"](params, "bin_path", "")
            if not bin_path:
                return (0, None, ("NO_BIN_PATH", "bin_path not provided", 0))

            tool_dir = self.state["config"]["decrypt_tool_dir"]
            if tool_dir not in sys.path:
                sys.path.insert(0, tool_dir)

            from scan_trajectory import parse_trajectory
            from export_md import split_into_rounds

            buf = Path(bin_path).read_bytes()
            info = parse_trajectory(buf)
            traj_id = info["trajectory_id"] or Path(bin_path).stem
            cascade_id = info["cascade_id"] or Path(bin_path).stem
            # Sanitize: if trajectory_id is not a clean UUID, fall back to filename stem
            if traj_id and (len(traj_id) > 64 or not all(c in "0123456789abcdef-" for c in traj_id.lower())):
                traj_id = Path(bin_path).stem
            if cascade_id and (len(cascade_id) > 64 or not all(c in "0123456789abcdef-" for c in cascade_id.lower())):
                cascade_id = Path(bin_path).stem
            rounds = split_into_rounds(info["steps"])

            first_prompt = ""
            for r in rounds:
                if r["prompt"]:
                    first_prompt = r["prompt"][:500]
                    break

            cursor = self.state["cursor"]

            cursor.execute("""
                INSERT INTO trajectories (id, cascade_id, file_name, trajectory_type, source, step_count, round_count, first_prompt)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    cascade_id=VALUES(cascade_id), file_name=VALUES(file_name),
                    trajectory_type=VALUES(trajectory_type), source=VALUES(source),
                    step_count=VALUES(step_count), round_count=VALUES(round_count),
                    first_prompt=VALUES(first_prompt)
            """, (traj_id, cascade_id, Path(bin_path).name, info["trajectory_type"],
                  info["source"], info["steps_count"], len(rounds), first_prompt))

            total_msgs = 0
            for round_num, r in enumerate(rounds, start=1):
                prompt = r["prompt"] or ""
                ok, slug, _ = self._Slugify({"text": prompt}) if prompt else (1, "prelude", None)
                step_count = r["end_step"] - r["start_step"] + 1

                cursor.execute("""
                    INSERT INTO rounds (trajectory_id, round_number, start_step, end_step, step_count, prompt, prompt_slug)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        start_step=VALUES(start_step), end_step=VALUES(end_step),
                        step_count=VALUES(step_count), prompt=VALUES(prompt), prompt_slug=VALUES(prompt_slug)
                """, (traj_id, round_num, r["start_step"], r["end_step"], step_count, prompt, slug))

                cursor.execute("SELECT id FROM rounds WHERE trajectory_id=%s AND round_number=%s", (traj_id, round_num))
                round_id = cursor.fetchone()[0]

                ok, messages, _ = self._ExtractMessagesFromRound({"steps": r["parsed_steps"]})
                for msg in messages:
                    content = msg.get("content", "")
                    internal = msg.get("internal_planning", "")
                    cmd = msg.get("command", "")
                    cmd_out = msg.get("command_output", "")
                    file_uri = msg.get("file_uri", "")

                    all_text = " ".join(filter(None, [content, internal, cmd, cmd_out]))
                    ok, wc, _ = self._CountWords({"text": all_text})
                    cc = len(all_text)

                    cursor.execute("""
                        INSERT INTO messages (trajectory_id, round_id, step_index, role, variant_field, step_type,
                            content, internal_planning, command, command_output, file_uri, word_count, char_count)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (traj_id, round_id, msg["step_index"], msg["role"],
                          msg["variant_field"], msg["step_type"],
                          content, internal, cmd, cmd_out, file_uri, wc, cc))
                    total_msgs += 1

            return (1, {"traj_id": traj_id, "rounds": len(rounds), "messages": total_msgs}, None)
        except Exception as e:
            return (0, None, ("INGEST_TRAJ_ERROR", str(e), 0))

    def Ingest(self, params):
        try:
            decrypted_dir = self.state["p"](params, "decrypted_dir", self.state["config"]["decrypted_dir"])

            ok, _, error = self._CreateSchema({})
            if not ok:
                return (0, None, error)

            ok, _, error = self._ConnectDb({})
            if not ok:
                return (0, None, error)

            bin_files = sorted(Path(decrypted_dir).glob("*.bin"))
            total_traj = 0
            total_rounds = 0
            total_msgs = 0
            failed = 0

            for bin_path in bin_files:
                ok, result, error = self._IngestTrajectory({"bin_path": str(bin_path)})
                if ok:
                    total_traj += 1
                    total_rounds += result["rounds"]
                    total_msgs += result["messages"]
                else:
                    failed += 1
                self.state["conn"].commit()

            self._Close({})

            self.state["results"] = {
                "trajectories": total_traj,
                "rounds": total_rounds,
                "messages": total_msgs,
                "failed": failed
            }
            return (1, self.state["results"], None)
        except Exception as e:
            return (0, None, ("INGEST_ERROR", str(e), 0))

    def DecryptIngest(self, params):
        try:
            ok, decrypt_results, error = self.Decrypt(params)
            if not ok:
                return (0, None, error)

            ok, ingest_results, error = self.Ingest(params)
            if not ok:
                return (0, None, error)

            return (1, {
                "decrypted": len(decrypt_results),
                "ingested": ingest_results
            }, None)
        except Exception as e:
            return (0, None, ("DECRYPT_INGEST_ERROR", str(e), 0))

    def Status(self, params):
        try:
            ok, _, error = self._ConnectDb({})
            if not ok:
                return (0, None, error)

            cursor = self.state["cursor"]
            cursor.execute("SELECT COUNT(*) FROM trajectories")
            trajs = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM rounds")
            rounds = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM messages")
            msgs = cursor.fetchone()[0]
            cursor.execute("SELECT SUM(word_count) FROM messages")
            words = cursor.fetchone()[0] or 0
            cursor.execute("SELECT SUM(char_count) FROM messages")
            chars = cursor.fetchone()[0] or 0

            cursor.execute("SELECT role, COUNT(*) FROM messages GROUP BY role ORDER BY COUNT(*) DESC")
            role_counts = cursor.fetchall()

            cursor.execute("SELECT id, cascade_id, round_count, step_count, LEFT(first_prompt, 80) FROM trajectories ORDER BY ingested_at")
            traj_list = cursor.fetchall()

            self._Close({})

            status = {
                "database": self.state["config"]["db_name"],
                "trajectories": trajs,
                "rounds": rounds,
                "messages": msgs,
                "words": words,
                "chars": chars,
                "role_counts": role_counts,
                "trajectories_list": traj_list
            }
            self.state["results"] = status
            return (1, status, None)
        except Exception as e:
            return (0, None, ("STATUS_ERROR", str(e), 0))
