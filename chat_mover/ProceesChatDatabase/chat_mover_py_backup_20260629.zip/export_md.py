#!/usr/bin/env python3
"""Export a decrypted Windsurf Cascade trajectory (.bin protobuf) to human-readable Markdown.

Design:
  - One Markdown file per "conversation round" (user prompt → AI response → tool calls →
    until the next user prompt). This matches how a user thinks about the chat.
  - Files are numbered 0001-, 0002-, ... with a slug from the user's prompt.
  - If a round's markdown exceeds --max-bytes (default 80 KB), it is split into
    <round>-part-01.md, <round>-part-02.md so a single file always stays AI-readable
    in one chunk.
  - Per trajectory, a 00-index.md lists every round with its title and the file(s)
    that contain it.

Usage:
    export_md.py <decrypted.bin> --out-dir markdown/<traj-id>/
    export_md.py --batch <decrypted-dir> <markdown-root-dir>

Both inputs are *decrypted* protobuf bytes (output of decrypt_pb.py). To go from
encrypted .pb to markdown in one shot:

    python3 tools/decrypt_pb.py --batch ~/.codeium/windsurf/cascade ./decrypted/cascade
    python3 tools/export_md.py --batch ./decrypted/cascade ./markdown/cascade
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Iterable

sys.path.insert(0, str(Path(__file__).parent))
from scan_trajectory import (  # type: ignore
    parse_trajectory,
    parse_step,
    parse_checkpoint,
    iter_fields,
)

# --- Step variant_field → role mapping ---
# Discovered empirically from decrypted trajectories (Windsurf 1.110.1):
#   19 = user_input            (f2 = user's prompt text)
#   20 = planner_response       (f1 = AI's user-facing response; f3 = AI's English internal planning)
#   28 = run_command            (f23 = shell command; f24 = command output bytes; f25 = command again)
#   30 = checkpoint             (compressed step summary — see parse_checkpoint)
#   15 = file_context           (f1 = file URI)
# Many other variants exist (24/37/43/56/87/...) — they're tool calls / metadata
# we summarize minimally as "[tool: variant_field=N type=T]".

VARIANT_USER_INPUT = 19
VARIANT_PLANNER_RESPONSE = 20
VARIANT_RUN_COMMAND = 28
VARIANT_CHECKPOINT = 30
VARIANT_FILE_CONTEXT = 15
VARIANT_COMMAND_RESULT = 37


# --- Markdown rendering helpers ---


def slugify(s: str, max_len: int = 40) -> str:
    """Make a filesystem-safe, short slug from a user prompt's first line."""
    s = (s or "").strip().splitlines()[0] if s else ""
    s = re.sub(r"[\s/\\]+", "-", s)
    s = re.sub(r"[^\w\-一-鿿]", "", s)  # keep CJK + word chars + dash
    s = s.strip("-")
    if not s:
        s = "untitled"
    if len(s) > max_len:
        s = s[:max_len].rstrip("-")
    return s


def read_string_field(data: bytes, target_fno: int) -> str | None:
    """Walk a message body, return the first string-typed value at field number target_fno."""
    for fno, wt, _off, val in iter_fields(data):
        if fno == target_fno and wt == 2 and isinstance(val, (bytes, bytearray)):
            try:
                return val.decode("utf-8", errors="replace")
            except Exception:
                return None
    return None


def render_user_input(step_idx: int, data: bytes) -> tuple[str, str]:
    """Return (title, markdown) for a user_input step. Title is used in the index."""
    prompt = read_string_field(data, 2) or "(empty user prompt)"
    md = f"## 👤 User (step #{step_idx})\n\n{prompt.strip()}\n"
    return prompt, md


def render_planner_response(step_idx: int, data: bytes) -> str:
    """Return markdown for a planner_response step."""
    user_facing = read_string_field(data, 1)
    internal = read_string_field(data, 3)

    parts = [f"## 🤖 Assistant (step #{step_idx})\n"]
    if user_facing:
        parts.append(user_facing.strip() + "\n")
    if internal and internal != user_facing:
        # Distinct internal planning text — show under a foldout
        parts.append("\n<details>\n<summary>Internal planning (AI's English-only reasoning)</summary>\n")
        parts.append("\n```\n" + internal.strip() + "\n```\n")
        parts.append("</details>\n")
    if not user_facing and not internal:
        parts.append("*(no response text — likely a tool-call-only turn)*\n")
    return "".join(parts)


def render_run_command(step_idx: int, data: bytes) -> str:
    """Return markdown for a run_command step."""
    cmd = read_string_field(data, 23) or read_string_field(data, 25) or "(no command)"
    output: str | None = None
    for fno, wt, _off, val in iter_fields(data):
        if fno == 24 and wt == 2 and isinstance(val, (bytes, bytearray)):
            try:
                output = val.decode("utf-8", errors="replace")
            except Exception:
                output = None
            break
    parts = [f"<details>\n<summary>🛠 <code>run_command</code> (step #{step_idx})</summary>\n\n"]
    parts.append("**Command:**\n\n```bash\n" + cmd.strip() + "\n```\n")
    if output:
        truncated = output if len(output) <= 4000 else output[:4000] + f"\n... [+{len(output)-4000} chars truncated]"
        parts.append("\n**Output:**\n\n```\n" + truncated.strip() + "\n```\n")
    parts.append("\n</details>\n")
    return "".join(parts)


def render_file_context(step_idx: int, data: bytes) -> str:
    """Return markdown for a file_context step (variant_field=15)."""
    uri = read_string_field(data, 1) or "(no uri)"
    return f"<sub>📂 file context (step #{step_idx}): <code>{uri}</code></sub>\n"


def render_command_result(step_idx: int, data: bytes) -> str:
    """Return markdown for a command_result step (variant_field=37). Companion to run_command."""
    step_ref = read_string_field(data, 1) or "?"
    output = read_string_field(data, 9) or ""
    if not output:
        return f"<sub>📤 result of step #{step_ref} — empty output</sub>\n"
    truncated = output if len(output) <= 2000 else output[:2000] + f"\n... [+{len(output)-2000} chars truncated]"
    return (
        f"<details>\n<summary>📤 result of step #{step_ref} (step #{step_idx}, {len(output):,} chars output)</summary>\n\n"
        f"```\n{truncated.strip()}\n```\n\n</details>\n"
    )


def render_checkpoint(step_idx: int, data: bytes) -> str:
    """Return markdown for a CortexStepCheckpoint step — Cascade's compression artifact."""
    cp = parse_checkpoint(data)
    start = cp.get("included_step_index_start")
    end = cp.get("included_step_index_end")
    if start is not None and end is not None:
        span_str = f"steps **{start}..{end}** ({end - start} steps)"
    elif cp.get("included_step_indices"):
        indices = cp["included_step_indices"]
        span_str = f"{len(indices)} step(s): {indices[:5]}{'...' if len(indices) > 5 else ''}"
    else:
        span_str = "(step range not recorded)"
    title = cp.get("conversation_title") or "(no title)"
    intent_only = cp.get("intent_only")
    md = [
        f"---\n",
        f"### 🗜 Cascade Checkpoint (step #{step_idx})\n",
        f"\n",
        f"Cascade compressed {span_str} into a 6-field summary. "
        f"The original steps still exist in the trajectory file but are no longer sent to the LLM.\n",
        f"\n",
        f"- **Title**: {title}\n",
        f"- **Intent-only**: {intent_only}\n",
    ]
    for field in ("user_intent", "session_summary", "code_change_summary", "memory_summary", "plan_snapshot"):
        v = cp.get(field)
        if v:
            md.append(f"\n<details>\n<summary><b>{field}</b> ({len(v):,} chars)</summary>\n\n```\n{v}\n```\n</details>\n")
    md.append("\n---\n")
    return "".join(md)


def render_generic_step(step_idx: int, step_type: int, variant_field: int, data: bytes) -> str:
    """Fallback renderer for unrecognized step variants — keep it short."""
    return f"<sub>↪ step #{step_idx} · type={step_type} · variant_field={variant_field} · {len(data)} bytes (tool call / metadata, not rendered)</sub>\n"


def render_step(step_idx: int, step_dict) -> str:
    """Dispatch one parsed step to its renderer."""
    vf = step_dict["variant_field"]
    data = step_dict["variant_data"] or b""
    t = step_dict["type"]
    if vf == VARIANT_USER_INPUT:
        _, md = render_user_input(step_idx, data)
        return md
    if vf == VARIANT_PLANNER_RESPONSE:
        return render_planner_response(step_idx, data)
    if vf == VARIANT_RUN_COMMAND:
        return render_run_command(step_idx, data)
    if vf == VARIANT_CHECKPOINT:
        return render_checkpoint(step_idx, data)
    if vf == VARIANT_FILE_CONTEXT:
        return render_file_context(step_idx, data)
    if vf == VARIANT_COMMAND_RESULT:
        return render_command_result(step_idx, data)
    return render_generic_step(step_idx, t, vf, data)


# --- Round segmentation (split trajectory by user_input boundary) ---


def split_into_rounds(steps: list[bytes]) -> list[dict]:
    """Walk steps; emit one 'round' per user_input boundary.

    Returns a list of {start_step, end_step, prompt, parsed_steps}.
    Steps before the first user_input form a 'prelude' round (prompt=None).
    """
    rounds: list[dict] = []
    current: dict | None = None

    for idx, sb in enumerate(steps):
        s = parse_step(sb)
        if s["variant_field"] == VARIANT_USER_INPUT:
            if current is not None:
                current["end_step"] = idx - 1
                rounds.append(current)
            prompt = read_string_field(s["variant_data"] or b"", 2) or ""
            current = {
                "start_step": idx,
                "end_step": idx,
                "prompt": prompt,
                "parsed_steps": [(idx, s)],
            }
        else:
            if current is None:
                # prelude
                current = {
                    "start_step": idx,
                    "end_step": idx,
                    "prompt": None,
                    "parsed_steps": [],
                }
            current["parsed_steps"].append((idx, s))
            current["end_step"] = idx

    if current is not None:
        rounds.append(current)
    return rounds


# --- File writing ---


def write_round(out_dir: Path, round_no: int, r: dict, max_bytes: int) -> list[Path]:
    """Render one round to one or more markdown files. Returns list of written paths."""
    prompt = r["prompt"]
    slug = slugify(prompt) if prompt else f"prelude"
    base_name = f"{round_no:04d}-{slug}"

    header_parts = [
        f"# Round {round_no}: {slug}\n",
        f"\n",
        f"_Steps {r['start_step']}–{r['end_step']} ({r['end_step'] - r['start_step'] + 1} total)._\n",
        f"\n",
    ]
    if prompt is None:
        header_parts.append("_(Prelude — trajectory setup / state before the first user prompt.)_\n\n")

    body_parts: list[str] = []
    for step_idx, s in r["parsed_steps"]:
        body_parts.append(render_step(step_idx, s))
        body_parts.append("\n")

    full = "".join(header_parts) + "".join(body_parts)
    full_bytes = full.encode("utf-8")

    if len(full_bytes) <= max_bytes:
        path = out_dir / f"{base_name}.md"
        path.write_text(full, encoding="utf-8")
        return [path]

    # Need to split. Split body_parts greedily by part size, keeping a constant header.
    header = "".join(header_parts)
    parts: list[list[str]] = [[]]
    accumulated = len(header.encode("utf-8"))
    for chunk in body_parts:
        cb = len(chunk.encode("utf-8"))
        if accumulated + cb > max_bytes and parts[-1]:
            parts.append([])
            accumulated = len(header.encode("utf-8"))
        parts[-1].append(chunk)
        accumulated += cb

    written: list[Path] = []
    for i, body in enumerate(parts, start=1):
        marker = f"\n_Part {i} of {len(parts)}._\n\n"
        text = header + marker + "".join(body)
        path = out_dir / f"{base_name}-part-{i:02d}.md"
        path.write_text(text, encoding="utf-8")
        written.append(path)
    return written


def write_index(out_dir: Path, traj_id: str, rounds: list[dict], round_files: list[list[Path]]) -> Path:
    """Write 00-index.md with a navigable list of rounds."""
    lines = [
        f"# Trajectory `{traj_id}`\n",
        f"\n",
        f"Total **{len(rounds)} round(s)** ({sum(r['end_step'] - r['start_step'] + 1 for r in rounds)} steps).\n",
        f"\n",
        f"| # | Title | Steps | Files |\n",
        f"|---|---|---|---|\n",
    ]
    for i, (r, files) in enumerate(zip(rounds, round_files), start=1):
        slug = slugify(r["prompt"]) if r["prompt"] else "(prelude)"
        title_short = (r["prompt"][:60] + "…") if r["prompt"] and len(r["prompt"]) > 60 else (r["prompt"] or "_(prelude)_")
        title_short = title_short.replace("\n", " ").replace("|", "\\|")
        steps_range = f"{r['start_step']}–{r['end_step']}"
        if len(files) == 1:
            file_links = f"[{files[0].name}]({files[0].name})"
        else:
            file_links = ", ".join(f"[part {j+1}]({f.name})" for j, f in enumerate(files))
        lines.append(f"| {i} | {title_short} | {steps_range} | {file_links} |\n")

    path = out_dir / "00-index.md"
    path.write_text("".join(lines), encoding="utf-8")
    return path


# --- Top-level export ---


def export_one(bin_path: Path, out_dir: Path, max_bytes: int = 80 * 1024) -> dict:
    """Export one decrypted trajectory .bin to a directory of markdown files."""
    buf = bin_path.read_bytes()
    info = parse_trajectory(buf)
    traj_id = info["trajectory_id"] or bin_path.stem

    out_dir.mkdir(parents=True, exist_ok=True)
    rounds = split_into_rounds(info["steps"])

    round_files: list[list[Path]] = []
    for i, r in enumerate(rounds, start=1):
        paths = write_round(out_dir, i, r, max_bytes=max_bytes)
        round_files.append(paths)

    write_index(out_dir, traj_id, rounds, round_files)

    return {
        "trajectory_id": traj_id,
        "n_rounds": len(rounds),
        "n_files": sum(len(fs) for fs in round_files) + 1,  # +1 for index
        "out_dir": str(out_dir),
    }


def export_batch(in_dir: Path, out_root: Path, max_bytes: int) -> list[dict]:
    """Export every *.bin file in in_dir, each into its own subdir under out_root."""
    results = []
    for bin_path in sorted(in_dir.glob("*.bin")):
        sub_out = out_root / bin_path.stem
        try:
            result = export_one(bin_path, sub_out, max_bytes=max_bytes)
            results.append(result)
            pass  # TODO: replace with Report
        except Exception as e:
            pass  # TODO: replace with Report
            results.append({"trajectory_id": bin_path.stem, "error": str(e)})
    return results


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("one", help="Export a single decrypted .bin trajectory")
    p1.add_argument("bin_path")
    p1.add_argument("--out-dir", required=True, help="Directory for markdown output")
    p1.add_argument("--max-bytes", type=int, default=80 * 1024, help="Soft cap per markdown file (default 80 KB)")

    p2 = sub.add_parser("batch", help="Export every *.bin in a directory")
    p2.add_argument("in_dir")
    p2.add_argument("out_root")
    p2.add_argument("--max-bytes", type=int, default=80 * 1024)

    args = ap.parse_args()
    if args.cmd == "one":
        r = export_one(Path(args.bin_path).expanduser(), Path(args.out_dir).expanduser(), max_bytes=args.max_bytes)
        pass  # TODO: replace with Report
        return 0
    if args.cmd == "batch":
        results = export_batch(Path(args.in_dir).expanduser(), Path(args.out_root).expanduser(), max_bytes=args.max_bytes)
        ok = sum(1 for r in results if "error" not in r)
        pass  # TODO: replace with Report
        return 0 if ok == len(results) else 1
    return 2


if __name__ == "__main__":
    sys.exit(main())
