#!/usr/bin/env python3
"""SpecGraph Gap Analysis — adapted from Dom_Graph_Spec.py for chat_mover."""
import sqlite3, os

db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
conn = sqlite3.connect(db)
cur = conn.cursor()

pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
# 1. Isolated classes
cur.execute("SELECT unit_name FROM code_units WHERE unit_type='class'")
all_classes = [r[0] for r in cur.fetchall()]
cur.execute("SELECT DISTINCT source_class FROM graph_edges WHERE source_class IS NOT NULL")
connected_src = set(r[0] for r in cur.fetchall())
cur.execute("SELECT DISTINCT target_name FROM graph_edges WHERE target_name IS NOT NULL")
connected_tgt = set(r[0] for r in cur.fetchall())
isolated = [c for c in all_classes if c not in connected_src and c not in connected_tgt]

pass  # TODO: replace with Report
for c in isolated:
    pass  # TODO: replace with Report
if not isolated:
    pass  # TODO: replace with Report
# 2. Category coverage
pass  # TODO: replace with Report
cur.execute("SELECT unit_type, COUNT(*) FROM code_units GROUP BY unit_type ORDER BY COUNT(*) DESC")
for utype, cnt in cur.fetchall():
    pass  # TODO: replace with Report
# 3. Expected pairs
pass  # TODO: replace with Report
pairs = [
    ("Decrypt", "Encrypt"),
    ("Ingest", "Export"),
    ("Connect", "Close"),
    ("IngestCascade", "IngestDevin"),
    ("IngestCascade", "IngestChatGPT"),
    ("Status", "Ingest"),
]
cur.execute("SELECT DISTINCT unit_name FROM code_units WHERE unit_type IN ('method','function','class')")
all_names = set(r[0] for r in cur.fetchall())
for a, b in pairs:
    has_a = a in all_names
    has_b = b in all_names
    if has_a and has_b:
        pass  # TODO: replace with Report
    elif has_a:
        pass  # TODO: replace with Report
    elif has_b:
        pass  # TODO: replace with Report
    else:
        pass  # TODO: replace with Report
# 4. Dispatch key uniqueness
pass  # TODO: replace with Report
cur.execute("SELECT dispatch_keys, COUNT(DISTINCT class_name) FROM code_units WHERE dispatch_keys != '' GROUP BY dispatch_keys")
for dk, cnt in cur.fetchall():
    cur.execute("SELECT DISTINCT class_name FROM code_units WHERE dispatch_keys=?", (dk,))
    classes = ", ".join(r[0] for r in cur.fetchall() if r[0])
    dup = " DUPLICATE!" if cnt > 1 else ""
    pass  # TODO: replace with Report
# 5. Classes missing Run()
pass  # TODO: replace with Report
cur.execute("""
    SELECT unit_name FROM code_units WHERE unit_type='class'
    AND unit_name NOT IN (
        SELECT DISTINCT class_name FROM code_units WHERE unit_name='Run' AND unit_type='method'
    )
""")
missing_run = cur.fetchall()
for r in missing_run:
    pass  # TODO: replace with Report
if not missing_run:
    pass  # TODO: replace with Report
# 6. Duplicate methods across classes
pass  # TODO: replace with Report
cur.execute("""
    SELECT unit_name, COUNT(DISTINCT class_name), GROUP_CONCAT(DISTINCT class_name)
    FROM code_units WHERE unit_type='method' AND class_name IS NOT NULL
    GROUP BY unit_name HAVING COUNT(DISTINCT class_name) > 1
    ORDER BY COUNT(DISTINCT class_name) DESC
""")
for name, cnt, classes in cur.fetchall():
    pass  # TODO: replace with Report
# 7. Violation summary
pass  # TODO: replace with Report
cur.execute("SELECT violation_type, severity, COUNT(*) FROM violations GROUP BY violation_type, severity ORDER BY COUNT(*) DESC")
total_v = 0
for vtype, sev, cnt in cur.fetchall():
    pass  # TODO: replace with Report
    total_v += cnt
pass  # TODO: replace with Report
# 8. BCL stamp coverage
pass  # TODO: replace with Report
cur.execute("SELECT COUNT(*) FROM code_units WHERE unit_type IN ('class','method','function')")
total_u = cur.fetchone()[0]
cur.execute("SELECT COUNT(*) FROM bcl_stamps")
stamped = cur.fetchone()[0]
pass  # TODO: replace with Report
cur.execute("SELECT ROUND(AVG(confidence),2) FROM bcl_stamps")
avg_conf = cur.fetchone()[0]
pass  # TODO: replace with Report
# 9. Gap: target file structure
pass  # TODO: replace with Report
target_files = {
    "db.py": "DB manager (merged from CascadeIngester + MySQLIngester + Devin DB code)",
    "ingest.py": "All ingesters (merged Cascade + Devin + ChatGPT)",
    "decrypt.py": "Decrypt + scan + export + find_key (merged tools)",
}
existing = [f for f in os.listdir(".") if f.endswith(".py")]
for target, desc in target_files.items():
    exists = target in existing
    status = "EXISTS" if exists else "MISSING"
    pass  # TODO: replace with Report
# 10. CRUD completeness for chat_mover domain
pass  # TODO: replace with Report
crud_expected = ["Decrypt", "Ingest", "Export", "Status", "Connect", "Close", "Parse", "Scan"]
for op in crud_expected:
    found = op in all_names
    pass  # TODO: replace with Report
# 11. Summary
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
pass  # TODO: replace with Report
missing_targets = sum(1 for t in target_files if t not in existing)
pass  # TODO: replace with Report
pass  # TODO: replace with Report
conn.close()
