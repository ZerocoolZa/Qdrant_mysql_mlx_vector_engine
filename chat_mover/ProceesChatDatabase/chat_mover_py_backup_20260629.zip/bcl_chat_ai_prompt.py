#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/bcl_chat_ai_prompt.py"
# date="2026-06-28" author="Cascade" session_id="bcl-chat-compression"
# context="Stage 2: AI prompt builder for semantic BCL extraction from preliminary tokens"}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="bcl_chat_ai_prompt.py" domain="ChatMover" authority="BclChatAiPrompt"}
#[@SUMMARY]{summary="Stage 2 AI prompt builder: reads Stage 1 preliminary BCL tokens, builds a focused prompt for AI model to extract semantic tokens (problems, solutions, root causes, lessons, mood, intent)."}
#[@CLASS]{class="BclChatAiPrompt" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="build_prompt" type="command"}
#[@METHOD]{method="parse_preliminary" type="command"}
#[@METHOD]{method="format_prompt" type="command"}
#[@METHOD]{method="write_prompt" type="command"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import sys
from datetime import datetime

PROMPT_TEMPLATE = """You are a BCL (Bracketed Concept Language) chat compression engine. Your job is to read the preliminary tokens extracted by Stage 1 (code) and the raw chat source, then extract SEMANTIC tokens that code cannot extract.

## Preliminary Tokens (from Stage 1 — code extraction)

{preliminary_tokens}

## Instructions

Read the preliminary tokens above and the raw chat source. Extract the following semantic tokens IN CHRONOLOGICAL ORDER:

### Tokens to Extract

1. [@PROBLEM] — What went wrong. Each problem should be a single sentence.
2. [@SOLUTION] — How it was fixed. Directly below the problem it solves.
3. [@ROOT_CAUSE] — Why it happened. The underlying cause, not the symptom.
4. [@SUCCESS] — Approaches that worked. Proven paths to repeat.
5. [@FAILED] — Approaches that didn't work. Dead ends to avoid.
6. [@LESSON] — Cumulative takeaway. Place DIRECTLY BELOW the [@PROBLEM] it relates to.
7. [@DECISION] — Key decision points where a choice was made.
8. [@USER_PREF] — User preferences extracted from their messages.
9. [@MOOD] — User mood inferred from word choice, punctuation, tone.
10. [@INTENT] — What the user actually wanted (not what they literally said).
11. [@AI_CORRECT] — When the AI did the right thing.
12. [@AI_WRONG] — When the AI did the wrong thing or misunderstood.

### Output Format

Output as a chronological timeline (T1, T2, T3...) with inline lessons:

```
# --- T1: Shell Config (lines 1-200) ---
#[@USER_SAYS] "fix this issue"
#[@AI_SAYS]   "shell is already zsh, suppress warning"
#[@PROBLEM]   macOS bash deprecation warning every terminal open
#[@SOLUTION]  add BASH_SILENCE_DEPRECATION_WARNING=1
#[@SUCCESS]   warning suppressed
#[@LESSON]    check actual state before fixing
```

### Rules

- Each problem MUST have its lesson directly below it (inline lessons)
- Problems and solutions must be paired (problem first, solution below)
- Root causes go below the problem, above the solution
- Output in chronological order (by line number in source chat)
- Keep each token to one line, max 200 chars
- Include [@USER_SAYS] and [@AI_SAYS] from Stage 1 as context anchors
- At the end, include a cumulative LESSONS LEARNED section
- At the end, include COMPRESSION STATS

### Source Chat Reference

The raw chat source is at: {source_path}
Read it if you need more context than the preliminary tokens provide.
"""


class BclChatAiPrompt:
    """Stage 2: Builds AI prompt for semantic BCL extraction."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "chronological": True,
                "inline_lessons": True,
                "max_preliminary_lines": 500,
            },
            "preliminary_path": None,
            "source_path": None,
            "preliminary_content": "",
            "prompt": "",
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "build_prompt":
            return self.BuildPrompt(params)
        elif command == "parse_preliminary":
            return self.ParsePreliminary(params)
        elif command == "format_prompt":
            return self.FormatPrompt(params)
        elif command == "write_prompt":
            return self.WritePrompt(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def BuildPrompt(self, params):
        preliminary_path = self._p(params, "preliminary_path")
        source_path = self._p(params, "source_path")
        output_path = self._p(params, "output_path")
        if not preliminary_path:
            return (0, None, ("MISSING_PARAM", "preliminary_path required", 0))

        rv = self.ParsePreliminary({"preliminary_path": preliminary_path})
        if rv[0] != 1:
            return rv

        self.state["source_path"] = source_path or ""

        rv = self.FormatPrompt(params)
        if rv[0] != 1:
            return rv

        if output_path:
            return self.WritePrompt({"output_path": output_path})
        return (1, {"prompt": self.state["prompt"], "length": len(self.state["prompt"])}, None)

    def ParsePreliminary(self, params):
        path = self._p(params, "preliminary_path")
        if not path:
            return (0, None, ("MISSING_PARAM", "preliminary_path required", 0))
        if not os.path.isfile(path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + path, 0))
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        max_lines = self.state["config"]["max_preliminary_lines"]
        lines = content.splitlines()
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines.append("# ... (truncated, %d total lines)" % len(content.splitlines()))
        self.state["preliminary_path"] = path
        self.state["preliminary_content"] = "\n".join(lines)
        return (1, {"lines": len(lines)}, None)

    def FormatPrompt(self, params):
        prompt = PROMPT_TEMPLATE.format(
            preliminary_tokens=self.state["preliminary_content"],
            source_path=self.state["source_path"] or "(not provided)",
        )
        self.state["prompt"] = prompt
        return (1, {"length": len(prompt)}, None)

    def WritePrompt(self, params):
        output_path = self._p(params, "output_path")
        if not output_path:
            base = self.state["preliminary_path"]
            if base:
                base_no_ext, _ = os.path.splitext(base)
                output_path = base_no_ext + "_AI_PROMPT.md"
            else:
                return (0, None, ("MISSING_PARAM", "output_path required", 0))
        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(self.state["prompt"])
        except Exception as exc:
            return (0, None, ("WRITE_ERROR", str(exc), 0))
        return (1, {"output_path": output_path, "length": len(self.state["prompt"])}, None)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="BCL Chat AI Prompt Builder — Stage 2 (semantic extraction prompt)")
    parser.add_argument("--input", required=True, help="Preliminary BCL file from Stage 1")
    parser.add_argument("--source", help="Raw source chat .md file path (for AI reference)")
    parser.add_argument("--output", help="Output prompt file path (default: <input>_AI_PROMPT.md)")
    args = parser.parse_args()

    builder = BclChatAiPrompt()
    rv = builder.Run("build_prompt", {
        "preliminary_path": args.input,
        "source_path": args.source,
        "output_path": args.output,
    })

    if rv[0] == 1:
        data = rv[1]
        if "output_path" in data:
            print("Prompt written: %s (%d chars)" % (data["output_path"], data["length"]), file=sys.stderr)
        else:
            print(data["prompt"])
    else:
        err = rv[2]
        print("ERROR: %s — %s" % (err[0], err[1]), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
