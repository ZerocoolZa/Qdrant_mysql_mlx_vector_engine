#!/usr/bin/env python3
#[@GHOST]{("file_path=chat_mover/ai1.py";"identity=ai1.py";"purpose=";"date=2026-06-29";"version=1.0";"author=Cascade";"chat_link=")}
#[@VBSTYLE]{[@pass]{"return=Tuple3";"dispatch=Run";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete"}[@fail]{"decorators_found";"print_found";"hardcoded_values";"self._used"}}
#[@FILEID]{("session_id=auto";"context=Auto-stamped by header watcher";"purpose=")}
#[@SUMMARY]{("Created on 2026-06-29";"auto_stamped=true")}

import sqlite3
import time

PRIMITIVES = {
    "move_lines":        {"in": {"file","start","end","target"}, "out": {"modified_file","modified_target"}},
    "copy_lines":        {"in": {"file","start","end","target"}, "out": {"modified_target"}},
    "append":            {"in": {"file","content"}, "out": {"modified_file"}},
    "insert_at_line":    {"in": {"file","line","content"}, "out": {"modified_file"}},
    "insert_after_pat":  {"in": {"file","pattern","content"}, "out": {"modified_file"}},
    "insert_before_pat": {"in": {"file","pattern","content"}, "out": {"modified_file"}},
    "replace_range":     {"in": {"file","start","end","content"}, "out": {"modified_file"}},
    "delete_lines":      {"in": {"file","start","end"}, "out": {"modified_file"}},
    "delete_pattern":    {"in": {"file","pattern"}, "out": {"modified_file"}},
    "extract_regex":     {"in": {"file","pat1","pat2"}, "out": {"extracted_text"}},
    "duplicate_within":  {"in": {"file","start","end","target_line"}, "out": {"modified_file"}},
    "swap_blocks":       {"in": {"file","s1","e1","s2","e2"}, "out": {"modified_file"}},
    "split_file":        {"in": {"file","split_line"}, "out": {"file1","file2"}},
    "merge_files":       {"in": {"file1","file2"}, "out": {"merged_file"}},
}

OUTPUT_TYPES = {
    "modified_file": "file",
    "modified_target": "file",
    "extracted_text": "content",
    "file1": "file",
    "file2": "file",
    "merged_file": "file",
}

INPUT_TYPES = {
    "file": "file",
    "target": "file",
    "content": "content",
    "file1": "file",
    "file2": "file",
}


def out_type(op, out):
    return OUTPUT_TYPES.get(out, out)


def in_type(op, inp):
    return INPUT_TYPES.get(inp, inp)


def can_chain(a, b):
    a_out = PRIMITIVES[a]["out"]
    b_in = PRIMITIVES[b]["in"]

    for o in a_out:
        ot = OUTPUT_TYPES.get(o, o)
        for i in b_in:
            it = INPUT_TYPES.get(i, i)
            if ot == it:
                return True
    return False


def build_chain(a, b, c=None, d=None, e=None):
    parts = [a, b]
    if c: parts.append(c)
    if d: parts.append(d)
    if e: parts.append(e)
    return "->".join(parts)


prims = list(PRIMITIVES.keys())

# Precompute adjacency map (removes repeated can_chain calls)
adj = {p: [] for p in prims}
for a in prims:
    for b in prims:
        if a != b and can_chain(a, b):
            adj[a].append(b)

db = sqlite3.connect("/tmp/pipeline_graph.db")
cur = db.cursor()

cur.execute("DROP TABLE IF EXISTS pipelines")

cur.execute("""
CREATE TABLE pipelines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    depth INTEGER NOT NULL,
    step1 TEXT NOT NULL,
    step2 TEXT NOT NULL,
    step3 TEXT,
    step4 TEXT,
    step5 TEXT,
    chain TEXT NOT NULL,
    useful INTEGER DEFAULT NULL,
    category TEXT DEFAULT NULL,
    tested INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    fail_count INTEGER DEFAULT 0,
    date_created TEXT DEFAULT CURRENT_TIMESTAMP
)
""")

cur.execute("CREATE INDEX idx_depth ON pipelines(depth)")
cur.execute("CREATE INDEX idx_useful ON pipelines(useful)")
cur.execute("CREATE INDEX idx_category ON pipelines(category)")

batch = []
count = 0
t0 = time.time()

BATCH_SIZE = 5000

def flush():
    global batch
    if batch:
        cur.executemany(
            """INSERT INTO pipelines(depth,step1,step2,step3,step4,step5,chain)
               VALUES(?,?,?,?,?,?,?)""",
            batch
        )
        batch = []


for a in prims:
    for b in adj[a]:
        batch.append((2, a, b, None, None, None, build_chain(a, b)))
        count += 1

        for c in adj[b]:
            if c in (a, b):
                continue

            batch.append((3, a, b, c, None, None, build_chain(a, b, c)))
            count += 1

            for d in adj[c]:
                if d in (a, b, c):
                    continue

                batch.append((4, a, b, c, d, None, build_chain(a, b, c, d)))
                count += 1

                for e in adj[d]:
                    if e in (a, b, c, d):
                        continue

                    batch.append((5, a, b, c, d, e, build_chain(a, b, c, d, e)))
                    count += 1

                if len(batch) >= BATCH_SIZE:
                    flush()

        if len(batch) >= BATCH_SIZE:
            flush()

flush()

db.commit()

elapsed = time.time() - t0

cur.execute("SELECT depth, COUNT(*) FROM pipelines GROUP BY depth ORDER BY depth")
rows = cur.fetchall()

print(f"Done in {elapsed:.2f}s")
print(f"Total pipelines: {count}")

for depth, cnt in rows:
    print(f"depth {depth}: {cnt}")

db.close()