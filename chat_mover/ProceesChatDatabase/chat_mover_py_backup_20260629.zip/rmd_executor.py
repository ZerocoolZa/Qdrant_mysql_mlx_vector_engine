#!/usr/bin/env python3
#[@GHOST]{file_path="/Users/wws/Qdrant_mysql_mlx_vector_engine/chat_mover/rmd_executor.py"
# date="2026-06-28" author="Cascade" session_id="rmd-executor"
# context="RMD Executor: standalone script that finds, extracts, and runs any [@RUNNABLE] tag in a markdown file. Supports multiple versions, binaries and Python source."}
#[@VBSTYLE]{standard="VBStyle" version="1" rules="PascalCase UPPERCASE Tuple3 Run dispatch"}
#[@FILEID]{id="rmd_executor.py" domain="ChatMover" authority="RmdExecutor"}
#[@SUMMARY]{summary="RMD Executor: reads any .rmd.md file, finds all [@RUNNABLE] tags, extracts binary or Python source, runs it. Supports version selection, listing, and verification."}
#[@CLASS]{class="RmdExecutor" domain="ChatMover" authority="single"}
#[@METHOD]{method="Run" type="dispatch"}
#[@METHOD]{method="list_runnables" type="command"}
#[@METHOD]{method="execute" type="command"}
#[@METHOD]{method="extract" type="command"}
#[@METHOD]{method="verify" type="command"}
#[@METHOD]{method="_p" type="helper"}
#[@METHOD]{method="read_state" type="command"}
#[@METHOD]{method="set_config" type="command"}
#[@METHOD]{method="__init__" type="ctor"}

import os
import re
import sys
import base64
import hashlib
import zlib
import platform
import tempfile
import subprocess

RUNNABLE_PATTERN = r'#\[@RUNNABLE\]\{(.*?)\}\s*```(\w+)\n(.*?)\n```\s*(?:#\[@/RUNNABLE\])?'
RUNNABLE_PATTERN_LEGACY = r'#\[@RUNNABLE\]\{(.*?)\}\s*```base64\n(.*?)\n```'


class RmdExecutor:
    """Universal executor for RMD (Runnable Markdown Document) files."""

    def __init__(self, mem=None, db=None, param=None):
        self.state = {
            "config": {
                "verify_md5": True,
                "cleanup_temp": True,
                "python_cmd": "python3",
            },
            "md_path": None,
            "runnables": [],
            "memunit": mem,
            "db_manager": db,
        }
        if param:
            for key, value in param.items():
                self.state["config"][key] = value

    def Run(self, command, params=None):
        params = params or {}
        if command == "list":
            return self.ListRunnables(params)
        elif command == "execute":
            return self.Execute(params)
        elif command == "extract":
            return self.Extract(params)
        elif command == "verify":
            return self.Verify(params)
        elif command == "read_state":
            return self.read_state(params)
        elif command == "set_config":
            return self.set_config(params)
        return (0, None, ("UNKNOWN_COMMAND", "Unknown command: " + str(command), 0))

    def _p(self, params, key, default=None):
        if not params:
            return default
        return params.get(key, default)

    def read_state(self, params=None):
        return (1, dict(self.state), None)

    def set_config(self, params):
        params = params or {}
        for key, value in params.items():
            self.state["config"][key] = value
        return (1, dict(self.state["config"]), None)

    def _parse_runnables(self, md_path):
        if not os.path.isfile(md_path):
            return (0, None, ("FILE_NOT_FOUND", "File not found: " + md_path, 0))
        try:
            with open(md_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            return (0, None, ("READ_ERROR", str(exc), 0))

        runnables = []
        for m in re.finditer(RUNNABLE_PATTERN, content, re.DOTALL):
            tag_body = m.group(1)
            lang = m.group(2)
            data = m.group(3).strip()
            fields = self._parse_fields(tag_body)
            fields["lang"] = lang
            fields["data"] = data
            fields["index"] = len(runnables)
            runnables.append(fields)

        if not runnables:
            for m in re.finditer(RUNNABLE_PATTERN_LEGACY, content, re.DOTALL):
                tag_body = m.group(1)
                data = m.group(2).strip()
                fields = self._parse_fields(tag_body)
                fields["lang"] = "base64"
                fields["data"] = data
                fields["index"] = len(runnables)
                runnables.append(fields)

        self.state["md_path"] = md_path
        self.state["runnables"] = runnables
        return (1, runnables, None)

    def _parse_fields(self, tag_body):
        fields = {}
        for fm in re.finditer(r'(\w+)="([^"]*)"', tag_body):
            fields[fm.group(1)] = fm.group(2)
        for fm in re.finditer(r'(\w+)=(\d+)', tag_body):
            fields[fm.group(1)] = fm.group(2)
        return fields

    def ListRunnables(self, params):
        md_path = self._p(params, "md_path")
        if not md_path:
            return (0, None, ("MISSING_PARAM", "md_path required", 0))
        rv = self._parse_runnables(md_path)
        if rv[0] != 1:
            return rv
        runnables = rv[1]
        listing = []
        for r in runnables:
            entry = {
                "index": r["index"],
                "name": r.get("binary", r.get("name", "unnamed")),
                "version": r.get("version", "1"),
                "format": r.get("format", "base64"),
                "lang": r.get("lang", "base64"),
                "size": r.get("size", "?"),
                "platform": r.get("platform", "?"),
                "arch": r.get("arch", "?"),
                "cmd": r.get("cmd", "?"),
                "md5": r.get("md5", "?")[:12],
            }
            listing.append(entry)
        return (1, listing, None)

    def Execute(self, params):
        md_path = self._p(params, "md_path")
        version = self._p(params, "version")
        name = self._p(params, "name")
        index = self._p(params, "index", 0)
        args = self._p(params, "args", [])
        if not md_path:
            return (0, None, ("MISSING_PARAM", "md_path required", 0))

        rv = self._parse_runnables(md_path)
        if rv[0] != 1:
            return rv
        runnables = rv[1]
        if not runnables:
            return (0, None, ("NO_RUNNABLE", "No [@RUNNABLE] tags found in markdown", 0))

        target = None
        if version is not None:
            for r in runnables:
                if r.get("version", "1") == str(version):
                    target = r
                    break
        elif name is not None:
            for r in runnables:
                if r.get("binary", r.get("name", "")) == name:
                    target = r
                    break
        else:
            if index < len(runnables):
                target = runnables[index]

        if target is None:
            return (0, None, ("NOT_FOUND",
                "No runnable matching version=%s name=%s index=%d" % (
                    version, name, index), 0))

        return self._run_target(target, args)

    def _run_target(self, target, args):
        lang = target.get("lang", "base64")
        binary_name = target.get("binary", target.get("name", "rmd_binary"))
        run_cmd = target.get("cmd", "")
        data = target.get("data", "")

        if lang in ("base64", "binary"):
            compression = target.get("compression", "")
            try:
                raw_data = base64.b64decode(data)
            except Exception as exc:
                return (0, None, ("DECODE_ERROR", str(exc), 0))

            if compression == "zlib":
                try:
                    binary_data = zlib.decompress(raw_data)
                except Exception as exc:
                    return (0, None, ("DECOMPRESS_ERROR", str(exc), 0))
            else:
                binary_data = raw_data

            if self.state["config"]["verify_md5"]:
                expected_md5 = target.get("md5", "")
                actual_md5 = hashlib.md5(binary_data).hexdigest()
                if expected_md5 and actual_md5 != expected_md5:
                    return (0, None, ("MD5_MISMATCH",
                        "Expected %s, got %s" % (expected_md5, actual_md5), 0))

            tmpdir = tempfile.mkdtemp(prefix="rmd_exec_")
            binary_path = os.path.join(tmpdir, binary_name)
            with open(binary_path, "wb") as f:
                f.write(binary_data)
            os.chmod(binary_path, 0o755)

            if run_cmd:
                cmd_parts = run_cmd.replace("./" + binary_name, binary_path).split()
            else:
                cmd_parts = [binary_path]
            cmd_parts.extend(args)

            try:
                result = subprocess.run(cmd_parts, capture_output=False)
                return (1, {
                    "binary_path": binary_path,
                    "returncode": result.returncode,
                    "cmd": " ".join(cmd_parts),
                }, None)
            except Exception as exc:
                return (0, None, ("RUN_ERROR", str(exc), 0))

        elif lang in ("python", "python3", "py"):
            compression = target.get("compression", "")
            try:
                raw_data = base64.b64decode(data)
            except Exception as exc:
                return (0, None, ("DECODE_ERROR", str(exc), 0))

            if compression == "zlib":
                try:
                    source_text = zlib.decompress(raw_data).decode("utf-8")
                except Exception as exc:
                    return (0, None, ("DECOMPRESS_ERROR", str(exc), 0))
            else:
                source_text = data

            tmpdir = tempfile.mkdtemp(prefix="rmd_py_")
            script_path = os.path.join(tmpdir, binary_name if binary_name.endswith(".py") else binary_name + ".py")
            with open(script_path, "w") as f:
                f.write(source_text)

            python_cmd = self.state["config"]["python_cmd"]
            cmd_parts = [python_cmd, script_path]
            cmd_parts.extend(args)

            try:
                result = subprocess.run(cmd_parts, capture_output=False)
                return (1, {
                    "script_path": script_path,
                    "returncode": result.returncode,
                    "cmd": " ".join(cmd_parts),
                }, None)
            except Exception as exc:
                return (0, None, ("RUN_ERROR", str(exc), 0))

        elif lang in ("bash", "sh", "shell"):
            tmpdir = tempfile.mkdtemp(prefix="rmd_sh_")
            script_path = os.path.join(tmpdir, binary_name if binary_name.endswith(".sh") else binary_name + ".sh")
            with open(script_path, "w") as f:
                f.write(data)
            os.chmod(script_path, 0o755)

            cmd_parts = ["bash", script_path]
            cmd_parts.extend(args)

            try:
                result = subprocess.run(cmd_parts, capture_output=False)
                return (1, {
                    "script_path": script_path,
                    "returncode": result.returncode,
                    "cmd": " ".join(cmd_parts),
                }, None)
            except Exception as exc:
                return (0, None, ("RUN_ERROR", str(exc), 0))

        else:
            return (0, None, ("UNSUPPORTED_LANG",
                "Language '%s' not supported. Use base64, python, or bash." % lang, 0))

    def Extract(self, params):
        md_path = self._p(params, "md_path")
        output_path = self._p(params, "output_path")
        version = self._p(params, "version")
        index = self._p(params, "index", 0)
        if not md_path:
            return (0, None, ("MISSING_PARAM", "md_path required", 0))

        rv = self._parse_runnables(md_path)
        if rv[0] != 1:
            return rv
        runnables = rv[1]
        if not runnables:
            return (0, None, ("NO_RUNNABLE", "No [@RUNNABLE] tags found", 0))

        target = None
        if version is not None:
            for r in runnables:
                if r.get("version", "1") == str(version):
                    target = r
                    break
        else:
            if index < len(runnables):
                target = runnables[index]

        if target is None:
            return (0, None, ("NOT_FOUND", "Runnable not found", 0))

        lang = target.get("lang", "base64")
        binary_name = target.get("binary", "rmd_binary")
        data = target.get("data", "")

        if not output_path:
            output_path = os.path.join(tempfile.gettempdir(), binary_name)

        compression = target.get("compression", "")
        if lang in ("base64", "binary"):
            raw_data = base64.b64decode(data)
            if compression == "zlib":
                binary_data = zlib.decompress(raw_data)
            else:
                binary_data = raw_data
            with open(output_path, "wb") as f:
                f.write(binary_data)
            os.chmod(output_path, 0o755)
        else:
            if compression == "zlib":
                raw_data = base64.b64decode(data)
                source_text = zlib.decompress(raw_data).decode("utf-8")
            else:
                source_text = data
            with open(output_path, "w") as f:
                f.write(source_text)

        return (1, {"output_path": output_path, "size": os.path.getsize(output_path)}, None)

    def Verify(self, params):
        md_path = self._p(params, "md_path")
        if not md_path:
            return (0, None, ("MISSING_PARAM", "md_path required", 0))
        rv = self._parse_runnables(md_path)
        if rv[0] != 1:
            return rv
        runnables = rv[1]
        results = []
        for r in runnables:
            lang = r.get("lang", "base64")
            expected_md5 = r.get("md5", "")
            data = r.get("data", "")
            if lang in ("base64", "binary"):
                try:
                    raw_data = base64.b64decode(data)
                    if r.get("compression", "") == "zlib":
                        binary_data = zlib.decompress(raw_data)
                    else:
                        binary_data = raw_data
                    actual_md5 = hashlib.md5(binary_data).hexdigest()
                    ok = (not expected_md5) or (actual_md5 == expected_md5)
                    results.append({
                        "name": r.get("binary", "unnamed"),
                        "version": r.get("version", "1"),
                        "expected_md5": expected_md5,
                        "actual_md5": actual_md5,
                        "verified": ok,
                        "size": len(binary_data),
                    })
                except Exception as exc:
                    results.append({
                        "name": r.get("binary", "unnamed"),
                        "version": r.get("version", "1"),
                        "error": str(exc),
                        "verified": False,
                    })
            else:
                results.append({
                    "name": r.get("binary", "unnamed"),
                    "version": r.get("version", "1"),
                    "lang": lang,
                    "verified": True,
                    "size": len(data),
                })
        return (1, results, None)


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="RMD Executor — Runnable Markdown Document executor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List all runnables in an RMD file
  python3 rmd_executor.py list pipeline.rmd.md

  # Run the first runnable
  python3 rmd_executor.py run pipeline.rmd.md

  # Run version 2
  python3 rmd_executor.py run pipeline.rmd.md --version 2

  # Run with arguments
  python3 rmd_executor.py run pipeline.rmd.md --args "search_term" "--radius" "50"

  # Extract binary without running
  python3 rmd_executor.py extract pipeline.rmd.md --output ./my_binary

  # Verify all embedded binaries
  python3 rmd_executor.py verify pipeline.rmd.md
        """)
    sub = parser.add_subparsers(dest="command")

    list_p = sub.add_parser("list", help="List all [@RUNNABLE] tags in markdown")
    list_p.add_argument("md_path", help="Path to .rmd.md file")

    run_p = sub.add_parser("run", help="Extract and execute a runnable")
    run_p.add_argument("md_path", help="Path to .rmd.md file")
    run_p.add_argument("--version", help="Run specific version (e.g. 2)")
    run_p.add_argument("--name", help="Run by name")
    run_p.add_argument("--index", type=int, default=0, help="Run by index (default: 0)")
    run_p.add_argument("--args", nargs="*", default=[], help="Arguments to pass")

    ext_p = sub.add_parser("extract", help="Extract binary without running")
    ext_p.add_argument("md_path", help="Path to .rmd.md file")
    ext_p.add_argument("--version", help="Extract specific version")
    ext_p.add_argument("--index", type=int, default=0, help="Extract by index")
    ext_p.add_argument("--output", help="Output path")

    ver_p = sub.add_parser("verify", help="Verify MD5 of all embedded binaries")
    ver_p.add_argument("md_path", help="Path to .rmd.md file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    executor = RmdExecutor()

    if args.command == "list":
        rv = executor.Run("list", {"md_path": args.md_path})
        if rv[0] == 1:
            items = rv[1]
            if not items:
                print("No [@RUNNABLE] tags found.", file=sys.stderr)
            else:
                print("Found %d runnable(s):" % len(items), file=sys.stderr)
                for item in items:
                    print("  [%d] %s v%s  %s bytes  %s/%s  md5=%s..." % (
                        item["index"],
                        item["name"],
                        item["version"],
                        item["size"],
                        item["platform"],
                        item["arch"],
                        item["md5"],
                    ), file=sys.stderr)
        else:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)

    elif args.command == "run":
        rv = executor.Run("execute", {
            "md_path": args.md_path,
            "version": args.version,
            "name": args.name,
            "index": args.index,
            "args": args.args,
        })
        if rv[0] != 1:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)

    elif args.command == "extract":
        rv = executor.Run("extract", {
            "md_path": args.md_path,
            "version": args.version,
            "index": args.index,
            "output_path": args.output,
        })
        if rv[0] == 1:
            print("Extracted: %s (%d bytes)" % (rv[1]["output_path"], rv[1]["size"]), file=sys.stderr)
        else:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)

    elif args.command == "verify":
        rv = executor.Run("verify", {"md_path": args.md_path})
        if rv[0] == 1:
            for item in rv[1]:
                status = "OK" if item.get("verified") else "FAIL"
                print("  [%s] %s v%s  %s" % (
                    status,
                    item.get("name", "?"),
                    item.get("version", "?"),
                    item.get("actual_md5", "?")[:12],
                ), file=sys.stderr)
        else:
            print("ERROR: %s" % str(rv[2]), file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
