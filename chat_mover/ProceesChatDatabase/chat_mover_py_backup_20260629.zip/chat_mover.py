#!/usr/bin/env python3
"""
Chat Mover — Chat-to-Database Pipeline

Moves chat conversations from MySQL, Disk, or SQLite sources into a
unified Chat_History MySQL database with optional Qdrant embeddings.

Pipeline: Source -> Classify -> Filter -> Parse -> Import -> Embed -> Verify
"""

import argparse
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import sys
import time
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

try:
    import mysql.connector
    from mysql.connector import errors as mysql_errors
    HAS_MYSQL = True
except ImportError:
    HAS_MYSQL = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from Config import cfg

# ─── Constants ─────────────────────────────────────────────────────────────

PIPELINE_VERSION = cfg.PIPELINE_VERSION
DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "Config.py")
LOCK_FILE = cfg.LOCK_FILE
CLASSIFICATION_FILE = os.path.join(os.path.dirname(__file__), "pipeline_classification.json")

ROLE_PATTERNS_MD = [
    re.compile(r'^\*\*User:\*\*\s*', re.IGNORECASE),
    re.compile(r'^\*\*Assistant:\*\*\s*', re.IGNORECASE),
    re.compile(r'^## User\s*$', re.IGNORECASE),
    re.compile(r'^## Assistant\s*$', re.IGNORECASE),
    re.compile(r'^### User\s*$', re.IGNORECASE),
    re.compile(r'^### Assistant\s*$', re.IGNORECASE),
    re.compile(r'^### Planner Response\s*$', re.IGNORECASE),
    re.compile(r'^> User:\s*', re.IGNORECASE),
    re.compile(r'^> Assistant:\s*', re.IGNORECASE),
    re.compile(r'^Human:\s*', re.IGNORECASE),
    re.compile(r'^Assistant:\s*', re.IGNORECASE),
    re.compile(r'^=== MESSAGE \d+ - (User|Assistant|System|Planner) ===', re.IGNORECASE),
]

ROLE_MAP = {
    'user': 'user',
    'human': 'user',
    'assistant': 'assistant',
    'planner': 'assistant',
    'planner response': 'assistant',
    'system': 'system',
}

CODE_FENCE_RE = re.compile(r'^```\S*$')

# Schema SQL now lives in Config.py — use cfg.GetSchemaSql()


# ─── Logging ───────────────────────────────────────────────────────────────

def setup_logging(config):
    """Set up rotating file + console logging."""
    logger = logging.getLogger('chat_mover')
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    fmt = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(step)s] %(message)s',
                            datefmt='%Y-%m-%d %H:%M:%S')

    class StepFilter(logging.Filter):
        def __init__(self):
            self.step = 'init'

        def filter(self, record):
            if not hasattr(record, 'step'):
                record.step = self.step
            return True

    step_filter = StepFilter()
    logger.addFilter(step_filter)

    fh = RotatingFileHandler(
        config.LOG_FILE, maxBytes=config.LOG_MAX_BYTES,
        backupCount=config.LOG_BACKUP_COUNT
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    fh.addFilter(step_filter)
    logger.addHandler(fh)

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    ch.addFilter(step_filter)
    logger.addHandler(ch)

    return logger, step_filter


# ─── MySQL Connection ──────────────────────────────────────────────────────

class MySQLConn:
    """Manages MySQL connections with reconnect support."""

    def __init__(self, host, port, user, password, database=None):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.conn = None

    def connect(self, database=None):
        db = database or self.database
        self.conn = mysql.connector.connect(
            host=self.host, port=self.port,
            user=self.user, password=self.password,
            database=db, charset='utf8mb4',
            autocommit=False, connection_timeout=10
        )
        return self.conn

    def reconnect(self):
        if self.conn and self.conn.is_connected():
            try:
                self.conn.ping(reconnect=True, attempts=3, delay=5)
                return self.conn
            except Exception:
                pass
        return self.connect(self.database)

    def cursor(self, buffered=False):
        if not self.conn or not self.conn.is_connected():
            self.reconnect()
        return self.conn.cursor(buffered=buffered)

    def commit(self):
        if self.conn and self.conn.is_connected():
            self.conn.commit()

    def rollback(self):
        if self.conn and self.conn.is_connected():
            self.conn.rollback()

    def close(self):
        if self.conn and self.conn.is_connected():
            self.conn.close()

    def test(self):
        """Quick connection test."""
        try:
            c = self.connect()
            cur = c.cursor()
            cur.execute('SELECT 1')
            cur.fetchone()
            cur.close()
            return True
        except Exception:
            return False


# ─── Schema Creation ───────────────────────────────────────────────────────

def create_schema(mysql_conn, dest_db, logger):
    """Create destination database and tables if they don't exist."""
    logger.info(f"Creating schema for {dest_db}...", extra={'step': '0.5'})

    conn = mysql_conn.connect()
    cur = conn.cursor()

    try:
        statements = cfg.GetSchemaSql().split(';')
        for stmt in statements:
            stmt = stmt.strip()
            if stmt:
                cur.execute(stmt)
        conn.commit()
        logger.info(f"Schema ready: {dest_db} (sessions, messages, prompts, pipeline_state, error_knowledge)")
    except Exception as e:
        logger.error(f"Schema creation failed: {e}", extra={'step': '0.5'})
        raise
    finally:
        cur.close()


# ─── Classification ────────────────────────────────────────────────────────

def classify_content(content, filename=''):
    """Classify content as chat, doc, or other."""
    if not content or len(content.strip()) == 0:
        return 'other'

    if filename.endswith('.json'):
        return classify_json(content)
    else:
        return classify_md(content)


def classify_md(content):
    """Classify markdown content."""
    in_code_fence = False
    role_count = 0
    roles_found = set()

    for line in content.split('\n'):
        stripped = line.strip()

        if CODE_FENCE_RE.match(stripped):
            in_code_fence = not in_code_fence
            continue

        if in_code_fence:
            continue

        for pattern in ROLE_PATTERNS_MD:
            m = pattern.match(stripped)
            if m:
                role_text = m.group(1).lower() if m.lastindex else ''
                if not role_text:
                    role_text = stripped.lower().replace(':', '').replace('*', '').replace('#', '').replace('>', '').strip()
                role = ROLE_MAP.get(role_text, 'unknown')
                if role in ('user', 'assistant', 'system'):
                    roles_found.add(role)
                role_count += 1
                break

    if len(roles_found) >= 2 and role_count >= 2:
        return 'chat'
    elif role_count >= 1:
        return 'chat'
    else:
        return 'doc'


def classify_json(content):
    """Classify JSON content."""
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return 'other'

    messages = None
    if isinstance(data, list):
        messages = data
    elif isinstance(data, dict):
        if 'messages' in data:
            messages = data['messages']
        elif 'mapping' in data:
            messages = []
            for node_id, node in data['mapping'].items():
                msg = node.get('message', {})
                if msg and 'content' in msg and 'author' in msg:
                    role = msg['author'].get('role', '')
                    if role in ('user', 'assistant', 'system'):
                        messages.append({'role': role})
        elif 'conversation' in data:
            messages = data['conversation']

    if not messages or len(messages) < 2:
        return 'other'

    roles = set()
    for msg in messages:
        if isinstance(msg, dict):
            role = msg.get('role', msg.get('sender', ''))
            if role:
                roles.add(role.lower())

    if len(roles) >= 2:
        return 'chat'
    elif len(roles) >= 1:
        return 'chat'
    return 'doc'


def should_skip_filename(filename, skip_set):
    """Check if filename should be skipped."""
    basename = os.path.basename(filename)
    if basename.startswith('.'):
        return True
    if basename in skip_set:
        return True
    if basename.startswith('PLAN') or basename.startswith('TODO') or basename.startswith('NOTES'):
        return True
    if basename.endswith('.min.json') or basename.endswith('.lock.json'):
        return True
    return False


def should_skip_path(filepath, skip_paths):
    """Check if path contains skipped directories."""
    parts = filepath.replace('\\', '/').split('/')
    for skip in skip_paths:
        if skip in parts:
            return True
    return False


# ─── Source Readers ────────────────────────────────────────────────────────

def read_mysql_sources(mysql_conn, source_tables, logger, max_rows=50000):
    """Read content from MySQL source tables."""
    items = []
    for src in source_tables:
        db = src['database']
        table = src['table']
        fname_col = src.get('filename_col', 'filename')
        content_col = src.get('content_col', 'content')
        date_col = src.get('date_col', 'created_at')

        logger.info(f"Reading {db}.{table}...", extra={'step': '1'})
        try:
            conn = mysql_conn.connect(db)
            cur = conn.cursor(buffered=False)

            cur.execute(f"SELECT COUNT(*) FROM {table}")
            total = cur.fetchone()[0]
            logger.info(f"  {db}.{table}: {total} rows", extra={'step': '1'})

            if total > max_rows:
                logger.warning(f"  Large table ({total} rows), sampling first {max_rows}", extra={'step': '1'})

            cur.close()
            cur = conn.cursor(buffered=False)
            cur.execute(f"SELECT id, {fname_col}, {content_col}, {date_col} FROM {table} LIMIT %s", (max_rows,))

            for row in cur:
                row_id, fname, content, date_val = row
                if content is None:
                    continue
                items.append({
                    'source_db': db,
                    'source_table': table,
                    'source_format': '.md' if (fname or '').endswith('.md') else '.json' if (fname or '').endswith('.json') else '.md',
                    'row_id': row_id,
                    'filename': fname or f'{table}_{row_id}',
                    'content': content,
                    'date': str(date_val) if date_val else None,
                })

            cur.close()
        except Exception as e:
            logger.error(f"  Failed to read {db}.{table}: {e}", extra={'step': '1'})

    return items


def read_disk_sources(folders, skip_filenames, skip_paths, logger):
    """Read .md and .json files from disk folders."""
    items = []
    for folder in folders:
        folder = os.path.expanduser(folder)
        if not os.path.isdir(folder):
            logger.warning(f"Folder not found: {folder}", extra={'step': '1'})
            continue

        logger.info(f"Scanning disk: {folder}", extra={'step': '1'})
        count = 0

        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in skip_paths and not d.startswith('.')]

            for fname in files:
                if not (fname.endswith('.md') or fname.endswith('.json')):
                    continue
                if should_skip_filename(fname, skip_filenames):
                    continue

                filepath = os.path.join(root, fname)
                if should_skip_path(filepath, skip_paths):
                    continue

                try:
                    stat = os.stat(filepath)
                    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                        content = f.read()

                    items.append({
                        'source_db': 'disk',
                        'source_table': folder,
                        'source_format': '.md' if fname.endswith('.md') else '.json',
                        'row_id': 0,
                        'filename': fname,
                        'content': content,
                        'date': str(stat.st_mtime),
                        'file_path': filepath,
                        'file_created': str(getattr(stat, 'st_birthtime', stat.st_mtime)),
                    })
                    count += 1
                except Exception as e:
                    logger.warning(f"  Skip {fname}: {e}", extra={'step': '1'})

        logger.info(f"  {folder}: {count} files", extra={'step': '1'})

    return items


def read_sqlite_sources(sources, logger, max_rows=50000):
    """Read chat content from SQLite databases.

    Each source entry is a dict:
        {
          "db_path": "/path/to/file.db",
          "tables": [
            {
              "table": "qa_pairs",
              "id_col": "id",
              "content_col": "question",      # primary content column
              "answer_col": "answer",          # optional: for qa_pairs format
              "role_col": "role",              # optional: for session_messages format
              "session_col": "session_id",     # optional: groups rows into sessions
              "date_col": "created_at",
              "filename_col": null,            # optional: column for filename
              "format": "qa_pairs",            # raw_content | qa_pairs | session_messages
              "filename_prefix": "qa_"         # optional prefix for generated filenames
            }
          ]
        }

    Formats:
      raw_content      — single content_col, used directly (like MySQL source)
      qa_pairs         — question (content_col) + answer (answer_col) → markdown chat
      session_messages — rows grouped by session_col, role_col + content_col → markdown chat
    """
    items = []

    for src in sources:
        db_path = os.path.expanduser(src.get('db_path', ''))
        if not db_path or not os.path.isfile(db_path):
            logger.warning(f"SQLite DB not found: {db_path}", extra={'step': '1'})
            continue

        db_name = os.path.basename(db_path)
        tables = src.get('tables', [])

        if not tables:
            # Auto-detect chat-like tables
            tables = _auto_detect_sqlite_tables(db_path, logger)

        if not tables:
            logger.warning(f"  No chat-like tables found in {db_name}", extra={'step': '1'})
            continue

        logger.info(f"Reading SQLite: {db_name}", extra={'step': '1'})

        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            for tbl_cfg in tables:
                table = tbl_cfg.get('table', '')
                if not table:
                    continue

                fmt = tbl_cfg.get('format', 'raw_content')
                id_col = tbl_cfg.get('id_col', 'id')
                content_col = tbl_cfg.get('content_col', 'content')
                answer_col = tbl_cfg.get('answer_col', 'answer')
                role_col = tbl_cfg.get('role_col', 'role')
                session_col = tbl_cfg.get('session_col', 'session_id')
                date_col = tbl_cfg.get('date_col', 'created_at')
                fname_col = tbl_cfg.get('filename_col')
                fname_prefix = tbl_cfg.get('filename_prefix', f'{table}_')

                # Verify table exists
                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
                if not cur.fetchone():
                    logger.warning(f"  Table not found: {db_name}.{table}", extra={'step': '1'})
                    continue

                # Get column names for validation
                cur.execute(f"PRAGMA table_info({table})")
                col_names = {row[1] for row in cur.fetchall()}

                # Validate required columns exist
                required = {id_col, content_col}
                if fmt == 'qa_pairs':
                    required.add(answer_col)
                if fmt == 'session_messages':
                    required.update({role_col, session_col})
                if date_col and date_col not in ('', 'null', 'None'):
                    required.add(date_col)

                missing = required - col_names
                if missing:
                    logger.warning(f"  {db_name}.{table}: missing columns {missing}, skipping",
                                   extra={'step': '1'})
                    continue

                if fmt == 'session_messages':
                    table_items = _read_sqlite_session_messages(
                        cur, conn, db_name, table, tbl_cfg, max_rows, logger
                    )
                elif fmt == 'qa_pairs':
                    table_items = _read_sqlite_qa_pairs(
                        cur, db_name, table, tbl_cfg, max_rows, logger
                    )
                else:
                    table_items = _read_sqlite_raw_content(
                        cur, db_name, table, tbl_cfg, max_rows, logger
                    )

                items.extend(table_items)
                logger.info(f"  {db_name}.{table}: {len(table_items)} items ({fmt})",
                            extra={'step': '1'})

            cur.close()
            conn.close()

        except Exception as e:
            logger.error(f"  Failed to read SQLite {db_name}: {e}", extra={'step': '1'})

    return items


def _auto_detect_sqlite_tables(db_path, logger):
    """Auto-detect chat-like tables in a SQLite database by examining schema."""
    detected = []
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        table_names = [row[0] for row in cur.fetchall()]

        for tname in table_names:
            cur.execute(f"PRAGMA table_info({tname})")
            cols = {row[1] for row in cur.fetchall()}

            # qa_pairs pattern: has question + answer columns
            q_col = next((c for c in cols if c in ('question', 'prompt', 'query')), None)
            a_col = next((c for c in cols if c in ('answer', 'response', 'reply')), None)
            if q_col and a_col:
                detected.append({
                    'table': tname,
                    'id_col': 'id' if 'id' in cols else list(cols)[0],
                    'content_col': q_col,
                    'answer_col': a_col,
                    'date_col': 'created_at' if 'created_at' in cols else None,
                    'format': 'qa_pairs',
                    'filename_prefix': f'{tname}_',
                })
                continue

            # session_messages pattern: has role + content + session_id
            r_col = next((c for c in cols if c in ('role', 'sender', 'author')), None)
            c_col = next((c for c in cols if c in ('content', 'text', 'message')), None)
            s_col = next((c for c in cols if c in ('session_id', 'conversation_id', 'chat_id')), None)
            if r_col and c_col and s_col:
                detected.append({
                    'table': tname,
                    'id_col': 'id' if 'id' in cols else list(cols)[0],
                    'content_col': c_col,
                    'role_col': r_col,
                    'session_col': s_col,
                    'date_col': 'created_at' if 'created_at' in cols else None,
                    'format': 'session_messages',
                    'filename_prefix': f'{tname}_',
                })
                continue

            # raw_content pattern: has a content/text/message column
            if c_col:
                detected.append({
                    'table': tname,
                    'id_col': 'id' if 'id' in cols else list(cols)[0],
                    'content_col': c_col,
                    'date_col': 'created_at' if 'created_at' in cols else None,
                    'format': 'raw_content',
                    'filename_prefix': f'{tname}_',
                })

        cur.close()
        conn.close()

        if detected:
            logger.info(f"  Auto-detected {len(detected)} chat-like table(s): "
                        f"{[d['table'] for d in detected]}", extra={'step': '1'})

    except Exception as e:
        logger.warning(f"  Auto-detect failed: {e}", extra={'step': '1'})

    return detected


def _read_sqlite_raw_content(cur, db_name, table, cfg, max_rows, logger):
    """Read rows with a single content column — same format as MySQL source."""
    items = []
    id_col = cfg.get('id_col', 'id')
    content_col = cfg.get('content_col', 'content')
    date_col = cfg.get('date_col', 'created_at')
    fname_col = cfg.get('filename_col')
    fname_prefix = cfg.get('filename_prefix', f'{table}_')
    fmt_ext = cfg.get('source_format', '.md')

    cols = f"{id_col}, {content_col}"
    if date_col:
        cols += f", {date_col}"
    if fname_col:
        cols += f", {fname_col}"

    cur.execute(f"SELECT {cols} FROM {table} LIMIT ?", (max_rows,))
    for row in cur.fetchall():
        row_id = row[0]
        content = row[1]
        if content is None:
            continue
        date_val = row[2] if date_col else None
        fname = row[3] if fname_col else f"{fname_prefix}{row_id}{fmt_ext}"

        items.append({
            'source_db': db_name,
            'source_table': table,
            'source_format': fmt_ext,
            'row_id': row_id,
            'filename': fname,
            'content': str(content),
            'date': str(date_val) if date_val else None,
        })
    return items


def _read_sqlite_qa_pairs(cur, db_name, table, cfg, max_rows, logger):
    """Read question/answer pairs and format as markdown chat sessions."""
    items = []
    id_col = cfg.get('id_col', 'id')
    content_col = cfg.get('content_col', 'question')
    answer_col = cfg.get('answer_col', 'answer')
    date_col = cfg.get('date_col', 'created_at')
    fname_prefix = cfg.get('filename_prefix', f'{table}_')

    cols = f"{id_col}, {content_col}, {answer_col}"
    if date_col:
        cols += f", {date_col}"

    cur.execute(f"SELECT {cols} FROM {table} LIMIT ?", (max_rows,))
    for row in cur.fetchall():
        row_id = row[0]
        question = row[1]
        answer = row[2]
        if question is None and answer is None:
            continue
        date_val = row[3] if date_col else None

        # Format as markdown chat that parse_md_chat can parse
        lines = []
        if question:
            lines.append("**User:**")
            lines.append(str(question).strip())
        if answer:
            lines.append("")
            lines.append("**Assistant:**")
            lines.append(str(answer).strip())
        content = "\n".join(lines)

        items.append({
            'source_db': db_name,
            'source_table': table,
            'source_format': '.md',
            'row_id': row_id,
            'filename': f"{fname_prefix}{row_id}.md",
            'content': content,
            'date': str(date_val) if date_val else None,
        })
    return items


def _read_sqlite_session_messages(cur, conn, db_name, table, cfg, max_rows, logger):
    """Read rows grouped by session_id, each group becomes one chat session."""
    items = []
    id_col = cfg.get('id_col', 'id')
    content_col = cfg.get('content_col', 'content')
    role_col = cfg.get('role_col', 'role')
    session_col = cfg.get('session_col', 'session_id')
    date_col = cfg.get('date_col', 'created_at')
    fname_prefix = cfg.get('filename_prefix', f'{table}_')

    cols = f"{id_col}, {session_col}, {role_col}, {content_col}"
    if date_col:
        cols += f", {date_col}"

    # Group rows by session_col
    sessions = {}
    session_dates = {}
    cur.execute(f"SELECT {cols} FROM {table} LIMIT ?", (max_rows,))
    for row in cur.fetchall():
        row_id = row[0]
        sess_id = row[1]
        role = row[2]
        content = row[3]
        date_val = row[4] if date_col else None

        if content is None:
            continue

        if sess_id not in sessions:
            sessions[sess_id] = []
            session_dates[sess_id] = date_val
        sessions[sess_id].append((row_id, role, content))

    for sess_id, msgs in sessions.items():
        if not msgs:
            continue

        # Format as markdown chat
        lines = []
        for _row_id, role, content in msgs:
            role_norm = ROLE_MAP.get(str(role).lower(), 'system')
            role_label = 'User' if role_norm == 'user' else 'Assistant' if role_norm == 'assistant' else 'System'
            lines.append(f"**{role_label}:**")
            lines.append(str(content).strip())
            lines.append("")
        content = "\n".join(lines).strip()

        items.append({
            'source_db': db_name,
            'source_table': table,
            'source_format': '.md',
            'row_id': sess_id if isinstance(sess_id, int) else 0,
            'filename': f"{fname_prefix}session_{sess_id}.md",
            'content': content,
            'date': str(session_dates.get(sess_id)) if session_dates.get(sess_id) else None,
        })

    return items


# ─── Parsers ───────────────────────────────────────────────────────────────

def parse_md_chat(content):
    """Parse markdown chat content into messages."""
    messages = []
    current_role = None
    current_lines = []
    in_code_fence = False
    seq = 0

    for line in content.split('\n'):
        stripped = line.strip()

        if CODE_FENCE_RE.match(stripped):
            in_code_fence = not in_code_fence
            current_lines.append(line)
            continue

        if in_code_fence:
            current_lines.append(line)
            continue

        matched = False
        for pattern in ROLE_PATTERNS_MD:
            m = pattern.match(stripped)
            if m:
                if current_role is not None:
                    msg_content = '\n'.join(current_lines).strip()
                    if msg_content:
                        messages.append({
                            'role': current_role,
                            'content': msg_content,
                            'sequence': seq,
                        })
                        seq += 1

                role_text = m.group(1).lower() if m.lastindex else ''
                if not role_text:
                    role_text = stripped.lower().replace(':', '').replace('*', '').replace('#', '').replace('>', '').strip()
                current_role = ROLE_MAP.get(role_text, 'unknown')
                current_lines = []
                matched = True
                break

        if not matched:
            current_lines.append(line)

    if current_role is not None:
        msg_content = '\n'.join(current_lines).strip()
        if msg_content:
            messages.append({
                'role': current_role,
                'content': msg_content,
                'sequence': seq,
            })

    return messages


def parse_json_chat(content):
    """Parse JSON chat content into messages."""
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return []

    messages = []
    seq = 0

    if isinstance(data, list):
        for msg in data:
            if isinstance(msg, dict):
                role = msg.get('role', msg.get('sender', ''))
                text = msg.get('content', msg.get('text', ''))
                if role and text:
                    messages.append({
                        'role': ROLE_MAP.get(role.lower(), 'system'),
                        'content': str(text),
                        'sequence': seq,
                    })
                    seq += 1

    elif isinstance(data, dict):
        if 'messages' in data:
            for msg in data['messages']:
                role = msg.get('role', '')
                text = msg.get('content', '')
                if role and text:
                    messages.append({
                        'role': ROLE_MAP.get(role.lower(), 'system'),
                        'content': str(text),
                        'sequence': seq,
                    })
                    seq += 1

        elif 'mapping' in data:
            nodes = []
            for node_id, node in data['mapping'].items():
                msg = node.get('message', {})
                if msg and 'content' in msg:
                    role = msg.get('author', {}).get('role', '')
                    parts = msg['content'].get('parts', [])
                    text = ' '.join(str(p) for p in parts if isinstance(p, str))
                    if role and text:
                        nodes.append((node_id, role.lower(), text))

            nodes.sort(key=lambda x: x[0])
            for _, role, text in nodes:
                messages.append({
                    'role': ROLE_MAP.get(role, 'system'),
                    'content': text,
                    'sequence': seq,
                })
                seq += 1

        elif 'conversation' in data:
            for msg in data['conversation']:
                role = msg.get('sender', msg.get('role', ''))
                text = msg.get('text', msg.get('content', ''))
                if role and text:
                    messages.append({
                        'role': ROLE_MAP.get(role.lower(), 'system'),
                        'content': str(text),
                        'sequence': seq,
                    })
                    seq += 1

    return messages


def parse_chat(item):
    """Parse a chat item into messages list."""
    content = item['content']
    fmt = item.get('source_format', '.md')

    if fmt == '.json':
        return parse_json_chat(content)
    else:
        return parse_md_chat(content)


def extract_session_name(item, messages):
    """Derive session name from filename or first message."""
    fname = item.get('filename', 'unknown')
    name = os.path.splitext(os.path.basename(fname))[0]

    if not name or name == 'unknown':
        for msg in messages:
            if msg['role'] == 'user':
                name = msg['content'][:50].strip()
                break

    if not name:
        name = f"unnamed_{item.get('row_id', 0)}"

    if len(name) > 300:
        name = name[:300]

    return name


def extract_prompts(messages):
    """Extract user prompts from messages."""
    prompts = []
    first_user = True
    for msg in messages:
        if msg['role'] == 'user':
            prompts.append({
                'text': msg['content'],
                'type': 'initial' if first_user else 'follow_up',
            })
            first_user = False
        elif msg['role'] == 'system' and not prompts:
            prompts.append({
                'text': msg['content'],
                'type': 'system',
            })
    return prompts


def compute_content_hash(messages):
    """Compute SHA-256 hash of all message content."""
    combined = '\n'.join(m['content'] for m in messages)
    return hashlib.sha256(combined.encode('utf-8')).hexdigest()


# ─── Importer ──────────────────────────────────────────────────────────────

def validate_session(item, messages, prompts, logger):
    """Validate a parsed session without writing to database.

    Returns a dict with validation results:
      {valid: bool, errors: [str], warnings: [str], session_name: str,
       message_count: int, prompt_count: int, content_hash: str}
    """
    errors = []
    warnings = []
    session_name = extract_session_name(item, messages)
    content_hash = compute_content_hash(messages)

    # Check session structure
    if not session_name:
        errors.append("missing session_name")
    elif len(session_name) > 300:
        errors.append(f"session_name too long ({len(session_name)} chars, max 300)")

    if not messages:
        errors.append("no messages parsed")
    else:
        # Check message format
        seen_seqs = set()
        roles_found = set()
        for i, msg in enumerate(messages):
            if 'role' not in msg or not msg['role']:
                errors.append(f"message {i}: missing role")
            elif msg['role'] not in ('user', 'assistant', 'system', 'unknown'):
                warnings.append(f"message {i}: unusual role '{msg['role']}'")
            else:
                roles_found.add(msg['role'])

            if 'content' not in msg or not msg['content']:
                errors.append(f"message {i}: missing content")
            elif not msg['content'].strip():
                warnings.append(f"message {i}: empty content")

            if 'sequence' not in msg:
                warnings.append(f"message {i}: missing sequence")
            elif msg['sequence'] in seen_seqs:
                warnings.append(f"message {i}: duplicate sequence {msg['sequence']}")
            else:
                seen_seqs.add(msg['sequence'])

        # Check for at least one user message
        if 'user' not in roles_found:
            warnings.append("no user messages found in session")

    # Check prompts
    if prompts:
        for i, p in enumerate(prompts):
            if 'text' not in p or not p['text']:
                errors.append(f"prompt {i}: missing text")
            if 'type' not in p:
                warnings.append(f"prompt {i}: missing type")

    # Check item fields
    if 'source_db' not in item:
        warnings.append("item missing source_db")
    if 'source_table' not in item:
        warnings.append("item missing source_table")
    if 'source_format' not in item:
        warnings.append("item missing source_format")

    valid = len(errors) == 0
    return {
        'valid': valid,
        'errors': errors,
        'warnings': warnings,
        'session_name': session_name,
        'message_count': len(messages),
        'prompt_count': len(prompts),
        'content_hash': content_hash,
    }


def import_session(mysql_conn, dest_db, item, messages, prompts, logger, dry_run=False, validate=False):
    """Import a single session with its messages and prompts.

    In dry_run mode: validates data without writing, checks for duplicates.
    In validate mode: performs full validation and returns detailed results.
    """
    session_name = extract_session_name(item, messages)
    content_hash = compute_content_hash(messages)

    if dry_run or validate:
        # Full validation without writing
        result = validate_session(item, messages, prompts, logger)

        # Check for duplicate sessions in MySQL (read-only)
        try:
            conn = mysql_conn.connect(dest_db)
            cur = conn.cursor()
            cur.execute(
                f"SELECT row_id FROM sessions WHERE source_db=%s AND source_table=%s AND session_name=%s",
                (item.get('source_db', ''), item.get('source_table', ''), session_name)
            )
            if cur.fetchone():
                result['warnings'].append("duplicate session name in destination DB")
                result['duplicate'] = True
            else:
                result['duplicate'] = False

            cur.execute(f"SELECT row_id FROM sessions WHERE content_hash=%s", (content_hash,))
            if cur.fetchone():
                result['warnings'].append("duplicate content hash in destination DB")
                result['hash_duplicate'] = True
            else:
                result['hash_duplicate'] = False

            cur.close()
        except Exception as e:
            result['warnings'].append(f"could not check duplicates: {e}")
            result['duplicate'] = False
            result['hash_duplicate'] = False

        if validate:
            # Full validation mode — return detailed results
            return result

        # Dry-run mode — log and return result dict for report aggregation
        status = "OK" if result['valid'] else "INVALID"
        dup_note = " [DUPLICATE]" if result.get('duplicate') or result.get('hash_duplicate') else ""
        logger.info(f"  [DRY RUN] {status}{dup_note}: {session_name} "
                    f"({len(messages)} msgs, {len(prompts)} prompts)",
                    extra={'step': '4'})
        if result['errors']:
            for err in result['errors']:
                logger.warning(f"    ERROR: {err}", extra={'step': '4'})
        if result['warnings']:
            for warn in result['warnings']:
                logger.debug(f"    WARN: {warn}", extra={'step': '4'})
        return result

    conn = mysql_conn.connect(dest_db)
    cur = conn.cursor()

    try:
        cur.execute(
            f"SELECT row_id FROM sessions WHERE source_db=%s AND source_table=%s AND session_name=%s",
            (item['source_db'], item['source_table'], session_name)
        )
        existing = cur.fetchone()
        if existing:
            logger.info(f"  Skip (exists): {session_name}", extra={'step': '4'})
            cur.close()
            return False

        cur.execute(
            f"SELECT row_id FROM sessions WHERE content_hash=%s",
            (content_hash,)
        )
        existing_hash = cur.fetchone()
        if existing_hash:
            logger.info(f"  Skip (hash match): {session_name}", extra={'step': '4'})
            cur.close()
            return False

        metadata = json.dumps({
            'source_row_id': item.get('row_id'),
            'file_path': item.get('file_path'),
            'date': item.get('date'),
        })

        cur.execute(
            f"""INSERT INTO sessions
                (session_name, source_db, source_table, source_format,
                 source_created_at, source_modified_at, message_count, status, content_hash, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (session_name, item['source_db'], item['source_table'],
             item.get('source_format', '.md'),
             item.get('date'), item.get('date'),
             len(messages), 'imported', content_hash, metadata)
        )
        session_id = cur.lastrowid

        batch_size = 500
        for i in range(0, len(messages), batch_size):
            batch = messages[i:i + batch_size]
            values = [(session_id, m['role'], m['content'], m['sequence'], item.get('row_id'))
                      for m in batch]
            cur.executemany(
                f"INSERT INTO messages (session_id, role, content, sequence, source_row_id) VALUES (%s, %s, %s, %s, %s)",
                values
            )

        for p in prompts:
            cur.execute(
                f"INSERT INTO prompts (session_id, prompt_text, prompt_type) VALUES (%s, %s, %s)",
                (session_id, p['text'], p['type'])
            )

        conn.commit()
        logger.info(f"  Imported: {session_name} ({len(messages)} msgs, {len(prompts)} prompts)",
                    extra={'step': '4'})
        cur.close()
        return True

    except Exception as e:
        conn.rollback()
        logger.error(f"  Import failed for {session_name}: {e}", extra={'step': '4'})
        try:
            cur.close()
        except Exception:
            pass
        return False


# ─── Embedder ──────────────────────────────────────────────────────────────

def qdrant_health_check(config):
    """Check if Qdrant is running."""
    if not HAS_REQUESTS:
        return False
    try:
        r = requests.get(f"http://{config.QDRANT_HOST}:{config.QDRANT_PORT}/collections", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


def ensure_qdrant_collection(config, logger):
    """Create Qdrant collection if it doesn't exist."""
    if not HAS_REQUESTS:
        logger.warning("requests not installed, skipping Qdrant", extra={'step': '5'})
        return False

    url = f"http://{config.QDRANT_HOST}:{config.QDRANT_PORT}/collections/{config.QDRANT_COLLECTION}"
    try:
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            logger.info(f"Qdrant collection exists: {config.QDRANT_COLLECTION}", extra={'step': '5'})
            return True
    except Exception:
        pass

    try:
        r = requests.put(url, json={
            "vectors": {
                "size": config.EMBED_DIMENSIONS,
                "distance": "Cosine"
            }
        }, timeout=10)
        if r.status_code in (200, 201):
            logger.info(f"Created Qdrant collection: {config.QDRANT_COLLECTION}", extra={'step': '5'})
            return True
        else:
            logger.error(f"Qdrant collection creation failed: {r.text}", extra={'step': '5'})
            return False
    except Exception as e:
        logger.error(f"Qdrant connection failed: {e}", extra={'step': '5'})
        return False


def embed_messages(mysql_conn, dest_db, config, logger, dry_run=False):
    """Embed un-embedded messages into Qdrant."""
    if dry_run:
        # Validate embedding prerequisites and estimate work
        logger.info("[DRY RUN] Validating embedding prerequisites...", extra={'step': '5'})

        # Check Qdrant connectivity
        qdrant_ok = qdrant_health_check(config)
        if qdrant_ok:
            logger.info("  Qdrant: reachable", extra={'step': '5'})
        else:
            logger.warning("  Qdrant: NOT reachable — embeddings would fail", extra={'step': '5'})

        # Check embedding model availability
        model_available = False
        try:
            from sentence_transformers import SentenceTransformer
            model_available = True
            logger.info(f"  Embedding model: {config.EMBED_MODEL} (available)", extra={'step': '5'})
        except ImportError:
            logger.warning("  sentence_transformers not installed — embeddings would fail",
                           extra={'step': '5'})

        # Count messages that would be embedded
        try:
            conn = mysql_conn.connect(dest_db)
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM messages WHERE embedded=FALSE")
            total = cur.fetchone()[0]
            cur.close()

            # Estimate embedding time (~100 msgs/sec for all-MiniLM-L6-v2 on CPU)
            est_seconds = total / 100.0 if total > 0 else 0
            est_minutes = est_seconds / 60.0
            logger.info(f"  Messages to embed: {total}", extra={'step': '5'})
            if total > 0:
                logger.info(f"  Estimated embedding time: {est_seconds:.0f}s ({est_minutes:.1f} min)",
                            extra={'step': '5'})
            logger.info(f"  Batch size: {config.BATCH_SIZE}", extra={'step': '5'})
            logger.info(f"  Vector dimensions: {config.EMBED_DIMENSIONS}", extra={'step': '5'})

            if not qdrant_ok or not model_available:
                logger.warning("  [DRY RUN] Embedding would FAIL — missing prerequisites",
                               extra={'step': '5'})
            else:
                logger.info("  [DRY RUN] Embedding prerequisites OK — would succeed",
                            extra={'step': '5'})
        except Exception as e:
            logger.warning(f"  [DRY RUN] Could not count unembedded messages: {e}",
                           extra={'step': '5'})
        return

    if not qdrant_health_check(config):
        logger.warning("Qdrant not running, skipping embeddings", extra={'step': '5'})
        return

    ensure_qdrant_collection(config, logger)

    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        logger.warning("sentence_transformers not installed, skipping embeddings", extra={'step': '5'})
        return

    logger.info("Loading embedding model...", extra={'step': '5'})
    model = SentenceTransformer(config.EMBED_MODEL)

    conn = mysql_conn.connect(dest_db)
    cur = conn.cursor(buffered=False)

    cur.execute("SELECT COUNT(*) FROM messages WHERE embedded=FALSE")
    total = cur.fetchone()[0]
    logger.info(f"Messages to embed: {total}", extra={'step': '5'})

    if total == 0:
        cur.close()
        return

    cur.close()
    cur = conn.cursor(buffered=False)
    cur.execute("SELECT row_id, session_id, content FROM messages WHERE embedded=FALSE")

    batch_size = config.BATCH_SIZE
    batch = []
    embedded_count = 0

    for row in cur:
        row_id, session_id, content = row
        if not content or not content.strip():
            cur_update = conn.cursor()
            cur_update.execute("UPDATE messages SET embedded=TRUE WHERE row_id=%s", (row_id,))
            cur_update.close()
            continue

        batch.append((row_id, session_id, content))

        if len(batch) >= batch_size:
            embedded_count += embed_batch(conn, model, batch, config, logger)
            batch = []

    if batch:
        embedded_count += embed_batch(conn, model, batch, config, logger)

    cur.close()
    conn.commit()
    logger.info(f"Embedded {embedded_count} messages", extra={'step': '5'})


def embed_batch(conn, model, batch, config, logger):
    """Embed a batch of messages and upsert to Qdrant."""
    texts = [item[2][:config.EMBED_MAX_TOKENS * 4] for item in batch]
    vectors = model.encode(texts, show_progress_bar=False)

    points = []
    for (row_id, session_id, _), vector in zip(batch, vectors):
        points.append({
            "id": row_id,
            "vector": vector.tolist(),
            "payload": {
                "message_id": row_id,
                "session_id": session_id,
            }
        })

    url = f"http://{config.QDRANT_HOST}:{config.QDRANT_PORT}/collections/{config.QDRANT_COLLECTION}/points"
    try:
        r = requests.put(url, json={"points": points}, timeout=30)
        if r.status_code not in (200, 201):
            logger.error(f"Qdrant upsert failed: {r.text[:200]}", extra={'step': '5'})
            return 0
    except Exception as e:
        logger.error(f"Qdrant upsert error: {e}", extra={'step': '5'})
        return 0

    cur = conn.cursor()
    row_ids = [item[0] for item in batch]
    cur.executemany("UPDATE messages SET embedded=TRUE WHERE row_id=%s", [(rid,) for rid in row_ids])
    cur.close()
    conn.commit()

    logger.info(f"  Embedded batch: {len(batch)} messages", extra={'step': '5'})
    return len(batch)


# ─── Verification ──────────────────────────────────────────────────────────

def verify_import(mysql_conn, dest_db, source_tables, logger):
    """Verify imported data against sources."""
    logger.info("Verifying imported chats...", extra={'step': '7'})

    conn = mysql_conn.connect(dest_db)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM sessions")
    session_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM messages")
    message_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM prompts")
    prompt_count = cur.fetchone()[0]

    logger.info(f"  Sessions: {session_count}", extra={'step': '7'})
    logger.info(f"  Messages: {message_count}", extra={'step': '7'})
    logger.info(f"  Prompts: {prompt_count}", extra={'step': '7'})

    cur.execute("SELECT COUNT(*) FROM messages WHERE embedded=FALSE")
    unembedded = cur.fetchone()[0]
    if unembedded > 0:
        logger.warning(f"  Unembedded messages: {unembedded}", extra={'step': '7'})

    cur.execute("SELECT COUNT(*) FROM messages WHERE session_id NOT IN (SELECT row_id FROM sessions)")
    orphans = cur.fetchone()[0]
    if orphans > 0:
        logger.warning(f"  Orphaned messages: {orphans}", extra={'step': '7'})

    cur.execute("SELECT COUNT(*) FROM prompts WHERE session_id NOT IN (SELECT row_id FROM sessions)")
    orphan_prompts = cur.fetchone()[0]
    if orphan_prompts > 0:
        logger.warning(f"  Orphaned prompts: {orphan_prompts}", extra={'step': '7'})

    cur.execute("SELECT session_name, COUNT(*) as cnt FROM sessions GROUP BY session_name HAVING cnt > 1")
    dups = cur.fetchall()
    if dups:
        logger.warning(f"  Duplicate session names: {len(dups)}", extra={'step': '7'})
        for name, cnt in dups[:10]:
            logger.warning(f"    {name} ({cnt} copies)", extra={'step': '7'})

    cur.execute("SELECT content_hash, COUNT(*) as cnt FROM sessions GROUP BY content_hash HAVING cnt > 1")
    hash_dups = cur.fetchall()
    if hash_dups:
        logger.warning(f"  Duplicate content hashes: {len(hash_dups)}", extra={'step': '7'})

    cur.execute("SELECT MIN(source_modified_at), MAX(source_modified_at) FROM sessions WHERE source_modified_at IS NOT NULL")
    date_range = cur.fetchone()
    if date_range[0] and date_range[1]:
        logger.info(f"  Date range: {date_range[0]} to {date_range[1]}", extra={'step': '7'})

    cur.close()


# ─── Pipeline State ────────────────────────────────────────────────────────

def save_pipeline_state(mysql_conn, dest_db, step, last_id=0, batch=0, status='running'):
    """Save current pipeline state for resume support."""
    conn = mysql_conn.connect(dest_db)
    cur = conn.cursor()
    cur.execute(
        f"INSERT INTO pipeline_state (id, current_step, last_processed_id, batch_number, status) "
        f"VALUES (1, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE "
        f"current_step=%s, last_processed_id=%s, batch_number=%s, status=%s, updated_at=NOW()",
        (step, last_id, batch, status, step, last_id, batch, status)
    )
    conn.commit()
    cur.close()


def get_pipeline_state(mysql_conn, dest_db):
    """Get last pipeline state for resume."""
    try:
        conn = mysql_conn.connect(dest_db)
        cur = conn.cursor()
        cur.execute("SELECT current_step, last_processed_id, batch_number, status FROM pipeline_state WHERE id=1")
        row = cur.fetchone()
        cur.close()
        if row:
            return {'step': row[0], 'last_id': row[1], 'batch': row[2], 'status': row[3]}
    except Exception:
        pass
    return None


# ─── Lock File ─────────────────────────────────────────────────────────────

def acquire_lock(logger):
    """Create lock file to prevent concurrent runs."""
    if os.path.exists(LOCK_FILE):
        logger.error(f"Lock file exists: {LOCK_FILE} — another run in progress", extra={'step': 'init'})
        return False
    try:
        with open(LOCK_FILE, 'w') as f:
            f.write(str(os.getpid()))
        return True
    except Exception as e:
        logger.error(f"Cannot create lock file: {e}", extra={'step': 'init'})
        return False


def release_lock():
    """Remove lock file."""
    try:
        if os.path.exists(LOCK_FILE):
            os.remove(LOCK_FILE)
    except Exception:
        pass


def generate_validation_report(validation_results, config, logger, embed_enabled):
    """Generate a summary report for dry-run / validate mode.

    validation_results: list of dicts from validate_session() / import_session(validate=True)
    """
    total = len(validation_results)
    if total == 0:
        logger.info("Validation report: no sessions to validate", extra={'step': '8'})
        return

    valid_count = sum(1 for r in validation_results if r.get('valid'))
    invalid_count = total - valid_count
    total_messages = sum(r.get('message_count', 0) for r in validation_results)
    total_prompts = sum(r.get('prompt_count', 0) for r in validation_results)
    duplicates = sum(1 for r in validation_results if r.get('duplicate') or r.get('hash_duplicate'))

    # Collect all errors and warnings
    all_errors = []
    all_warnings = []
    for r in validation_results:
        all_errors.extend(r.get('errors', []))
        all_warnings.extend(r.get('warnings', []))

    # Estimate embedding time (~100 msgs/sec for all-MiniLM-L6-v2 on CPU)
    est_embed_seconds = total_messages / 100.0 if total_messages > 0 else 0
    est_embed_minutes = est_embed_seconds / 60.0

    logger.info("=" * 60, extra={'step': '8'})
    logger.info("VALIDATION REPORT (dry-run)", extra={'step': '8'})
    logger.info("=" * 60, extra={'step': '8'})
    logger.info(f"  Sessions validated:    {total}", extra={'step': '8'})
    logger.info(f"  Valid sessions:        {valid_count}", extra={'step': '8'})
    logger.info(f"  Invalid sessions:      {invalid_count}", extra={'step': '8'})
    logger.info(f"  Duplicate sessions:    {duplicates}", extra={'step': '8'})
    logger.info(f"  Total messages:        {total_messages}", extra={'step': '8'})
    logger.info(f"  Total prompts:         {total_prompts}", extra={'step': '8'})

    if embed_enabled:
        logger.info(f"  Est. embedding time:  {est_embed_seconds:.0f}s ({est_embed_minutes:.1f} min)",
                    extra={'step': '8'})
        logger.info(f"  Embedding model:      {config.EMBED_MODEL}", extra={'step': '8'})
        logger.info(f"  Vector dimensions:    {config.EMBED_DIMENSIONS}", extra={'step': '8'})

    if all_errors:
        logger.warning(f"  Total errors:         {len(all_errors)}", extra={'step': '8'})
        # Show unique error types
        from collections import Counter
        error_types = Counter()
        for err in all_errors:
            # Normalize: remove message index numbers for grouping
            normalized = re.sub(r'message \d+', 'message N', err)
            normalized = re.sub(r'prompt \d+', 'prompt N', normalized)
            error_types[normalized] += 1
        for err_type, count in error_types.most_common(10):
            logger.warning(f"    [{count}x] {err_type}", extra={'step': '8'})

    if all_warnings:
        logger.info(f"  Total warnings:       {len(all_warnings)}", extra={'step': '8'})
        from collections import Counter
        warn_types = Counter()
        for warn in all_warnings:
            normalized = re.sub(r'message \d+', 'message N', warn)
            normalized = re.sub(r'prompt \d+', 'prompt N', normalized)
            warn_types[normalized] += 1
        for warn_type, count in warn_types.most_common(10):
            logger.info(f"    [{count}x] {warn_type}", extra={'step': '8'})

    logger.info("=" * 60, extra={'step': '8'})

    if invalid_count > 0:
        logger.warning(f"  {invalid_count} session(s) would FAIL to import — fix errors before real run",
                       extra={'step': '8'})
    if duplicates > 0:
        logger.info(f"  {duplicates} session(s) are duplicates — would be skipped on real run",
                    extra={'step': '8'})
    if valid_count > 0 and invalid_count == 0:
        logger.info("  All sessions valid — safe to run without --dry-run", extra={'step': '8'})


# ─── Main Pipeline ─────────────────────────────────────────────────────────

def run_pipeline(args):
    """Main pipeline orchestrator."""
    config = cfg
    logger, step_filter = setup_logging(config)

    logger.info(f"Chat Mover v{PIPELINE_VERSION} starting", extra={'step': 'init'})
    logger.info(f"Sources: {args.source}", extra={'step': 'init'})
    logger.info(f"Dry run: {args.dry_run}", extra={'step': 'init'})
    logger.info(f"Validate: {args.validate}", extra={'step': 'init'})
    logger.info(f"Embed: {args.embed}", extra={'step': 'init'})

    if not acquire_lock(logger):
        return 1

    start_time = time.time()

    try:
        # ─── Step 0: Connect to sources ───
        step_filter.step = '0'
        if not HAS_MYSQL:
            logger.error("mysql.connector not installed. pip install mysql-connector-python", extra={'step': '0'})
            return 1

        mysql_conn = MySQLConn(config.MYSQL_HOST, config.MYSQL_PORT,
                               config.MYSQL_USER, config.MYSQL_PASSWORD)

        if not mysql_conn.test():
            logger.error("MySQL connection failed", extra={'step': '0'})
            return 1
        logger.info("MySQL connected", extra={'step': '0'})

        # ─── Step 0.5: Create schema ───
        step_filter.step = '0.5'
        create_schema(mysql_conn, config.DESTINATION_DB, logger)

        # ─── Step 1: Read and classify ───
        step_filter.step = '1'
        all_items = []

        if 'mysql' in args.source:
            row_limit = args.limit if args.limit else 50000
            if args.test:
                row_limit = 10
                logger.info("TEST MODE: limiting to 10 rows per table", extra={'step': '1'})
            mysql_items = read_mysql_sources(mysql_conn, config.SOURCE_TABLES, logger, max_rows=row_limit)
            all_items.extend(mysql_items)

        if 'disk' in args.source:
            folders = args.folder if args.folder else config.DISK_FOLDERS
            disk_items = read_disk_sources(folders, config.SKIP_FILENAMES, config.SKIP_PATHS, logger)
            all_items.extend(disk_items)

        if 'sqlite' in args.source:
            sqlite_sources = []
            # Build from CLI --sqlite-db args if provided
            if args.sqlite_db:
                for db_path in args.sqlite_db:
                    src_cfg = {'db_path': db_path, 'tables': []}
                    # Parse --sqlite-config JSON if provided for this db
                    sqlite_sources.append(src_cfg)
            # Fall back to config-defined sources
            if not sqlite_sources:
                sqlite_sources = config.SQLITE_SOURCES
            # If still empty and --sqlite-db not given, try auto-detect on known DBs
            if not sqlite_sources and args.sqlite_db is None:
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                known_dbs = [
                    os.path.join(project_root, 'efl_brain', 'efl_brain.db'),
                    os.path.join(project_root, 'Smart_system_seach', 'autocomplete.db'),
                    os.path.join(project_root, 'BookSystem', 'book.db'),
                ]
                for kdb in known_dbs:
                    kdb = os.path.normpath(kdb)
                    if os.path.isfile(kdb):
                        sqlite_sources.append({'db_path': kdb, 'tables': []})

            if sqlite_sources:
                row_limit = args.limit if args.limit else 50000
                if args.test:
                    row_limit = 10
                sqlite_items = read_sqlite_sources(sqlite_sources, logger, max_rows=row_limit)
                all_items.extend(sqlite_items)
            else:
                logger.warning("No SQLite sources configured. Use --sqlite-db or set sqlite_sources config.",
                               extra={'step': '1'})

        logger.info(f"Total items collected: {len(all_items)}", extra={'step': '1'})

        # Classify
        chat_items = []
        doc_count = 0
        other_count = 0

        for item in all_items:
            category = classify_content(item['content'], item.get('filename', ''))
            item['category'] = category
            if category == 'chat':
                chat_items.append(item)
            elif category == 'doc':
                doc_count += 1
            else:
                other_count += 1

        logger.info(f"Classification: {len(chat_items)} chat, {doc_count} doc, {other_count} other",
                    extra={'step': '1'})

        # ─── Step 2: Filter (already done above) ───
        step_filter.step = '2'
        if not chat_items:
            logger.info("No chat files found. Done.", extra={'step': '2'})
            return 0

        chat_items.sort(key=lambda x: x.get('date') or '', reverse=True)
        logger.info(f"Sorted {len(chat_items)} chat files (newest first)", extra={'step': '2'})

        # ─── Step 3: Exclude Chat_History ───
        step_filter.step = '3'
        chat_items = [item for item in chat_items if item.get('source_db') != config.DESTINATION_DB]
        logger.info(f"After excluding {config.DESTINATION_DB}: {len(chat_items)}", extra={'step': '3'})

        # ─── Step 4: Parse and import ───
        step_filter.step = '4'
        imported = 0
        skipped = 0
        failed = 0
        validation_results = []

        for i, item in enumerate(chat_items):
            messages = parse_chat(item)
            if not messages:
                logger.warning(f"  No messages parsed from {item.get('filename', '?')}", extra={'step': '4'})
                other_count += 1
                if args.dry_run or args.validate:
                    validation_results.append({
                        'valid': False,
                        'errors': ['no messages parsed'],
                        'warnings': [],
                        'session_name': item.get('filename', '?'),
                        'message_count': 0,
                        'prompt_count': 0,
                        'content_hash': '',
                        'duplicate': False,
                        'hash_duplicate': False,
                    })
                continue

            prompts = extract_prompts(messages)
            ok = import_session(mysql_conn, config.DESTINATION_DB, item, messages, prompts,
                                logger, dry_run=args.dry_run, validate=args.validate)
            if args.dry_run or args.validate:
                # import_session returns a result dict in dry-run / validate mode
                validation_results.append(ok)
                if ok.get('valid'):
                    imported += 1
                else:
                    failed += 1
            elif ok:
                imported += 1
            elif ok is False:
                skipped += 1

            if (i + 1) % 50 == 0:
                elapsed = time.time() - start_time
                pct = (i + 1) / len(chat_items) * 100
                logger.info(f"  Progress: {i+1}/{len(chat_items)} ({pct:.1f}%) — {imported} imported, {skipped} skipped — {elapsed:.0f}s",
                            extra={'step': '4'})

        logger.info(f"Import complete: {imported} imported, {skipped} skipped, {failed} failed",
                    extra={'step': '4'})

        # ─── Step 5: Embed ───
        step_filter.step = '5'
        if args.embed:
            embed_messages(mysql_conn, config.DESTINATION_DB, config, logger,
                           dry_run=(args.dry_run or args.validate))
        else:
            logger.info("Embedding skipped (use --embed to enable)", extra={'step': '5'})

        # ─── Step 7: Verify ───
        step_filter.step = '7'
        if not args.dry_run and not args.validate:
            verify_import(mysql_conn, config.DESTINATION_DB, config.SOURCE_TABLES, logger)

        # ─── Step 8: Final ───
        step_filter.step = '8'
        elapsed = time.time() - start_time

        # Generate validation report for dry-run / validate mode
        if args.dry_run or args.validate:
            generate_validation_report(validation_results, config, logger, args.embed)

        logger.info(f"Pipeline complete in {elapsed:.1f}s", extra={'step': '8'})
        logger.info(f"  Items: {len(all_items)} total, {len(chat_items)} chat, {imported} imported", extra={'step': '8'})

        if not args.dry_run and not args.validate:
            save_pipeline_state(mysql_conn, config.DESTINATION_DB, '8', 0, 0, 'complete')

        # Cleanup temp files
        if os.path.exists(CLASSIFICATION_FILE):
            os.remove(CLASSIFICATION_FILE)

        mysql_conn.close()
        return 0

    except KeyboardInterrupt:
        logger.warning("Pipeline interrupted by user", extra={'step': 'init'})
        return 130
    except Exception as e:
        logger.error(f"Pipeline error: {e}", extra={'step': 'init'})
        import traceback
        logger.debug(traceback.format_exc(), extra={'step': 'init'})
        return 1
    finally:
        release_lock()


# ─── CLI ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Chat Mover — Chat-to-Database Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument('--config', default=DEFAULT_CONFIG_PATH,
                        help=f'Config file path (default: {DEFAULT_CONFIG_PATH})')
    parser.add_argument('--source', default='mysql',
                        help='Source(s): mysql, disk, sqlite, or comma-separated (e.g. mysql,disk)')
    parser.add_argument('--folder', nargs='*', default=None,
                        help='Disk folder(s) to scan (overrides config disk_folders)')
    parser.add_argument('--sqlite-db', nargs='*', default=None,
                        help='SQLite database file path(s) to read (auto-detects chat-like tables)')
    parser.add_argument('--embed', action='store_true',
                        help='Embed messages into Qdrant after import')
    parser.add_argument('--with-graph', action='store_true',
                        help='Build knowledge graph (optional, slow)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Run without writing to database or Qdrant — validates data and reports')
    parser.add_argument('--validate', action='store_true',
                        help='Full validation mode: parse, validate, check duplicates, report — no writes')
    parser.add_argument('--limit', type=int, default=None,
                        help='Max rows to read per source table (default: 50000)')
    parser.add_argument('--test', action='store_true',
                        help='Test mode: only read 10 rows per table, dry-run automatically')
    parser.add_argument('--resume', action='store_true',
                        help='Resume from last pipeline state')

    args = parser.parse_args()
    args.source = args.source.lower().split(',')
    if args.test:
        args.dry_run = True

    sys.exit(run_pipeline(args))


if __name__ == '__main__':
    main()
