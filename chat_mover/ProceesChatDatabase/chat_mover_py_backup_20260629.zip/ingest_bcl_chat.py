#!/usr/bin/env python3
#[@GHOST]{("file_path=chat_mover/ingest_bcl_chat.py";"identity=ingest_bcl_chat.py";"purpose=";"date=2026-06-28";"version=1.0";"author=Cascade";"chat_link=")}
#[@VBSTYLE]{[@pass]{"return=Tuple3";"dispatch=Run";"no=no_decorators|no_print|no_hardcoded";"model=one_class_one_domain_one_authority_complete"}[@fail]{"decorators_found";"print_found";"hardcoded_values";"self._used"}}
#[@FILEID]{("session_id=auto";"context=Auto-stamped by header watcher";"purpose=")}
#[@SUMMARY]{("Created on 2026-06-28";"auto_stamped=true")}

#!/usr/bin/env python3
"""Ingest the Mapping Dom_Graph Architecture chat into bcl_chat_store.db."""

import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bcl_pipeline import BclChatStore
from bcl_pipeline import BclChatCompressor

CHAT_PATH = "/Users/wws/Downloads/Mapping Dom_Graph Architecture.md"
STAGE2_PATH = "/Users/wws/Downloads/Mapping_Dom_Graph_BCL_Stage2.md"

def main():
    print("=== INGESTING CHAT INTO bcl_chat_store.db ===")
    print()

    # Open store
    store = BclChatStore()
    rv = store.Run("open", {})
    if rv[0] != 1:
        print("ERROR opening store:", rv[2])
        return
    print("  Store opened:", rv[1])

    # Read original chat
    with open(CHAT_PATH, "r", encoding="utf-8", errors="replace") as f:
        chat_content = f.read()
    print(f"  Original chat: {len(chat_content.splitlines())} lines, {len(chat_content)} bytes")

    # Store original chat
    rv = store.Run("store_chat", {"source_path": CHAT_PATH, "content": chat_content})
    if rv[0] != 1:
        print("ERROR storing chat:", rv[2])
        return
    chat_id = rv[1]["chat_id"]
    print(f"  Stored original chat: id={chat_id}, md5={rv[1].get('md5','?')}")
    if rv[1].get("already_exists"):
        print("  (Chat already exists in DB)")

    # Run Stage 1 compression
    print()
    print("  Running Stage 1 compression...")
    comp = BclChatCompressor()
    rv = comp.Run("compress", {"input_path": CHAT_PATH})
    if rv[0] != 1:
        print("ERROR compressing:", rv[2])
        return

    tokens = rv[1].get("tokens", [])
    stats = rv[1].get("stats", {})
    output = rv[1].get("output", "")
    token_count = len(tokens)
    source_lines = stats.get("source_lines", 0)
    ratio = source_lines / max(token_count, 1)
    output_lines = len(output.splitlines()) if output else 0

    print(f"  Stage 1: {token_count} tokens, {output_lines} output lines, ratio {ratio:.1f}:1")

    # Store Stage 1
    rv = store.Run("store_stage1", {
        "chat_id": chat_id,
        "output_text": output,
        "token_count": token_count,
        "compression_ratio": ratio,
        "output_lines": output_lines,
        "stats_json": json.dumps(stats),
    })
    if rv[0] != 1:
        print("ERROR storing stage1:", rv[2])
        return
    stage1_id = rv[1]["stage1_id"]
    print(f"  Stored Stage 1: id={stage1_id}")

    # Read Stage 2 output
    with open(STAGE2_PATH, "r", encoding="utf-8", errors="replace") as f:
        stage2_text = f.read()
    print(f"  Stage 2: {len(stage2_text.splitlines())} lines")

    # Parse items from Stage 2
    items = []
    for line in stage2_text.splitlines():
        if "#[@PROBLEM]" in line:
            text = line.split("#[@PROBLEM]")[-1].strip()[:300]
            items.append({"type": "PROBLEM", "content": text, "status": "open"})
        elif "#[@UNRESOLVED]" in line:
            text = line.split("#[@UNRESOLVED]")[-1].strip()[:300]
            items.append({"type": "UNRESOLVED", "content": text, "status": "open"})
        elif "#[@DECISION]" in line:
            text = line.split("#[@DECISION]")[-1].strip()[:300]
            items.append({"type": "DECISION", "content": text, "status": "resolved"})
        elif "#[@SUCCESS]" in line:
            text = line.split("#[@SUCCESS]")[-1].strip()[:300]
            items.append({"type": "SUCCESS", "content": text, "status": "resolved"})
        elif "#[@FAILED]" in line:
            text = line.split("#[@FAILED]")[-1].strip()[:300]
            items.append({"type": "FAILED", "content": text, "status": "open"})
        elif "#[@LESSON]" in line:
            text = line.split("#[@LESSON]")[-1].strip()[:300]
            items.append({"type": "LESSON", "content": text, "status": "resolved"})

    print(f"  Parsed {len(items)} items from Stage 2")
    type_counts = {}
    for item in items:
        type_counts[item["type"]] = type_counts.get(item["type"], 0) + 1
    for t, c in sorted(type_counts.items()):
        print(f"    {t}: {c}")

    # Store Stage 2
    rv = store.Run("store_stage2", {
        "chat_id": chat_id,
        "stage1_id": stage1_id,
        "output_text": stage2_text,
        "items": items,
    })
    if rv[0] != 1:
        print("ERROR storing stage2:", rv[2])
        return
    print(f"  Stored Stage 2: id={rv[1]['stage2_id']}, items={rv[1]['items_stored']}")

    # Show stats
    print()
    rv = store.Run("get_stats", {})
    if rv[0]:
        print("=== DATABASE STATS ===")
        for k, v in rv[1].items():
            print(f"  {k}: {v}")

    # Show unresolved
    print()
    rv = store.Run("get_unresolved", {})
    if rv[0]:
        items = rv[1]["items"]
        print(f"=== UNRESOLVED ITEMS ({len(items)}) ===")
        for item in items:
            print(f"  [{item['item_id']}] L{item['line']} ({item['source']}) {item['content'][:100]}")

    store.Run("close", {})
    print()
    print("=== INGESTION COMPLETE ===")

if __name__ == "__main__":
    main()
