#!/usr/bin/env python3
"""
Step 5 of the ChatMover Refactor Pipeline: VALIDATE

Reads code_units + bcl_stamps from chatmover_code.db, runs validation checks,
and populates the violations table with all detected issues.

Checks:
  - has_print: print() in source_text
  - has_decorator: decorators present
  - has_self_underscore: self._ in method
  - run_no_tuple3: Run() method doesn't return Tuple3
  - method_no_tuple3: non-helper method doesn't return Tuple3
  - missing_run: class without Run() method
  - missing_bcl: unit without a BCL stamp
  - duplicate_method: same method name in multiple classes
  - dead_method: method never called (warning)
  - bare_except: bare except: clause (dangerous)
  - hardcoded_string: hardcoded string literal that looks like config
  - circular_dep: circular dependency in call graph

Usage:
    python3 validate.py              # Run all checks
    python3 validate.py --stats      # Show violation stats
    python3 validate.py --fix-suggest # Show suggested fixes
"""

import ast
import os
import sys
import re
import argparse
import sqlite3
from pathlib import Path


VIOLATIONS_SCHEMA = """
CREATE TABLE IF NOT EXISTS violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unit_id INTEGER,
    file_path TEXT,
    class_name TEXT,
    unit_name TEXT,
    unit_type TEXT,
    violation_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    detail TEXT,
    suggested_fix TEXT,
    status TEXT DEFAULT 'open',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (unit_id) REFERENCES code_units(id)
);
CREATE INDEX IF NOT EXISTS idx_v_type ON violations(violation_type);
CREATE INDEX IF NOT EXISTS idx_v_status ON violations(violation_type);
CREATE INDEX IF NOT EXISTS idx_v_unit ON violations(unit_id);
"""


def run_checks(db_path):
    """Run all validation checks and populate violations table."""
    conn = sqlite3.connect(db_path)
    conn.executescript(VIOLATIONS_SCHEMA)
    cur = conn.cursor()

    # Clear old violations
    cur.execute("DELETE FROM violations")

    # Get all units
    cur.execute("""
        SELECT id, file_path, unit_type, class_name, unit_name, source_text,
               return_type, decorators, is_vbstyle, line_start, line_end
        FROM code_units
        ORDER BY file_path, line_start
    """)
    units = cur.fetchall()

    violations = []

    # --- Check 1: has_print ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if utype == "import":
            continue
        if re.search(r'\bprint\s*\(', src):
            violations.append((uid, fpath, cls, name, utype, "has_print", "error",
                             "print() is forbidden in VBStyle",
                             "Replace with logging or return value"))

    # --- Check 2: has_decorator ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if decorators and decorators.strip():
            violations.append((uid, fpath, cls, name, utype, "has_decorator", "error",
                             f"Decorators found: {decorators}",
                             "Remove all decorators — VBStyle forbids them"))

    # --- Check 3: has_self_underscore ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if utype == "method" and re.search(r'self\._[a-z]', src):
            violations.append((uid, fpath, cls, name, utype, "has_self_underscore", "error",
                             "self._ prefix is forbidden — use self.state dict",
                             "Replace self._xxx with self.state['xxx']"))

    # --- Check 4: run_no_tuple3 ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if utype == "method" and name == "Run" and rtype != "Tuple3":
            violations.append((uid, fpath, cls, name, utype, "run_no_tuple3", "error",
                             f"Run() returns {rtype}, must return Tuple3",
                             "Ensure all return paths yield (1, data, None) or (0, None, (code, desc, 0))"))

    # --- Check 5: method_no_tuple3 (non-helper methods) ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if (utype == "method" and rtype != "Tuple3" and rtype != "None"
            and not name.startswith("_") and name not in ("read_state", "set_config", "__init__")):
            violations.append((uid, fpath, cls, name, utype, "method_no_tuple3", "warning",
                             f"{name}() returns {rtype}, VBStyle methods should return Tuple3",
                             "Convert return to Tuple3 format"))

    # --- Check 6: missing_run ---
    cur.execute("SELECT DISTINCT class_name FROM code_units WHERE unit_type='class' AND class_name IS NOT NULL")
    all_classes = [r[0] for r in cur.fetchall()]
    cur.execute("SELECT DISTINCT class_name FROM code_units WHERE unit_name='Run' AND unit_type='method'")
    classes_with_run = [r[0] for r in cur.fetchall()]

    for cls in all_classes:
        if cls not in classes_with_run:
            cur.execute("SELECT id, file_path FROM code_units WHERE unit_name=? AND unit_type='class' LIMIT 1", (cls,))
            row = cur.fetchone()
            if row:
                violations.append((row[0], row[1], cls, cls, "class", "missing_run", "error",
                                 f"Class {cls} has no Run() dispatch method",
                                 "Add Run(self, command, params) with dispatch if/elif chain"))

    # --- Check 7: missing_bcl ---
    cur.execute("""
        SELECT cu.id, cu.file_path, cu.class_name, cu.unit_name, cu.unit_type
        FROM code_units cu
        LEFT JOIN bcl_stamps bs ON bs.unit_id = cu.id
        WHERE cu.unit_type IN ('class','method','function') AND bs.id IS NULL
    """)
    for row in cur.fetchall():
        violations.append((row[0], row[1], row[2], row[3], row[4], "missing_bcl", "warning",
                         "No BCL reasoning stamp",
                         "Run reason.py to generate stamp, then AI-review"))

    # --- Check 8: duplicate_method ---
    cur.execute("""
        SELECT unit_name, COUNT(DISTINCT class_name) as cnt, GROUP_CONCAT(DISTINCT class_name) as classes
        FROM code_units
        WHERE unit_type='method' AND unit_name NOT IN ('__init__','Run','read_state','set_config','_p',
              '_Connect','_Close','_CountWords','Status','Ingest')
        GROUP BY unit_name
        HAVING cnt > 1
    """)
    for row in cur.fetchall():
        violations.append((None, None, None, row[0], "method", "duplicate_method", "warning",
                         f"Method '{row[0]}' appears in {row[1]} classes: {row[2]}",
                         "Consolidate into shared base or db.py"))

    # --- Check 9: dead_method ---
    cur.execute("""
        SELECT cu.id, cu.file_path, cu.class_name, cu.unit_name
        FROM code_units cu
        WHERE cu.unit_type='method'
        AND cu.unit_name NOT IN ('_p','read_state','set_config','__init__','Run')
        AND cu.unit_name NOT IN (SELECT DISTINCT target_name FROM graph_edges WHERE edge_type='calls')
        AND cu.class_name NOT IN ('EditorTabs','FileExplorer','AIPanel','Terminal','IDEWindow')
    """)
    for row in cur.fetchall():
        violations.append((row[0], row[1], row[2], row[3], "method", "dead_method", "warning",
                         f"Method '{row[3]}' is never called",
                         "Remove or wire it up"))

    # --- Check 10: bare_except ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if utype == "import":
            continue
        try:
            tree = ast.parse(src)
            for node in ast.walk(tree):
                if isinstance(node, ast.Try):
                    for handler in node.handlers:
                        if handler.type is None:
                            violations.append((uid, fpath, cls, name, utype, "bare_except", "error",
                                             "Bare except: catches everything including KeyboardInterrupt",
                                             "Use 'except Exception' instead"))
        except Exception:
            pass

    # --- Check 11: hardcoded_strings (heuristic) ---
    for row in units:
        uid, fpath, utype, cls, name, src, rtype, decorators, vbstyle, ls, le = row
        if utype == "import":
            continue
        # Look for hardcoded DB config, paths, ports
        hardcoded_patterns = [
            (r'"localhost"', "hardcoded_host"),
            (r'"127\.0\.0\.1"', "hardcoded_host"),
            (r'"root"', "hardcoded_user"),
            (r'":\d{4,5}"', "hardcoded_port"),
            (r'os\.path\.expanduser\("~', "hardcoded_home_path"),
        ]
        for pattern, vtype in hardcoded_patterns:
            if re.search(pattern, src):
                violations.append((uid, fpath, cls, name, utype, vtype, "warning",
                                 f"Hardcoded value matching {pattern}",
                                 "Move to Config.py"))
                break  # one per unit

    # Insert all violations
    cur.executemany("""
        INSERT INTO violations (unit_id, file_path, class_name, unit_name, unit_type,
                                violation_type, severity, detail, suggested_fix)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, violations)

    conn.commit()
    conn.close()

    return len(violations)


def show_violation_stats(db_path):
    """Show violation statistics."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM violations")
    total = cur.fetchone()[0]

    cur.execute("""
        SELECT violation_type, severity, COUNT(*) as count
        FROM violations
        GROUP BY violation_type, severity
        ORDER BY count DESC
    """)
    by_type = cur.fetchall()

    cur.execute("""
        SELECT file_path, COUNT(*) as count
        FROM violations
        WHERE file_path IS NOT NULL
        GROUP BY file_path
        ORDER BY count DESC
    """)
    by_file = cur.fetchall()

    cur.execute("""
        SELECT class_name, unit_name, violation_type, severity, detail
        FROM violations
        WHERE severity = 'error'
        ORDER BY file_path, violation_type
        LIMIT 30
    """)
    errors = cur.fetchall()

    conn.close()

    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for vtype, severity, count in by_type:
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for fpath, count in by_file:
        fname = os.path.basename(fpath)
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
    for cls, name, vtype, severity, detail in errors:
        loc = f"{cls}.{name}" if cls else f"module.{name}"
        pass  # TODO: replace with Report
    pass  # TODO: replace with Report
def main():
    parser = argparse.ArgumentParser(description="Step 5: VALIDATE — Run all checks on code_units")
    parser.add_argument("--db", default=None, help="SQLite DB path")
    parser.add_argument("--stats", action="store_true", help="Show violation stats")
    args = parser.parse_args()

    db_path = args.db or os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatmover_code.db")
    if not os.path.exists(db_path):
        pass  # TODO: replace with Report
        sys.exit(1)

    if args.stats and not os.path.exists(db_path):
        show_violation_stats(db_path)
        return

    count = run_checks(db_path)
    pass  # TODO: replace with Report
    show_violation_stats(db_path)


if __name__ == "__main__":
    main()
